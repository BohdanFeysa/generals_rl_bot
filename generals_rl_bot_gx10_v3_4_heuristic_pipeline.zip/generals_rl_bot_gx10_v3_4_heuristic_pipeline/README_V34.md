# v3.4 heuristic-teacher pipeline

This package extends the existing v3.2/v3.3 CNN+GRU PPO project without changing
the model architecture or checkpoint tensor format.

It adds:

- a JAX-compatible heuristic agent (`src/heuristic.py`);
- a stateful standalone Python heuristic submission (`heuristic_submission/`);
- evaluation against Expander, Hunter and the heuristic;
- corrected curriculum staging;
- a 75% exact-competition / 25% `max_bfs=28` final map pool;
- potential-difference reward shaping;
- mixed-opponent PPO;
- online behavior cloning from the heuristic;
- learner-control masks, so fixed-opponent actions never enter PPO/value losses.

The implemented heuristic encodes ideas from the Generals.io 1v1 guide without
copying another bot's source: opening accumulation, multi-flank exploration,
information-gain scoring, enemy-land priority, gathering toward an objective,
general defense, deathtouch awareness, and anti-loop behavior in the standalone
submission.

## Important separation

Keep these directories separate:

```text
checkpoints_v32/            completed failed sparse-self-play experiment
checkpoints_v34_.../        new recovery experiments
heuristic_submission/       standalone non-neural bot
submission/                 existing neural C++ exporter/runtime
```

Never write v3.4 checkpoints into `checkpoints_v32`.

## 1. Install this package over the current project

From the current project root:

```bash
cd ~/Desktop/feysa_RL_BOT/generals_rl_bot/generals_rl_bot_gx10_v3_1

mkdir -p ../code_backups
stamp=$(date +%Y%m%d_%H%M%S)
tar --exclude=.venv --exclude=third_party --exclude='checkpoints*' \
    -czf "../code_backups/v32_code_${stamp}.tar.gz" .

rm -rf /tmp/generals_v34
mkdir -p /tmp/generals_v34
unzip /path/to/generals_rl_bot_gx10_v3_4_heuristic_pipeline.zip \
      -d /tmp/generals_v34

rsync -a \
  /tmp/generals_v34/generals_rl_bot_gx10_v3_4_heuristic_pipeline/ \
  ./
```

The overlay does not contain `.venv`, `third_party`, or checkpoints, so those
remain untouched.

Activate and verify the environment:

```bash
source .venv/bin/activate
python -m pip install -e third_party/generals-bots
python -m pytest -q tests/test_action_codec.py tests/test_heuristic.py
```

## 2. Benchmark the heuristic before training

Run with no training process active:

```bash
GAMES=128 bash scripts/evaluate_heuristic.sh
```

Then confirm with more games:

```bash
GAMES=512 bash scripts/evaluate_heuristic.sh
```

The first invocation compiles JAX kernels. Judge the heuristic by wins, losses,
draws, and especially whether it produces decisive games on the full competition
map distribution.

The standalone stdio bot can be tested headlessly against an official baseline:

```bash
source .venv/bin/activate
python third_party/generals-bots/competition/matchup.py \
  heuristic_submission/run.sh \
  third_party/generals-bots/competition/agents/hunter_cpp/run.sh \
  --mode competition --seed 7
```

For a GUI, add `--gui`. Do not run a GUI or evaluation while GPU training is
active on the GX10.

## 3. Choose the initialization checkpoint

Use the checkpoint tournament already in progress. Prefer the strongest
pre-collapse checkpoint, not update 3000. Evaluate finalists with at least 256
games against both official agents.

Example:

```bash
GAMES=256 bash scripts/evaluate.sh checkpoints_v32/update_0001600.msgpack
GAMES=256 bash scripts/evaluate.sh checkpoints_v32/update_0001620.msgpack
```

Call the selected file `BEST_V32` in the commands below.

## 4. Run a tiny v3.4 smoke test

The complete smoke test performs one tiny update and heuristic evaluation:

```bash
bash scripts/smoke_test_v34.sh
```

A full smoke test still requires a working CUDA JAX installation and the
official environment. The first compilation can use substantial memory; do not
run other JAX processes simultaneously.

## 5. Start recovery training

Initialize weights from the selected checkpoint but use a fresh optimizer,
fresh EMA and fresh v3.4 update counter:

```bash
BEST_V32=checkpoints_v32/update_0001620.msgpack
mkdir -p checkpoints_v34_from_1620

CHECKPOINT_DIR=checkpoints_v34_from_1620 \
UPDATES=1200 \
bash scripts/train_v34_gx10.sh --init-from "$BEST_V32" \
  2>&1 | tee -a checkpoints_v34_from_1620/console.log
```

Replace `1620` with the checkpoint that actually wins the tournament.

Default v3.4 mix across 512 environments:

```text
25% current-policy self-play
35% heuristic opponent
20% Expander
20% Hunter
```

In self-play environments both seats train. In fixed-opponent environments one
alternating seat trains; the opponent seat is explicitly masked from policy,
value, entropy and behavior-cloning losses.

Default recovery map pool:

```text
75% exact competition distribution (minimum general distance 17)
25% bridge distribution (maximum BFS distance 28)
```

The behavior-cloning coefficient decays from `0.20` to `0.02` over 800 v3.4
updates. GAE lambda is `0.995`; potential shaping is enabled at scale `1.0`.

## 6. Logs and checkpoints

Metrics are written to:

```text
checkpoints_v34_from_1620/training_v34.csv
```

Follow them from a second SSH session:

```bash
tail -f checkpoints_v34_from_1620/training_v34.csv
```

Important console columns:

```text
term       true terminal rate
trunc      timeout rate
wins       all decisive games in the rollout
fixed=W-L  learner results in heuristic/Expander/Hunter games
bc_c       current imitation coefficient
bc         behavior-cloning cross-entropy
nent       normalized policy entropy
kl         PPO approximate KL
EV         value explained variance on learner-controlled transitions
```

The main success condition is not merely stable KL/EV. On the final mixed pool:

- `term` must remain clearly above zero;
- fixed-opponent wins and losses must occur regularly;
- truncation must not become the only completed outcome;
- the checkpoint must improve in external evaluation.

Stop and inspect if a 30-update moving average has almost no true terminations.
Do not allow another thousand updates with zero terminal reward.

## 7. Resume training

Resume only from a v3.4 checkpoint directory:

```bash
CHECKPOINT_DIR=checkpoints_v34_from_1620 \
UPDATES=1600 \
bash scripts/train_v34_gx10.sh \
  --resume checkpoints_v34_from_1620 \
  2>&1 | tee -a checkpoints_v34_from_1620/console.log
```

`UPDATES` is the final v3.4 update number, not the number of extra updates.

## 8. Evaluate v3.4 checkpoints

Stop training first:

```bash
GAMES=128 bash scripts/evaluate_v34.sh \
  checkpoints_v34_from_1620/update_0000200.msgpack
```

This evaluates against Expander, Hunter and the new heuristic. Confirm finalists
with 512–1000 games and multiple seeds.

Examples:

```bash
GAMES=512 bash scripts/evaluate_v34.sh \
  checkpoints_v34_from_1620/update_0000800.msgpack --opponent all --seed 100

GAMES=512 bash scripts/evaluate_v34.sh \
  checkpoints_v34_from_1620/update_0001000.msgpack --opponent all --seed 200
```

Select a checkpoint by external wins/draws and replay quality, not by update
number or training loss.

## 9. Deploy the standalone heuristic

Build its upload ZIP:

```bash
bash scripts/package_heuristic_submission.sh
```

This creates:

```text
generals_heuristic_submission.zip
```

The ZIP contains only `run.sh` and `main.py`, uses NumPy from the official
sandbox, has no network dependency, parses exact rectangular boards, and emits
one flushed action per observation.

Benchmark this submission independently. It is a useful fallback even if the
neural recovery is not ready.

## 10. Deploy a trained neural checkpoint

The model architecture is unchanged, so the existing exporter accepts v3.4
checkpoints:

```bash
bash scripts/export_submission.sh \
  checkpoints_v34_from_1620/update_0001000.msgpack
```

However, the previously observed Python-to-C++ policy-logit parity mismatch must
be resolved before trusting the neural submission ZIP. Do not ignore or loosen
the parity test merely to make export pass.

## 11. Useful controlled ablations

Change one item at a time and use separate checkpoint directories.

More teaching if exploration still fails:

```bash
BC_COEF=0.30 BC_FINAL_COEF=0.05 HEURISTIC_FRACTION=0.45 \
SELFPLAY_FRACTION=0.15 EXPANDER_FRACTION=0.20 HUNTER_FRACTION=0.20 \
CHECKPOINT_DIR=checkpoints_v34_more_teacher \
bash scripts/train_v34_gx10.sh --init-from "$BEST_V32"
```

More independent RL after the policy imitates the teacher:

```bash
BC_COEF=0.08 BC_FINAL_COEF=0.00 HEURISTIC_FRACTION=0.20 \
SELFPLAY_FRACTION=0.40 EXPANDER_FRACTION=0.20 HUNTER_FRACTION=0.20 \
CHECKPOINT_DIR=checkpoints_v34_more_selfplay \
bash scripts/train_v34_gx10.sh --init-from "$BEST_V32"
```

All four opponent fractions must sum to exactly `1.0`.

## 12. Files added by v3.4

```text
src/heuristic.py                 JAX heuristic/teacher/opponent
src/train_v34.py                 mixed-opponent PPO + online imitation
src/evaluate_v34.py              checkpoint vs three opponent types
src/evaluate_heuristic.py        heuristic vs official baselines
heuristic_submission/main.py     stateful stdio competition bot
heuristic_submission/run.sh
scripts/train_v34_gx10.sh
scripts/evaluate_v34.sh
scripts/evaluate_heuristic.sh
scripts/watch_heuristic.sh
scripts/package_heuristic_submission.sh
scripts/smoke_test_v34.sh
tests/test_heuristic.py
```

## Validation status

Completed here:

- Python syntax compilation for all new modules;
- JAX `jit` and action-codec unit tests for the heuristic;
- synthetic stdio protocol test for the standalone submission;
- static inspection of learner/opponent masks and checkpoint compatibility.

Still required on the GX10:

- a one-update smoke run with the installed official `generals-bots` version;
- throughput measurement;
- full heuristic benchmark;
- external checkpoint tournament;
- neural C++ parity repair before neural submission.
