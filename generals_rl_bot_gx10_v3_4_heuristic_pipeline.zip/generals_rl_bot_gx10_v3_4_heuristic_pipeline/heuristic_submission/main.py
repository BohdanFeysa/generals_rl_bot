#!/usr/bin/env python3
from __future__ import annotations

import sys
from collections import Counter, deque

import numpy as np


DIRS = ((-1, 0), (1, 0), (0, -1), (0, 1))
FOG, PLAIN, MOUNTAIN, CASTLE, GENERAL, STRUCTURE_FOG = range(6)
NEUTRAL, ME, OPP = 0, 1, 2


class Agent:
    def __init__(self, height: int, width: int):
        self.h = height
        self.w = width
        self.visit_count = np.zeros((height, width), dtype=np.int32)
        self.recent_edges: deque[tuple[int, int, int, int]] = deque(maxlen=48)
        self.general: tuple[int, int] | None = None
        self.last_fog = height * width
        self.stagnation = 0

    def neighbours(self, r: int, c: int):
        for d, (dr, dc) in enumerate(DIRS):
            rr, cc = r + dr, c + dc
            if 0 <= rr < self.h and 0 <= cc < self.w:
                yield d, rr, cc

    def information(self, types: np.ndarray) -> np.ndarray:
        fog = types == FOG
        result = np.zeros_like(types, dtype=np.int32)
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                src_r0, src_r1 = max(0, -dr), min(self.h, self.h - dr)
                src_c0, src_c1 = max(0, -dc), min(self.w, self.w - dc)
                dst_r0, dst_r1 = src_r0 + dr, src_r1 + dr
                dst_c0, dst_c1 = src_c0 + dc, src_c1 + dc
                result[dst_r0:dst_r1, dst_c0:dst_c1] += fog[
                    src_r0:src_r1, src_c0:src_c1
                ]
        return result

    def choose(self, turn: int, owners: np.ndarray, types: np.ndarray, armies: np.ndarray):
        visible = types != FOG
        self.visit_count[visible] += 1
        fog_count = int(np.sum(types == FOG))
        if fog_count < self.last_fog:
            self.stagnation = 0
        else:
            self.stagnation += 1
        self.last_fog = fog_count

        own_general_cells = np.argwhere((types == GENERAL) & (owners == ME))
        if len(own_general_cells):
            self.general = tuple(map(int, own_general_cells[0]))

        info = self.information(types)
        own = owners == ME
        opponent = owners == OPP
        movable = own & (armies > 1)
        recent = Counter(self.recent_edges)

        phase = (turn // 50) % 4
        def sector(r: int, c: int) -> float:
            if phase == 0:
                return -r
            if phase == 1:
                return c
            if phase == 2:
                return r
            return -c

        frontier_candidates: list[tuple[float, int, int]] = []
        for r in range(self.h):
            for c in range(self.w):
                if types[r, c] == MOUNTAIN or own[r, c]:
                    continue
                if any(own[rr, cc] for _, rr, cc in self.neighbours(r, c)):
                    base = 1000.0 if types[r, c] == FOG else 700.0
                    if opponent[r, c]:
                        base += 20_000.0 + 40.0 * armies[r, c]
                    frontier_candidates.append(
                        (base + 70.0 * info[r, c] + 4.0 * sector(r, c), r, c)
                    )

        enemy_generals = np.argwhere((types == GENERAL) & opponent)
        enemy_cells = np.argwhere(opponent)
        if len(enemy_generals):
            goal = tuple(map(int, enemy_generals[0]))
        elif len(enemy_cells):
            best = max(enemy_cells, key=lambda x: int(armies[tuple(x)]))
            goal = tuple(map(int, best))
        elif frontier_candidates:
            _, gr, gc = max(frontier_candidates)
            goal = (gr, gc)
        elif self.general is not None:
            # Search the farthest still-foggy region compatible with distant spawns.
            gr0, gc0 = self.general
            candidates = np.argwhere(types == FOG)
            if len(candidates):
                best = max(
                    candidates,
                    key=lambda x: abs(int(x[0]) - gr0)
                    + abs(int(x[1]) - gc0)
                    + 0.2 * info[tuple(x)],
                )
                goal = tuple(map(int, best))
            else:
                goal = self.general
        else:
            goal = (self.h // 2, self.w // 2)

        danger = False
        threat = None
        if self.general is not None and len(enemy_cells):
            gr, gc = self.general
            scored = []
            for r, c in enemy_cells:
                dist = abs(int(r) - gr) + abs(int(c) - gc)
                scored.append((int(armies[r, c]) - 2 * dist, dist, int(r), int(c)))
            strength, distance, tr, tc = max(scored)
            general_army = int(armies[gr, gc])
            danger = distance <= 5 or strength >= 0.6 * general_army
            threat = (tr, tc)

        best_score = -1e100
        best_action = None
        owned_land = int(np.sum(own))

        for r in range(self.h):
            for c in range(self.w):
                if not movable[r, c]:
                    continue
                source_army = int(armies[r, c])
                source_general = self.general == (r, c)
                if owned_land <= 2 and source_general and source_army < 11:
                    continue
                for d, rr, cc in self.neighbours(r, c):
                    if types[rr, cc] == MOUNTAIN:
                        continue
                    target_army = int(armies[rr, cc])
                    is_enemy_general = types[rr, cc] == GENERAL and opponent[rr, cc]
                    can_capture = source_army - 1 > target_army or turn >= 800
                    if is_enemy_general and can_capture:
                        score = 1_000_000.0
                    elif opponent[rr, cc]:
                        score = 20_000.0 + 35.0 * (source_army - 1 - target_army)
                        if not can_capture:
                            score -= 25_000.0
                    elif types[rr, cc] in (FOG, STRUCTURE_FOG):
                        score = 620.0 + 48.0 * info[rr, cc]
                    elif owners[rr, cc] == NEUTRAL:
                        score = 440.0 + 28.0 * info[rr, cc]
                        if source_army - 1 <= target_army:
                            score -= 1000.0
                    else:
                        before = abs(r - goal[0]) + abs(c - goal[1])
                        after = abs(rr - goal[0]) + abs(cc - goal[1])
                        progress = before - after
                        score = 230.0 * progress + 3.0 * source_army
                        if progress <= 0:
                            score -= 180.0

                    score += 2.0 * np.log1p(source_army)
                    score += 0.4 * sector(rr, cc)
                    score -= 3.0 * self.visit_count[rr, cc]

                    edge = (r, c, rr, cc)
                    reverse = (rr, cc, r, c)
                    score -= 90.0 * recent[edge]
                    score -= 180.0 * recent[reverse]
                    if self.stagnation >= 16 and types[rr, cc] in (FOG, STRUCTURE_FOG):
                        score += 900.0

                    if danger and threat is not None:
                        before = abs(r - threat[0]) + abs(c - threat[1])
                        after = abs(rr - threat[0]) + abs(cc - threat[1])
                        if after < before:
                            score += 420.0

                    if source_general and turn >= 80 and not is_enemy_general:
                        score -= 900.0

                    split = 0
                    frontier_degree = sum(
                        types[nr, nc] in (FOG, STRUCTURE_FOG, PLAIN, CASTLE)
                        and owners[nr, nc] != ME
                        for _, nr, nc in self.neighbours(r, c)
                    )
                    if (
                        not opponent[rr, cc]
                        and not is_enemy_general
                        and (
                            (source_general and turn >= 50)
                            or (source_army >= 18 and frontier_degree >= 2)
                        )
                    ):
                        split = 1

                    if score > best_score:
                        best_score = score
                        best_action = (0, r, c, d, split, rr, cc)

        if best_action is None:
            return (1, 0, 0, 0, 0)

        kind, r, c, d, split, rr, cc = best_action
        self.recent_edges.append((r, c, rr, cc))
        return (kind, r, c, d, split)


def read_grid(stream, h: int, w: int):
    rows = []
    for _ in range(h):
        line = stream.readline()
        if not line:
            raise EOFError
        row = list(map(int, line.split()))
        if len(row) != w:
            raise ValueError(f"expected {w} entries, got {len(row)}")
        rows.append(row)
    return np.asarray(rows, dtype=np.int32)


def main() -> None:
    first = sys.stdin.readline()
    if not first:
        return
    _player_id, h, w = map(int, first.split())
    agent = Agent(h, w)

    while True:
        scalar_line = sys.stdin.readline()
        if not scalar_line:
            break
        turn, _my_land, _my_army, _opp_land, _opp_army = map(int, scalar_line.split())
        try:
            types = read_grid(sys.stdin, h, w)
            owners = read_grid(sys.stdin, h, w)
            armies = read_grid(sys.stdin, h, w)
        except EOFError:
            break
        action = agent.choose(turn, owners, types, armies)
        sys.stdout.write("%d %d %d %d %d\n" % action)
        sys.stdout.flush()


if __name__ == "__main__":
    main()
