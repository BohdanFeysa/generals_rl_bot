from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def frame(army: int, turn: int) -> str:
    h = w = 5
    types = [[0] * w for _ in range(h)]
    owners = [[0] * w for _ in range(h)]
    armies = [[0] * w for _ in range(h)]
    types[2][2] = 4
    owners[2][2] = 1
    armies[2][2] = army
    lines = [f"{turn} 1 {army} 1 1"]
    for grid in (types, owners, armies):
        lines.extend(" ".join(map(str, row)) for row in grid)
    return "\n".join(lines) + "\n"


def test_submission_waits_then_moves():
    root = Path(__file__).resolve().parents[1]
    data = "0 5 5\n" + frame(5, 0) + frame(12, 12)
    proc = subprocess.run(
        [sys.executable, str(root / "heuristic_submission" / "main.py")],
        input=data,
        text=True,
        capture_output=True,
        check=True,
    )
    lines = proc.stdout.strip().splitlines()
    assert lines[0].startswith("1 ")
    assert lines[1].startswith("0 ")
