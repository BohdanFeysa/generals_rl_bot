from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp

from src.actions import PASS_INDEX
from src.heuristic import heuristic_action_index


class Obs(NamedTuple):
    armies: jnp.ndarray
    generals: jnp.ndarray
    castles: jnp.ndarray
    mountains: jnp.ndarray
    neutral_cells: jnp.ndarray
    owned_cells: jnp.ndarray
    opponent_cells: jnp.ndarray
    fog_cells: jnp.ndarray
    structures_in_fog: jnp.ndarray
    owned_land_count: jnp.ndarray
    owned_army_count: jnp.ndarray
    opponent_land_count: jnp.ndarray
    opponent_army_count: jnp.ndarray
    timestep: jnp.ndarray


def make_obs(army: int, timestep: int = 0) -> Obs:
    z = jnp.zeros((21, 21), dtype=jnp.bool_)
    armies = jnp.zeros((21, 21), dtype=jnp.int32).at[10, 10].set(army)
    owned = z.at[10, 10].set(True)
    general = z.at[10, 10].set(True)
    fog = jnp.ones((21, 21), dtype=jnp.bool_).at[10, 10].set(False)
    mountains = z.at[0, :].set(True)
    return Obs(
        armies=armies,
        generals=general,
        castles=z,
        mountains=mountains,
        neutral_cells=~fog & ~owned & ~mountains,
        owned_cells=owned,
        opponent_cells=z,
        fog_cells=fog,
        structures_in_fog=z,
        owned_land_count=jnp.asarray(1),
        owned_army_count=jnp.asarray(army),
        opponent_land_count=jnp.asarray(1),
        opponent_army_count=jnp.asarray(1),
        timestep=jnp.asarray(timestep),
    )


def test_opening_waits_then_moves():
    key = jax.random.PRNGKey(0)
    assert int(heuristic_action_index(make_obs(5), key)) == PASS_INDEX
    assert int(heuristic_action_index(make_obs(12), key)) != PASS_INDEX


def test_jit_and_vmap():
    key = jax.random.PRNGKey(1)
    action = jax.jit(heuristic_action_index)(make_obs(12), key)
    assert action.shape == ()
