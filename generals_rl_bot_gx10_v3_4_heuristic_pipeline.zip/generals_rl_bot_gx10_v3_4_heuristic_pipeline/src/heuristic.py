from __future__ import annotations

"""JAX-compatible competition heuristic used as a bot, opponent and teacher.

The policy is deliberately compact and stateless so it can be vmapped/jitted in
training.  It implements the most robust programmable ideas from strong human
1v1 play: wait for an opening stack, explore several flanks, prefer information
and enemy land, gather armies toward the current objective, protect the general,
and never pass when a productive move exists.
"""

from typing import NamedTuple

import jax
import jax.numpy as jnp

from .actions import BOARD, PASS_INDEX, action_index_to_env


class HeuristicWeights(NamedTuple):
    opening_release: float = 11.0
    capture_general: float = 1_000_000.0
    attack_enemy: float = 20_000.0
    explore_fog: float = 620.0
    expand_neutral: float = 440.0
    information: float = 42.0
    gather_progress: float = 230.0
    source_army: float = 2.0
    danger_defense: float = 380.0
    general_move_penalty: float = 900.0
    reverse_direction_bias: float = 8.0
    build_base: float = 360.0


DEFAULT_WEIGHTS = HeuristicWeights()
_ROWS, _COLS = jnp.meshgrid(
    jnp.arange(BOARD, dtype=jnp.float32),
    jnp.arange(BOARD, dtype=jnp.float32),
    indexing="ij",
)
_DIR_DR = jnp.asarray([-1, 1, 0, 0], dtype=jnp.int32)
_DIR_DC = jnp.asarray([0, 0, -1, 1], dtype=jnp.int32)


def _shift_to_source(grid: jnp.ndarray) -> jnp.ndarray:
    """For every source cell, return the property at each direction's target."""
    pad = ((1, 1), (1, 1))
    x = jnp.pad(grid, pad)
    # Source (r,c) targets: up/down/left/right in the padded grid.
    up = x[0:BOARD, 1 : BOARD + 1]
    down = x[2 : BOARD + 2, 1 : BOARD + 1]
    left = x[1 : BOARD + 1, 0:BOARD]
    right = x[1 : BOARD + 1, 2 : BOARD + 2]
    return jnp.stack([up, down, left, right], axis=-1)


def _neighbor_sum(mask: jnp.ndarray) -> jnp.ndarray:
    """Eight-neighbour count, used as a cheap information-gain estimate."""
    x = jnp.pad(mask.astype(jnp.float32), ((1, 1), (1, 1)))
    total = jnp.zeros((BOARD, BOARD), dtype=jnp.float32)
    for dr in range(3):
        for dc in range(3):
            if dr == 1 and dc == 1:
                continue
            total = total + x[dr : dr + BOARD, dc : dc + BOARD]
    return total


def _safe_argmax(mask: jnp.ndarray, score: jnp.ndarray) -> jnp.ndarray:
    masked = jnp.where(mask, score, -1.0e30)
    return jnp.argmax(masked.reshape(-1)).astype(jnp.int32)


def heuristic_action_index(
    obs,
    key: jnp.ndarray,
    weights: HeuristicWeights = DEFAULT_WEIGHTS,
) -> jnp.ndarray:
    """Choose one flattened action for an unbatched official Observation.

    The function contains no Python data-dependent branches and is safe under
    ``jax.jit`` and ``jax.vmap``.
    """
    armies = obs.armies.astype(jnp.float32)
    owned = obs.owned_cells.astype(jnp.bool_)
    opponent = obs.opponent_cells.astype(jnp.bool_)
    neutral = obs.neutral_cells.astype(jnp.bool_)
    fog = obs.fog_cells.astype(jnp.bool_)
    generals = obs.generals.astype(jnp.bool_)
    castles = obs.castles.astype(jnp.bool_)
    mountains = obs.mountains.astype(jnp.bool_)
    timestep = obs.timestep.astype(jnp.float32)

    dest_army = _shift_to_source(armies)
    dest_owned = _shift_to_source(owned)
    dest_opponent = _shift_to_source(opponent)
    dest_neutral = _shift_to_source(neutral)
    dest_fog = _shift_to_source(fog)
    dest_general = _shift_to_source(generals)
    dest_mountain = _shift_to_source(mountains)
    dest_r_int = jnp.arange(BOARD, dtype=jnp.int32)[:, None, None] + _DIR_DR
    dest_c_int = jnp.arange(BOARD, dtype=jnp.int32)[None, :, None] + _DIR_DC
    in_bounds = (
        (dest_r_int >= 0)
        & (dest_r_int < BOARD)
        & (dest_c_int >= 0)
        & (dest_c_int < BOARD)
    )
    move_legal = owned[..., None] & (armies[..., None] > 1.0) & in_bounds & ~dest_mountain

    info_grid = _neighbor_sum(fog)
    dest_information = _shift_to_source(info_grid)

    own_general = generals & owned
    has_general = jnp.any(own_general)
    general_flat = jnp.argmax(own_general.reshape(-1)).astype(jnp.int32)
    gr = (general_flat // BOARD).astype(jnp.float32)
    gc = (general_flat % BOARD).astype(jnp.float32)
    general_army = jnp.max(jnp.where(own_general, armies, 0.0))

    # Rotate the preferred exploration flank every two growth rounds. This is a
    # stateless anti-tunnel mechanism: the bot does not extend only one corridor.
    phase = (obs.timestep.astype(jnp.int32) // 50) % 4
    dest_r = _ROWS[..., None] + _DIR_DR.astype(jnp.float32)
    dest_c = _COLS[..., None] + _DIR_DC.astype(jnp.float32)
    sector_bias = jnp.select(
        [phase == 0, phase == 1, phase == 2],
        [-dest_r, dest_c, dest_r],
        default=-dest_c,
    )
    sector_bias = weights.reverse_direction_bias * sector_bias / float(BOARD)

    source_army = armies[..., None]
    movable = jnp.maximum(source_army - 1.0, 0.0)
    full_capture = movable > dest_army
    deathtouch = timestep >= 800.0
    enemy_general = dest_general & dest_opponent
    can_take_general = enemy_general & (full_capture | deathtouch)

    # Enemy stack threatening our general. Distances are visible-information
    # only; this is intentionally conservative under fog.
    dist_to_general = jnp.abs(_ROWS - gr) + jnp.abs(_COLS - gc)
    threat_grid = jnp.where(
        opponent,
        armies - 2.0 * dist_to_general,
        -1.0e6,
    )
    threat_flat = jnp.argmax(threat_grid.reshape(-1)).astype(jnp.int32)
    tr = (threat_flat // BOARD).astype(jnp.float32)
    tc = (threat_flat % BOARD).astype(jnp.float32)
    threat_strength = jnp.max(threat_grid)
    threat_distance = jnp.abs(tr - gr) + jnp.abs(tc - gc)
    danger = has_general & jnp.any(opponent) & (
        (threat_distance <= 5.0) | (threat_strength >= 0.6 * general_army)
    )

    # Pick a global objective. Visible enemy cells dominate. Otherwise choose an
    # owned frontier destination that reveals much fog and lies in the rotating
    # preferred sector. The score is defined on destination cells.
    adjacent_owned = _neighbor_sum(owned) > 0.0
    possible_enemy_spawn = fog & has_general & (dist_to_general >= 17.0)
    cell_sector = jnp.select(
        [phase == 0, phase == 1, phase == 2],
        [-_ROWS, _COLS, _ROWS],
        default=-_COLS,
    )
    objective_score = (
        jnp.where(generals & opponent, 1.0e7, 0.0)
        + jnp.where(opponent, 1.0e6 + armies * 50.0, 0.0)
        + jnp.where(fog & adjacent_owned, 20_000.0 + info_grid * 500.0, 0.0)
        + jnp.where(neutral & adjacent_owned, 10_000.0 + info_grid * 250.0, 0.0)
        + jnp.where(possible_enemy_spawn, 750.0, 0.0)
        + 10.0 * cell_sector
        - jnp.where(mountains, 1.0e9, 0.0)
    )
    objective_flat = jnp.argmax(objective_score.reshape(-1)).astype(jnp.int32)
    goal_r = (objective_flat // BOARD).astype(jnp.float32)
    goal_c = (objective_flat % BOARD).astype(jnp.float32)
    dist_source_goal = jnp.abs(_ROWS - goal_r) + jnp.abs(_COLS - goal_c)
    dist_dest_goal = jnp.abs(dest_r - goal_r) + jnp.abs(dest_c - goal_c)
    gather_progress = dist_source_goal[..., None] - dist_dest_goal

    # Main move score. Non-owned destinations are strongly preferred; owned
    # moves are allowed only when they gather a real stack toward the objective.
    score = jnp.zeros((BOARD, BOARD, 4), dtype=jnp.float32)
    score = score + weights.source_army * jnp.log1p(source_army)
    score = score + sector_bias
    score = score + jnp.where(
        dest_fog,
        weights.explore_fog + weights.information * dest_information,
        0.0,
    )
    score = score + jnp.where(
        dest_neutral,
        weights.expand_neutral + 0.5 * weights.information * dest_information,
        0.0,
    )
    score = score + jnp.where(
        dest_opponent,
        weights.attack_enemy + 30.0 * (movable - dest_army),
        0.0,
    )
    score = score + jnp.where(
        dest_owned & (gather_progress > 0.0),
        weights.gather_progress * gather_progress + 3.0 * source_army,
        -120.0 * dest_owned,
    )

    # Emergency reinforcement/interception gets priority over routine expansion.
    dist_source_threat = jnp.abs(_ROWS - tr) + jnp.abs(_COLS - tc)
    dist_dest_threat = jnp.abs(dest_r - tr) + jnp.abs(dest_c - tc)
    defense_progress = dist_source_threat[..., None] - dist_dest_threat
    score = score + jnp.where(
        danger & (defense_progress > 0.0),
        weights.danger_defense * defense_progress + 2.0 * source_army,
        0.0,
    )

    # Opening: wait for a useful stack before the first move from the general.
    opening = obs.owned_land_count.astype(jnp.int32) <= 2
    opening_not_ready = opening & (general_army < weights.opening_release)
    source_is_general = own_general[..., None]
    score = score - jnp.where(source_is_general & opening_not_ready, 1.0e8, 0.0)

    # Later, avoid draining the general unless we are capturing, expanding from a
    # trapped spawn, or no other meaningful move exists. A split move is selected
    # below when the general itself must move.
    late_general_penalty = source_is_general & (timestep >= 80.0) & ~can_take_general
    score = score - jnp.where(late_general_penalty, weights.general_move_penalty, 0.0)

    score = score + jnp.where(can_take_general, weights.capture_general, 0.0)
    score = jnp.where(move_legal, score, -1.0e30)

    # Tiny deterministic random noise breaks symmetric ties without changing the
    # strategy. This matters in self-play and keeps vmapped agents diverse.
    noise = jax.random.uniform(key, score.shape, minval=0.0, maxval=1.0e-3)
    score = score + noise

    best_move_flat = jnp.argmax(score.reshape(-1)).astype(jnp.int32)
    best_move_score = jnp.max(score)
    move_cell = best_move_flat // 4
    move_dir = best_move_flat % 4
    move_row = move_cell // BOARD
    move_col = move_cell % BOARD

    selected_source_army = armies[move_row, move_col]
    selected_source_general = own_general[move_row, move_col]
    selected_dest_fog = dest_fog[move_row, move_col, move_dir]
    selected_dest_neutral = dest_neutral[move_row, move_col, move_dir]
    selected_dest_opponent = dest_opponent[move_row, move_col, move_dir]
    selected_enemy_general = enemy_general[move_row, move_col, move_dir]
    frontier_degree = jnp.sum(
        (dest_fog | dest_neutral)[move_row, move_col].astype(jnp.int32)
    )
    use_split = (
        (selected_source_general & (timestep >= 50.0))
        | (
            (selected_source_army >= 18.0)
            & (frontier_degree >= 2)
            & (selected_dest_fog | selected_dest_neutral)
        )
    ) & ~selected_dest_opponent & ~selected_enemy_general
    move_index = (((move_row * BOARD + move_col) * 4 + move_dir) * 2 + use_split.astype(jnp.int32))

    # Passing is used only while waiting for the opening stack or when no legal
    # move exists. The teacher intentionally does not build castles: expansion,
    # gathering and combat are the skills needed to repair the sparse-reward run.
    pass_score = jnp.where(opening_not_ready, 0.0, -500.0)
    chosen = jnp.where(pass_score >= best_move_score, PASS_INDEX, move_index)
    return chosen.astype(jnp.int32)


def heuristic_action(obs, key: jnp.ndarray) -> jnp.ndarray:
    return action_index_to_env(heuristic_action_index(obs, key))


class HeuristicAgent:
    """Drop-in official-agent interface: ``act(observation, key)``."""

    def act(self, observation, key: jnp.ndarray) -> jnp.ndarray:
        return heuristic_action(observation, key)
