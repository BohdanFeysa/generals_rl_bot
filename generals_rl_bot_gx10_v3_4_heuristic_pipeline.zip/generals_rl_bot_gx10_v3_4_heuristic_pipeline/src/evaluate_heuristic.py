from __future__ import annotations

import argparse

import jax
import jax.numpy as jnp

from generals import GeneralsEnv
from generals.agents import ExpanderAgent, HunterAgent
from generals.core import game

from .heuristic import HeuristicAgent


def stack_player_observations(state):
    p0 = game.get_observation(state, 0)
    p1 = game.get_observation(state, 1)
    return jax.tree.map(lambda a, b: jnp.stack([a, b], axis=0), p0, p1)


def select_seat(tree, seat):
    n = seat.shape[0]
    return jax.tree.map(lambda x: x[jnp.arange(n), seat], tree)


def evaluate(opponent_name: str, games: int, seed: int) -> tuple[int, int, int]:
    learner = HeuristicAgent()
    opponent = ExpanderAgent() if opponent_name == "expander" else HunterAgent()
    env = GeneralsEnv(mode="competition", pool_size=max(games, 256))
    key = jax.random.PRNGKey(seed)
    key, pool_key = jax.random.split(key)
    pool, _ = env.reset(pool_key)
    idx = jnp.arange(games, dtype=jnp.int32) % env.pool_size
    states = jax.tree.map(lambda x: x[idx], pool)._replace(pool_idx=idx)

    get_obs = jax.jit(jax.vmap(stack_player_observations))
    step_batch = jax.jit(jax.vmap(lambda s, a: env.step(s, a, pool)))
    learner_act = jax.jit(jax.vmap(learner.act))
    opponent_act = jax.jit(jax.vmap(opponent.act))

    seat = jnp.arange(games, dtype=jnp.int32) % 2
    other = 1 - seat
    obs = get_obs(states)
    finished = jnp.zeros((games,), dtype=jnp.bool_)
    wins = jnp.zeros((games,), dtype=jnp.bool_)
    losses = jnp.zeros((games,), dtype=jnp.bool_)

    for _turn in range(1200):
        learner_obs = select_seat(obs, seat)
        opp_obs = select_seat(obs, other)
        key, k1, k2 = jax.random.split(key, 3)
        learner_actions = learner_act(learner_obs, jax.random.split(k1, games))
        opponent_actions = opponent_act(opp_obs, jax.random.split(k2, games))
        actions = jnp.zeros((games, 2, 5), dtype=jnp.int32)
        actions = actions.at[jnp.arange(games), seat].set(learner_actions)
        actions = actions.at[jnp.arange(games), other].set(opponent_actions)
        timestep, states = step_batch(states, actions)
        just_finished = (~finished) & (timestep.terminated | timestep.truncated)
        wins = wins | (just_finished & (timestep.info.winner == seat))
        losses = losses | (just_finished & (timestep.info.winner == other))
        finished = finished | just_finished
        obs = timestep.observation
        if bool(jnp.all(finished)):
            break

    wins_n = int(jnp.sum(wins))
    losses_n = int(jnp.sum(losses))
    draws_n = games - wins_n - losses_n
    print(
        f"heuristic vs {opponent_name}: games={games} wins={wins_n} "
        f"losses={losses_n} draws={draws_n} win_rate={wins_n / games:.3f}"
    )
    return wins_n, losses_n, draws_n


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--opponent", choices=["expander", "hunter", "both"], default="both")
    p.add_argument("--games", type=int, default=256)
    p.add_argument("--seed", type=int, default=2026)
    args = p.parse_args()
    names = ["expander", "hunter"] if args.opponent == "both" else [args.opponent]
    for i, name in enumerate(names):
        evaluate(name, args.games, args.seed + i)


if __name__ == "__main__":
    main()
