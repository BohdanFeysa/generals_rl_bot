from __future__ import annotations

import argparse
import csv
import math
import os
import time
from pathlib import Path
from typing import NamedTuple

# Must be set before JAX initializes the GPU allocator.
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.85")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "true")

import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax.training.train_state import TrainState

from generals import GeneralsEnv
from generals.agents import ExpanderAgent, HunterAgent
from generals.core import game

from .actions import (
    action_index_to_env,
    env_action_to_index,
    mask_logits,
    valid_action_mask,
)
from .checkpoint import load_checkpoint, load_params_only, save_checkpoint
from .config import ModelConfig, TrainConfig, save_config
from .heuristic import heuristic_action, heuristic_action_index
from .model import ActorCritic, encode_observation


# The final stage switches to the exact competition spawn distribution.
# Before that, maps cap the maximum BFS distance so sparse terminal rewards are
# frequent enough for a random policy to bootstrap, as described in the 2026
# Generals.io self-play paper.
SPAWN_MAX_DISTANCE_STAGES: tuple[int | None, ...] = (
    4,
    6,
    8,
    10,
    12,
    14,
    17,
    20,
    24,
    28,
    None,
)


class Transition(NamedTuple):
    obs: object
    hidden: jnp.ndarray
    action: jnp.ndarray
    old_logprob: jnp.ndarray
    old_value: jnp.ndarray
    reward: jnp.ndarray
    raw_reward: jnp.ndarray
    teacher_action: jnp.ndarray
    control_mask: jnp.ndarray
    terminated: jnp.ndarray
    truncated: jnp.ndarray
    done: jnp.ndarray


class RolloutCarry(NamedTuple):
    states: object
    obs: object
    hidden: jnp.ndarray
    key: jnp.ndarray


class ChunkBatch(NamedTuple):
    obs: object
    hidden0: jnp.ndarray
    action: jnp.ndarray
    old_logprob: jnp.ndarray
    old_value: jnp.ndarray
    advantage: jnp.ndarray
    returns: jnp.ndarray
    done: jnp.ndarray
    policy_mask: jnp.ndarray
    teacher_action: jnp.ndarray
    control_mask: jnp.ndarray


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="v3.4 recurrent PPO with heuristic teaching and mixed opponents"
    )
    p.add_argument("--num-envs", type=int, default=512)
    p.add_argument("--pool-size", type=int, default=4096)
    p.add_argument("--rollout-length", type=int, default=512)
    p.add_argument("--updates", type=int, default=3000)
    p.add_argument("--bptt-length", type=int, default=32)
    p.add_argument("--minibatch-sequences", type=int, default=128)
    p.add_argument("--ppo-epochs", type=int, default=1)
    p.add_argument("--top-advantage-fraction", type=float, default=1.0)
    p.add_argument("--gae-lambda", type=float, default=0.995)
    p.add_argument("--shaping-scale", type=float, default=1.0)
    p.add_argument("--bc-coef", type=float, default=0.20)
    p.add_argument("--bc-final-coef", type=float, default=0.02)
    p.add_argument("--bc-decay-updates", type=int, default=800)
    p.add_argument("--selfplay-fraction", type=float, default=0.25)
    p.add_argument("--heuristic-fraction", type=float, default=0.35)
    p.add_argument("--expander-fraction", type=float, default=0.20)
    p.add_argument("--hunter-fraction", type=float, default=0.20)
    p.add_argument("--ema-decay", type=float, default=0.999)
    p.add_argument("--spawn-curriculum-updates", type=int, default=1800)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--checkpoint-dir", default="checkpoints_v3")
    p.add_argument(
        "--resume",
        default=None,
        help="Resume a v3 checkpoint file or directory containing latest.json",
    )
    p.add_argument(
        "--init-from",
        default=None,
        help=(
            "Initialize model parameters from any compatible checkpoint but start "
            "with a fresh optimizer/EMA. Normally leave unset after a failed run."
        ),
    )
    p.add_argument("--float32", action="store_true", help="Disable bfloat16 activations")
    return p.parse_args()


def stack_player_observations(state):
    p0 = game.get_observation(state, 0)
    p1 = game.get_observation(state, 1)
    return jax.tree.map(lambda a, b: jnp.stack([a, b], axis=0), p0, p1)


def flatten_players(tree):
    return jax.tree.map(
        lambda x: x.reshape((x.shape[0] * x.shape[1],) + x.shape[2:]),
        tree,
    )


def select_seat(tree, seat: jnp.ndarray):
    """Select a different player observation for every environment."""
    n = seat.shape[0]
    return jax.tree.map(lambda x: x[jnp.arange(n), seat], tree)


def make_competition_env(pool_size: int, max_spawn_distance: int | None) -> GeneralsEnv:
    """Competition rules with an optional curriculum cap on general distance.

    mode="competition" cannot be used here because the named preset is
    authoritative and would overwrite max_generals_distance. These values mirror
    the current official competition preset; only the spawn-distance constraint is
    changed during curriculum stages.
    """
    if max_spawn_distance is None:
        min_distance = 17
        max_distance = None
    else:
        # The published curriculum caps the maximum distance, beginning at four.
        # A low minimum preserves a mixture of easy distances inside each stage.
        min_distance = 2
        max_distance = max_spawn_distance

    return GeneralsEnv(
        min_grid_size=18,
        max_grid_size=21,
        pad_to=21,
        truncation=1200,
        perfect_info=False,
        mountain_density_range=(0.24, 0.26),
        num_castles_range=(9, 11),
        min_generals_distance=min_distance,
        max_generals_distance=max_distance,
        pool_size=pool_size,
        castle_val_range=(20, 26),
        build_castles=True,
        deathtouch_turn=800,
    )


def spawn_stage(update: int, curriculum_updates: int) -> tuple[int, int | None]:
    # Reserve the final None stage for updates strictly after the distance
    # curriculum. The previous implementation multiplied by all 11 stages, so
    # competition began at update ~1638 even when curriculum_updates was 1800.
    final_idx = len(SPAWN_MAX_DISTANCE_STAGES) - 1
    if curriculum_updates <= 0 or update > curriculum_updates:
        return final_idx, None
    distance_stage_count = final_idx
    progress = min(max((update - 1) / max(curriculum_updates, 1), 0.0), 0.999999)
    idx = min(int(progress * distance_stage_count), distance_stage_count - 1)
    return idx, SPAWN_MAX_DISTANCE_STAGES[idx]


def stage_label(max_distance: int | None) -> str:
    return "mixed(75%competition+25%max_bfs=28)" if max_distance is None else f"max_bfs={max_distance}"


def player_potential(obs) -> jnp.ndarray:
    """Small potential used only for potential-difference shaping.

    With gamma=1 and terminal potential forced to zero, the shaped episodic
    return differs from the original terminal return only by the initial-state
    potential. This provides local learning signal without changing the game's
    win/loss objective.
    """
    owned_land = obs.owned_land_count.astype(jnp.float32)
    opponent_land = obs.opponent_land_count.astype(jnp.float32)
    owned_army = obs.owned_army_count.astype(jnp.float32)
    opponent_army = obs.opponent_army_count.astype(jnp.float32)
    land_diff = (owned_land - opponent_land) / 441.0
    army_diff = jnp.tanh((jnp.log1p(owned_army) - jnp.log1p(opponent_army)) / 4.0)
    explored = 1.0 - jnp.mean(obs.fog_cells.astype(jnp.float32), axis=(-2, -1))
    return 0.20 * land_diff + 0.05 * army_diff + 0.05 * explored


def learning_rate_for_iteration(cfg: TrainConfig, iteration: jnp.ndarray) -> jnp.ndarray:
    raw = cfg.learning_rate_scale * jnp.power(iteration + 1.0, -cfg.learning_rate_power)
    return jnp.clip(raw, cfg.min_learning_rate, cfg.max_learning_rate)


def entropy_for_iteration(cfg: TrainConfig, iteration: int) -> float:
    # Keep strong exploration pressure throughout the first nearby-spawn stage.
    # The compact CNN+GRU collapses prematurely when this coefficient decays from
    # update one, especially together with top-advantage filtering.
    if iteration < cfg.entropy_warmup_updates:
        return float(cfg.entropy_scale)

    decay_iteration = iteration - cfg.entropy_warmup_updates + 1
    decayed = cfg.entropy_scale * math.pow(
        float(decay_iteration),
        -cfg.entropy_power,
    )
    return float(max(cfg.min_entropy_coef, decayed))


def bc_for_iteration(cfg: TrainConfig, iteration: int) -> float:
    """Linear decay from teacher imitation to mostly-RL fine tuning."""
    if cfg.bc_decay_updates <= 0:
        return float(cfg.bc_final_coef)
    progress = min(max(iteration / float(cfg.bc_decay_updates), 0.0), 1.0)
    return float(cfg.bc_coef + progress * (cfg.bc_final_coef - cfg.bc_coef))


def make_optimizer(cfg: TrainConfig) -> optax.GradientTransformation:
    steps_per_update = float(max(cfg.optimizer_steps_per_update, 1))

    def schedule(opt_step):
        iteration = opt_step.astype(jnp.float32) / steps_per_update
        return learning_rate_for_iteration(cfg, iteration)

    return optax.chain(
        optax.clip_by_global_norm(cfg.max_grad_norm),
        optax.adam(learning_rate=schedule, eps=1e-5),
    )


def ema_update(params, ema_params, decay: float):
    one_minus = 1.0 - decay
    return jax.tree.map(
        lambda new, old: old * decay + new * one_minus,
        params,
        ema_params,
    )


def main() -> None:
    args = parse_args()
    train_cfg = TrainConfig(
        seed=args.seed,
        num_envs=args.num_envs,
        pool_size=args.pool_size,
        rollout_length=args.rollout_length,
        total_updates=args.updates,
        bptt_length=args.bptt_length,
        minibatch_sequences=args.minibatch_sequences,
        ppo_epochs=args.ppo_epochs,
        top_advantage_fraction=args.top_advantage_fraction,
        gae_lambda=args.gae_lambda,
        shaping_scale=args.shaping_scale,
        bc_coef=args.bc_coef,
        bc_final_coef=args.bc_final_coef,
        bc_decay_updates=args.bc_decay_updates,
        selfplay_fraction=args.selfplay_fraction,
        heuristic_fraction=args.heuristic_fraction,
        expander_fraction=args.expander_fraction,
        hunter_fraction=args.hunter_fraction,
        ema_decay=args.ema_decay,
        spawn_curriculum_updates=args.spawn_curriculum_updates,
        checkpoint_dir=args.checkpoint_dir,
        compute_dtype="float32" if args.float32 else "bfloat16",
    )
    train_cfg.validate()
    model_cfg = ModelConfig()

    cache_dir = Path(train_cfg.compilation_cache_dir).resolve()
    cache_dir.mkdir(parents=True, exist_ok=True)
    jax.config.update("jax_compilation_cache_dir", str(cache_dir))
    jax.config.update("jax_persistent_cache_min_entry_size_bytes", -1)

    print("JAX devices:", jax.devices())
    if not any(d.platform == "gpu" for d in jax.devices()):
        raise RuntimeError("No JAX GPU found. Install the CUDA-enabled JAX wheel before training.")

    compute_dtype = jnp.float32 if train_cfg.compute_dtype == "float32" else jnp.bfloat16
    model = ActorCritic(model_cfg, compute_dtype=compute_dtype)
    key = jax.random.PRNGKey(train_cfg.seed)
    key, init_key = jax.random.split(key)

    dummy_x = jnp.zeros(
        (1, model_cfg.board_size, model_cfg.board_size, model_cfg.input_channels),
        dtype=compute_dtype,
    )
    dummy_h = jnp.zeros((1, model_cfg.hidden_size), dtype=jnp.float32)
    params = model.init(init_key, dummy_x, dummy_h)["params"]

    if args.init_from and args.resume:
        raise ValueError("Use either --resume or --init-from, not both")
    if args.init_from:
        params = load_params_only(args.init_from, params, prefer_ema=True)
        print(f"Initialized parameters from {args.init_from}; optimizer starts fresh")

    train_state = TrainState.create(
        apply_fn=model.apply,
        params=params,
        tx=make_optimizer(train_cfg),
    )
    ema_params = params
    start_update = 0

    if args.resume:
        train_state, ema_params, key, start_update = load_checkpoint(
            args.resume,
            train_state,
            ema_params,
            key,
        )
        print(f"Resumed v3.4 run from update {start_update}")

    out_dir = Path(train_cfg.checkpoint_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    save_config(out_dir / "config.json", model_cfg, train_cfg)

    # Step rules never depend on the curriculum distance; only generated pools do.
    step_env = make_competition_env(train_cfg.pool_size, None)
    get_obs_batch = jax.jit(jax.vmap(stack_player_observations))
    step_batch = jax.jit(
        jax.vmap(
            lambda s, a, pool_arg: step_env.step(s, a, pool_arg),
            in_axes=(0, 0, None),
        )
    )

    expander = ExpanderAgent()
    hunter = HunterAgent()
    expander_act_batch = jax.jit(jax.vmap(expander.act))
    hunter_act_batch = jax.jit(jax.vmap(hunter.act))
    heuristic_act_batch = jax.jit(jax.vmap(heuristic_action))
    heuristic_index_batch = jax.jit(jax.vmap(heuristic_action_index))

    # Fixed deterministic assignment avoids recompilation and keeps all batches
    # represented every rollout. Type: 0 self-play, 1 heuristic, 2 expander,
    # 3 hunter. The learner alternates seats in fixed-opponent games.
    fractions = np.asarray(
        [
            train_cfg.selfplay_fraction,
            train_cfg.heuristic_fraction,
            train_cfg.expander_fraction,
            train_cfg.hunter_fraction,
        ],
        dtype=np.float64,
    )
    raw_counts = fractions * train_cfg.num_envs
    counts = np.floor(raw_counts).astype(np.int32)
    for i in np.argsort(-(raw_counts - counts))[: train_cfg.num_envs - int(counts.sum())]:
        counts[i] += 1
    opponent_type_host = np.concatenate(
        [np.full(int(count), i, dtype=np.int32) for i, count in enumerate(counts)]
    )
    rng = np.random.default_rng(train_cfg.seed + 0x34)
    rng.shuffle(opponent_type_host)
    opponent_type = jnp.asarray(opponent_type_host)
    learner_seat = jnp.arange(train_cfg.num_envs, dtype=jnp.int32) % 2
    opponent_seat = 1 - learner_seat
    player_ids = jnp.arange(2, dtype=jnp.int32)[None, :]
    selfplay_env = opponent_type == 0
    control_mask_static = selfplay_env[:, None] | (player_ids == learner_seat[:, None])
    fixed_control_mask_static = (~selfplay_env[:, None]) & (
        player_ids == learner_seat[:, None]
    )
    controlled_agents_per_step = int(np.asarray(control_mask_static).sum())
    print(
        "Opponent mix: "
        f"selfplay={counts[0]}, heuristic={counts[1]}, "
        f"expander={counts[2]}, hunter={counts[3]} environments"
    )

    def initialize_stage_pool(
        rng_key: jnp.ndarray,
        max_distance: int | None,
    ) -> tuple[jnp.ndarray, object, RolloutCarry]:
        rng_key, pool_key, carry_key = jax.random.split(rng_key, 3)
        print(f"Generating pool for spawn stage {stage_label(max_distance)} ...")
        if max_distance is None:
            # Keep exact competition boards in the majority, but retain a
            # reward-bearing bridge fraction. A hard switch to min_distance=17
            # produced essentially zero decisive games and no policy signal.
            bridge_size = train_cfg.pool_size // 4
            hard_size = train_cfg.pool_size - bridge_size
            if bridge_size % 16 != 0 or hard_size % 16 != 0:
                raise ValueError("mixed final pool partitions must be divisible by 16")
            pool_key, hard_key, bridge_key, shuffle_key = jax.random.split(pool_key, 4)
            hard_env = make_competition_env(hard_size, None)
            bridge_env = make_competition_env(bridge_size, 28)
            hard_pool, _ = hard_env.reset(hard_key)
            bridge_pool, _ = bridge_env.reset(bridge_key)
            pool = jax.tree.map(
                lambda hard, bridge: jnp.concatenate([hard, bridge], axis=0),
                hard_pool,
                bridge_pool,
            )
            permutation = jax.random.permutation(shuffle_key, train_cfg.pool_size)
            pool = jax.tree.map(lambda x: x[permutation], pool)
        else:
            generator = make_competition_env(train_cfg.pool_size, max_distance)
            pool, _ = generator.reset(pool_key)
        indices = jnp.arange(train_cfg.num_envs, dtype=jnp.int32)
        current_indices = indices % train_cfg.pool_size
        states = jax.tree.map(lambda x: x[current_indices], pool)
        # pool_idx points to the *next* board used by auto-reset. Pointing it at
        # current_indices would replay every initial board once after its first end.
        next_indices = (current_indices + train_cfg.num_envs) % train_cfg.pool_size
        states = states._replace(pool_idx=next_indices)
        obs = get_obs_batch(states)
        hidden = jnp.zeros(
            (train_cfg.num_envs, 2, model_cfg.hidden_size),
            dtype=jnp.float32,
        )
        return rng_key, pool, RolloutCarry(states, obs, hidden, carry_key)

    initial_stage_idx, initial_max_distance = spawn_stage(
        start_update + 1,
        train_cfg.spawn_curriculum_updates,
    )
    key, pool, carry = initialize_stage_pool(key, initial_max_distance)
    current_stage_idx = initial_stage_idx

    def collect_rollout(params_arg, carry_arg: RolloutCarry, pool_arg):
        def one_step(c: RolloutCarry, _):
            flat_obs = flatten_players(c.obs)
            flat_hidden = c.hidden.reshape((-1, model_cfg.hidden_size))
            x = encode_observation(flat_obs, dtype=compute_dtype)
            logits, values, hidden_out = model.apply(
                {"params": params_arg},
                x,
                flat_hidden,
            )
            logits = mask_logits(logits, valid_action_mask(flat_obs))

            key_next, sample_key, opponent_key, teacher_key = jax.random.split(c.key, 4)
            action = jax.random.categorical(sample_key, logits, axis=-1).astype(jnp.int32)
            log_probs = jax.nn.log_softmax(logits, axis=-1)
            chosen_logprob = jnp.take_along_axis(
                log_probs,
                action[:, None],
                axis=-1,
            )[:, 0]

            action_2p = action.reshape((train_cfg.num_envs, 2))
            env_actions = action_index_to_env(action_2p)

            fixed_obs = select_seat(c.obs, opponent_seat)
            opponent_keys = jax.random.split(opponent_key, train_cfg.num_envs)
            heuristic_actions = heuristic_act_batch(fixed_obs, opponent_keys)
            expander_actions = expander_act_batch(fixed_obs, opponent_keys)
            hunter_actions = hunter_act_batch(fixed_obs, opponent_keys)
            fixed_actions = jnp.where(
                (opponent_type == 1)[:, None],
                heuristic_actions,
                jnp.where(
                    (opponent_type == 2)[:, None],
                    expander_actions,
                    hunter_actions,
                ),
            )
            env_actions = env_actions.at[
                jnp.arange(train_cfg.num_envs), opponent_seat
            ].set(
                jnp.where(selfplay_env[:, None],
                          env_actions[jnp.arange(train_cfg.num_envs), opponent_seat],
                          fixed_actions)
            )

            teacher_keys = jax.random.split(teacher_key, train_cfg.num_envs * 2)
            teacher_action = heuristic_index_batch(flat_obs, teacher_keys).reshape(
                (train_cfg.num_envs, 2)
            )

            timestep, new_states = step_batch(
                c.states,
                env_actions,
                pool_arg,
            )
            done = timestep.terminated | timestep.truncated

            phi_before = player_potential(c.obs)
            phi_after = player_potential(timestep.observation)
            phi_after = jnp.where(done[:, None], 0.0, phi_after)
            shaped_reward = timestep.reward + train_cfg.shaping_scale * (
                phi_after - phi_before
            )

            new_hidden = hidden_out.reshape(
                (train_cfg.num_envs, 2, model_cfg.hidden_size)
            )
            new_hidden = jnp.where(done[:, None, None], 0.0, new_hidden)

            transition = Transition(
                obs=c.obs,
                hidden=c.hidden,
                action=action_2p,
                old_logprob=chosen_logprob.reshape((train_cfg.num_envs, 2)),
                old_value=values.reshape((train_cfg.num_envs, 2)),
                reward=shaped_reward,
                raw_reward=timestep.reward,
                teacher_action=teacher_action,
                control_mask=control_mask_static,
                terminated=timestep.terminated,
                truncated=timestep.truncated,
                done=jnp.broadcast_to(done[:, None], (train_cfg.num_envs, 2)),
            )
            new_carry = RolloutCarry(
                new_states,
                timestep.observation,
                new_hidden,
                key_next,
            )
            return new_carry, transition

        final_carry, trajectory = jax.lax.scan(
            one_step,
            carry_arg,
            xs=None,
            length=train_cfg.rollout_length,
        )

        flat_final_obs = flatten_players(final_carry.obs)
        x_final = encode_observation(flat_final_obs, dtype=compute_dtype)
        _, bootstrap, _ = model.apply(
            {"params": params_arg},
            x_final,
            final_carry.hidden.reshape((-1, model_cfg.hidden_size)),
        )
        bootstrap = bootstrap.reshape((train_cfg.num_envs, 2))

        def gae_step(carry_gae, inputs):
            gae, next_value = carry_gae
            reward_t, done_t, value_t = inputs
            not_done = 1.0 - done_t.astype(jnp.float32)
            delta = reward_t + train_cfg.gamma * not_done * next_value - value_t
            gae = (
                delta
                + train_cfg.gamma
                * train_cfg.gae_lambda
                * not_done
                * gae
            )
            return (gae, value_t), gae

        (_, _), advantages = jax.lax.scan(
            gae_step,
            (jnp.zeros_like(bootstrap), bootstrap),
            (trajectory.reward, trajectory.done, trajectory.old_value),
            reverse=True,
        )
        returns = advantages + trajectory.old_value
        return final_carry, trajectory, advantages, returns

    collect_rollout_jit = jax.jit(collect_rollout)

    def chunk_time_env_player(x: jnp.ndarray) -> jnp.ndarray:
        # [T, N, 2, ...] -> [N*2*num_chunks, BPTT, ...]
        trailing = x.shape[3:]
        perm = (1, 2, 0) + tuple(range(3, x.ndim))
        x = jnp.transpose(x, perm)
        x = x.reshape(
            (
                train_cfg.num_envs * 2,
                train_cfg.chunks_per_agent,
                train_cfg.bptt_length,
            )
            + trailing
        )
        return x.reshape(
            (train_cfg.sequence_count, train_cfg.bptt_length) + trailing
        )

    @jax.jit
    def prepare_chunks(
        trajectory: Transition,
        advantages: jnp.ndarray,
        returns: jnp.ndarray,
    ) -> tuple[ChunkBatch, jnp.ndarray]:
        # Select/normalize only transitions controlled by the learner. Fixed
        # opponent actions are present in the environment trajectory but must not
        # enter PPO or value losses.
        control = trajectory.control_mask.astype(jnp.bool_)
        flat_adv = jnp.where(control, advantages, -1.0e30).reshape(-1)
        keep_count = max(
            1,
            int(
                train_cfg.rollout_length
                * controlled_agents_per_step
                * train_cfg.top_advantage_fraction
            ),
        )
        top_values, _ = jax.lax.top_k(flat_adv, keep_count)
        threshold = top_values[-1]
        policy_mask = control & (advantages >= threshold)

        weight = control.astype(jnp.float32)
        denom = jnp.maximum(jnp.sum(weight), 1.0)
        mean_adv = jnp.sum(advantages * weight) / denom
        var_adv = jnp.sum(jnp.square(advantages - mean_adv) * weight) / denom
        normalized_adv = (advantages - mean_adv) / jnp.sqrt(var_adv + 1e-8)

        obs_chunks = jax.tree.map(chunk_time_env_player, trajectory.obs)
        hidden_chunks = chunk_time_env_player(trajectory.hidden)
        batch = ChunkBatch(
            obs=obs_chunks,
            hidden0=hidden_chunks[:, 0],
            action=chunk_time_env_player(trajectory.action),
            old_logprob=chunk_time_env_player(trajectory.old_logprob),
            old_value=chunk_time_env_player(trajectory.old_value),
            advantage=chunk_time_env_player(normalized_adv),
            returns=chunk_time_env_player(returns),
            done=chunk_time_env_player(trajectory.done),
            policy_mask=chunk_time_env_player(policy_mask),
            teacher_action=chunk_time_env_player(trajectory.teacher_action),
            control_mask=chunk_time_env_player(trajectory.control_mask),
        )
        return batch, threshold

    @jax.jit
    def update_minibatch(
        state: TrainState,
        ema_params_arg,
        obs_mb,
        hidden0_mb,
        action_mb,
        old_logprob_mb,
        old_value_mb,
        advantage_mb,
        returns_mb,
        done_mb,
        policy_mask_mb,
        teacher_action_mb,
        control_mask_mb,
        entropy_coef: jnp.ndarray,
        bc_coef: jnp.ndarray,
    ):
        def loss_fn(params_arg):
            def replay_step(h, inputs):
                obs_t, done_t = inputs
                x_t = encode_observation(obs_t, dtype=compute_dtype)
                logits_t, value_t, h_out = model.apply(
                    {"params": params_arg},
                    x_t,
                    h,
                )
                action_mask_t = valid_action_mask(obs_t)
                logits_t = mask_logits(logits_t, action_mask_t)
                legal_count_t = jnp.sum(action_mask_t, axis=-1).astype(jnp.float32)
                h_out = jnp.where(done_t[:, None], 0.0, h_out)
                return h_out, (logits_t, value_t, legal_count_t)

            _, (logits, values, legal_counts) = jax.lax.scan(
                replay_step,
                hidden0_mb,
                (obs_mb, done_mb),
            )

            logp_all = jax.nn.log_softmax(logits, axis=-1)
            new_logprob = jnp.take_along_axis(
                logp_all,
                action_mb[..., None],
                axis=-1,
            )[..., 0]
            probs = jnp.exp(logp_all)
            entropy = -jnp.sum(probs * logp_all, axis=-1)

            ratio = jnp.exp(new_logprob - old_logprob_mb)
            unclipped = ratio * advantage_mb
            clipped = jnp.clip(
                ratio,
                1.0 - train_cfg.clip_epsilon,
                1.0 + train_cfg.clip_epsilon,
            ) * advantage_mb

            control_weight = control_mask_mb.astype(jnp.float32)
            control_denom = jnp.maximum(jnp.sum(control_weight), 1.0)
            policy_weight = policy_mask_mb.astype(jnp.float32)
            policy_denom = jnp.maximum(jnp.sum(policy_weight), 1.0)
            policy_objective = jnp.minimum(unclipped, clipped)
            policy_loss = -jnp.sum(policy_objective * policy_weight) / policy_denom

            # Entropy regularization covers every on-policy transition, not only
            # the transitions selected by the policy-advantage mask.
            entropy_mean = jnp.sum(entropy * control_weight) / control_denom
            max_entropy = jnp.log(jnp.maximum(legal_counts, 1.0))
            normalized_entropy = jnp.sum(
                (entropy / jnp.maximum(max_entropy, 1e-6)) * control_weight
            ) / control_denom

            value_clipped = old_value_mb + jnp.clip(
                values - old_value_mb,
                -train_cfg.value_clip_epsilon,
                train_cfg.value_clip_epsilon,
            )
            value_loss_unclipped = jnp.square(values - returns_mb)
            value_loss_clipped = jnp.square(value_clipped - returns_mb)
            value_loss = 0.5 * jnp.sum(
                jnp.maximum(value_loss_unclipped, value_loss_clipped)
                * control_weight
            ) / control_denom

            teacher_logprob = jnp.take_along_axis(
                logp_all,
                teacher_action_mb[..., None],
                axis=-1,
            )[..., 0]
            bc_loss = -jnp.sum(teacher_logprob * control_weight) / control_denom

            total_loss = (
                policy_loss
                + train_cfg.value_coef * value_loss
                + bc_coef * bc_loss
                - entropy_coef * entropy_mean
            )
            log_ratio = new_logprob - old_logprob_mb
            approx_kl = jnp.sum(
                ((ratio - 1.0) - log_ratio) * policy_weight
            ) / policy_denom
            clip_fraction = jnp.sum(
                (jnp.abs(ratio - 1.0) > train_cfg.clip_epsilon).astype(jnp.float32)
                * policy_weight
            ) / policy_denom

            return_mean = jnp.sum(returns_mb * control_weight) / control_denom
            return_variance = jnp.sum(
                jnp.square(returns_mb - return_mean) * control_weight
            ) / control_denom
            residual = returns_mb - values
            residual_mean = jnp.sum(residual * control_weight) / control_denom
            residual_variance = jnp.sum(
                jnp.square(residual - residual_mean) * control_weight
            ) / control_denom
            explained_variance = 1.0 - residual_variance / (
                return_variance + 1e-8
            )
            metrics = {
                "loss": total_loss,
                "policy_loss": policy_loss,
                "value_loss": value_loss,
                "bc_loss": bc_loss,
                "entropy": entropy_mean,
                "normalized_entropy": normalized_entropy,
                "approx_kl": approx_kl,
                "clip_fraction": clip_fraction,
                "explained_variance": explained_variance,
                "selected_fraction": jnp.sum(policy_weight) / control_denom,
                "controlled_fraction": jnp.mean(control_weight),
            }
            return total_loss, metrics

        (_, metrics), grads = jax.value_and_grad(loss_fn, has_aux=True)(state.params)
        grad_norm = optax.global_norm(grads)
        state = state.apply_gradients(grads=grads)
        ema_params_arg = ema_update(state.params, ema_params_arg, train_cfg.ema_decay)
        metrics["grad_norm"] = grad_norm
        return state, ema_params_arg, metrics

    fieldnames = [
        "update",
        "environment_steps",
        "agent_steps",
        "fps_environment",
        "fps_agent",
        "spawn_stage",
        "spawn_max_distance",
        "learning_rate",
        "entropy_coef",
        "mean_abs_terminal_reward",
        "done_rate",
        "terminated_rate",
        "truncated_rate",
        "episodes_finished",
        "decisive_games",
        "truncated_games",
        "p0_wins",
        "p1_wins",
        "fixed_opponent_wins",
        "fixed_opponent_losses",
        "estimated_mean_episode_length",
        "top_advantage_threshold",
        "loss",
        "policy_loss",
        "value_loss",
        "bc_loss",
        "entropy",
        "normalized_entropy",
        "approx_kl",
        "clip_fraction",
        "explained_variance",
        "selected_fraction",
        "controlled_fraction",
        "grad_norm",
    ]
    csv_path = out_dir / "training_v34.csv"
    write_header = not csv_path.exists()
    csv_file = csv_path.open("a", newline="", encoding="utf-8")
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    if write_header:
        writer.writeheader()

    total_environment_steps = (
        start_update * train_cfg.environment_steps_per_update
    )
    total_agent_steps = start_update * train_cfg.agent_steps_per_update

    print(
        "v3.4 recipe: mixed opponents, heuristic distillation, "
        f"rollout={train_cfg.rollout_length}, gamma={train_cfg.gamma}, "
        f"lambda={train_cfg.gae_lambda}, top_adv={train_cfg.top_advantage_fraction}, "
        f"shaping={train_cfg.shaping_scale}, bc={train_cfg.bc_coef}->{train_cfg.bc_final_coef}, "
        f"EMA={train_cfg.ema_decay}"
    )
    print(
        f"Recurrent batches: BPTT={train_cfg.bptt_length}, "
        f"sequences/update={train_cfg.sequence_count:,}, "
        f"minibatches/update={train_cfg.optimizer_steps_per_update:,}"
    )
    print("Compiling rollout and PPO kernels on first use...")

    try:
        for update in range(start_update + 1, train_cfg.total_updates + 1):
            wanted_stage_idx, wanted_max_distance = spawn_stage(
                update,
                train_cfg.spawn_curriculum_updates,
            )
            if wanted_stage_idx != current_stage_idx:
                key, pool, carry = initialize_stage_pool(key, wanted_max_distance)
                current_stage_idx = wanted_stage_idx

            t0 = time.perf_counter()
            carry, trajectory, advantages, returns = collect_rollout_jit(
                train_state.params,
                carry,
                pool,
            )
            chunks, advantage_threshold = prepare_chunks(
                trajectory,
                advantages,
                returns,
            )

            entropy_coef = entropy_for_iteration(train_cfg, update - 1)
            bc_coef = bc_for_iteration(train_cfg, update - 1)
            key, permutation_key = jax.random.split(carry.key)
            carry = carry._replace(key=key)
            metric_accum = []

            for _epoch in range(train_cfg.ppo_epochs):
                permutation_key, epoch_key = jax.random.split(permutation_key)
                order = np.asarray(
                    jax.device_get(
                        jax.random.permutation(epoch_key, train_cfg.sequence_count)
                    )
                )
                for start in range(
                    0,
                    train_cfg.sequence_count,
                    train_cfg.minibatch_sequences,
                ):
                    idx = jnp.asarray(
                        order[start : start + train_cfg.minibatch_sequences]
                    )

                    # Stored chunks are batch-major [M, L, ...]. Recurrent replay
                    # expects time-major [L, M, ...].
                    obs_mb = jax.tree.map(
                        lambda x: jnp.swapaxes(x[idx], 0, 1),
                        chunks.obs,
                    )
                    train_state, ema_params, metrics = update_minibatch(
                        train_state,
                        ema_params,
                        obs_mb,
                        chunks.hidden0[idx],
                        jnp.swapaxes(chunks.action[idx], 0, 1),
                        jnp.swapaxes(chunks.old_logprob[idx], 0, 1),
                        jnp.swapaxes(chunks.old_value[idx], 0, 1),
                        jnp.swapaxes(chunks.advantage[idx], 0, 1),
                        jnp.swapaxes(chunks.returns[idx], 0, 1),
                        jnp.swapaxes(chunks.done[idx], 0, 1),
                        jnp.swapaxes(chunks.policy_mask[idx], 0, 1),
                        jnp.swapaxes(chunks.teacher_action[idx], 0, 1),
                        jnp.swapaxes(chunks.control_mask[idx], 0, 1),
                        jnp.asarray(entropy_coef, dtype=jnp.float32),
                        jnp.asarray(bc_coef, dtype=jnp.float32),
                    )
                    metric_accum.append(metrics)

            # Synchronize once for reliable timing and metrics.
            metrics_mean = jax.tree.map(
                lambda *xs: jnp.mean(jnp.stack(xs)),
                *metric_accum,
            )
            metrics_host = {
                name: float(jax.device_get(value))
                for name, value in metrics_mean.items()
            }
            terminal_reward_rate = float(
                jax.device_get(jnp.mean(jnp.abs(trajectory.raw_reward)))
            )
            done_env = trajectory.terminated | trajectory.truncated
            done_rate = float(
                jax.device_get(jnp.mean(done_env.astype(jnp.float32)))
            )
            terminated_rate = float(
                jax.device_get(jnp.mean(trajectory.terminated.astype(jnp.float32)))
            )
            truncated_rate = float(
                jax.device_get(jnp.mean(trajectory.truncated.astype(jnp.float32)))
            )
            episodes_finished = int(jax.device_get(jnp.sum(done_env)))
            decisive_games = int(jax.device_get(jnp.sum(trajectory.terminated)))
            truncated_games = int(jax.device_get(jnp.sum(trajectory.truncated)))
            p0_wins = int(jax.device_get(jnp.sum(trajectory.raw_reward[..., 0] > 0.0)))
            p1_wins = int(jax.device_get(jnp.sum(trajectory.raw_reward[..., 1] > 0.0)))
            fixed_wins = int(
                jax.device_get(
                    jnp.sum(
                        (trajectory.raw_reward > 0.0)
                        & fixed_control_mask_static[None, ...]
                    )
                )
            )
            fixed_losses = int(
                jax.device_get(
                    jnp.sum(
                        (trajectory.raw_reward < 0.0)
                        & fixed_control_mask_static[None, ...]
                    )
                )
            )
            threshold_host = float(jax.device_get(advantage_threshold))

            elapsed = time.perf_counter() - t0
            total_environment_steps += train_cfg.environment_steps_per_update
            total_agent_steps += train_cfg.agent_steps_per_update
            fps_environment = train_cfg.environment_steps_per_update / max(elapsed, 1e-6)
            fps_agent = train_cfg.agent_steps_per_update / max(elapsed, 1e-6)
            estimated_episode_length = (
                1.0 / done_rate if done_rate > 0.0 else float("inf")
            )
            lr_host = float(
                learning_rate_for_iteration(
                    train_cfg,
                    jnp.asarray(update - 1, dtype=jnp.float32),
                )
            )

            _, active_max_distance = spawn_stage(
                update,
                train_cfg.spawn_curriculum_updates,
            )
            row = {
                "update": update,
                "environment_steps": total_environment_steps,
                "agent_steps": total_agent_steps,
                "fps_environment": fps_environment,
                "fps_agent": fps_agent,
                "spawn_stage": stage_label(active_max_distance),
                "spawn_max_distance": (
                    "full" if active_max_distance is None else active_max_distance
                ),
                "learning_rate": lr_host,
                "entropy_coef": entropy_coef,
                "mean_abs_terminal_reward": terminal_reward_rate,
                "done_rate": done_rate,
                "terminated_rate": terminated_rate,
                "truncated_rate": truncated_rate,
                "episodes_finished": episodes_finished,
                "decisive_games": decisive_games,
                "truncated_games": truncated_games,
                "p0_wins": p0_wins,
                "p1_wins": p1_wins,
                "fixed_opponent_wins": fixed_wins,
                "fixed_opponent_losses": fixed_losses,
                "estimated_mean_episode_length": estimated_episode_length,
                "top_advantage_threshold": threshold_host,
                **metrics_host,
            }
            writer.writerow(row)
            csv_file.flush()

            if update % train_cfg.log_every == 0:
                print(
                    f"u={update:05d} env_steps={total_environment_steps:,} "
                    f"fps={fps_environment:,.0f} spawn={stage_label(active_max_distance)} "
                    f"term={terminated_rate:.5f} trunc={truncated_rate:.5f} "
                    f"wins={p0_wins + p1_wins} fixed={fixed_wins}-{fixed_losses} "
                    f"lr={lr_host:.2e} ent_c={entropy_coef:.4f} bc_c={bc_coef:.4f} "
                    f"loss={metrics_host['loss']:.4f} bc={metrics_host['bc_loss']:.3f} "
                    f"ent={metrics_host['entropy']:.3f} "
                    f"nent={metrics_host['normalized_entropy']:.3f} "
                    f"kl={metrics_host['approx_kl']:.5f} "
                    f"ev={metrics_host['explained_variance']:.3f}"
                )

            if update % train_cfg.save_every == 0 or update == train_cfg.total_updates:
                path = save_checkpoint(
                    out_dir,
                    train_state,
                    ema_params,
                    update,
                    carry.key,
                )
                print(f"Saved {path} (EMA included)")
    finally:
        csv_file.close()


if __name__ == "__main__":
    main()
