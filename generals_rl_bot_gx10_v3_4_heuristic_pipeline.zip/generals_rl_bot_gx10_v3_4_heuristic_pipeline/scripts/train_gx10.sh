#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate

# GX10 / GB10 has unified CPU-GPU memory. Keep headroom for Python, the map pool,
# XLA compilation, and the desktop/SSH session.
export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.85}"
export XLA_PYTHON_CLIENT_PREALLOCATE="${XLA_PYTHON_CLIENT_PREALLOCATE:-true}"
export JAX_COMPILATION_CACHE_DIR="${JAX_COMPILATION_CACHE_DIR:-$ROOT/.jax_cache}"
export JAX_OPTIMIZATION_LEVEL="${JAX_OPTIMIZATION_LEVEL:-O1}"
export XLA_FLAGS="${XLA_FLAGS:---xla_gpu_enable_command_buffer=FUSION,CUSTOM_CALL}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-16}"

# Renewed 2026-style recipe. The minibatch is expressed as recurrent sequences:
# 128 sequences x 32 timesteps = 4096 agent transitions per optimizer step.
exec python -m src.train \
  --num-envs "${NUM_ENVS:-512}" \
  --pool-size "${POOL_SIZE:-4096}" \
  --rollout-length "${ROLLOUT_LENGTH:-512}" \
  --bptt-length "${BPTT_LENGTH:-32}" \
  --minibatch-sequences "${MINIBATCH_SEQUENCES:-128}" \
  --ppo-epochs "${PPO_EPOCHS:-1}" \
  --top-advantage-fraction "${TOP_ADVANTAGE_FRACTION:-1.0}" \
  --gae-lambda "${GAE_LAMBDA:-0.995}" \
  --shaping-scale "${SHAPING_SCALE:-1.0}" \
  --ema-decay "${EMA_DECAY:-0.999}" \
  --spawn-curriculum-updates "${SPAWN_CURRICULUM_UPDATES:-1800}" \
  --updates "${UPDATES:-3000}" \
  --checkpoint-dir "${CHECKPOINT_DIR:-checkpoints_v3}" \
  "$@"
