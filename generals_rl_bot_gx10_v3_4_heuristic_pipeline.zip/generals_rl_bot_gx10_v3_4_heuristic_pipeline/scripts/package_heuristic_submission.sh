#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
rm -f generals_heuristic_submission.zip
(
  cd heuristic_submission
  zip -q -r ../generals_heuristic_submission.zip run.sh main.py
)
echo "Wrote $ROOT/generals_heuristic_submission.zip"
