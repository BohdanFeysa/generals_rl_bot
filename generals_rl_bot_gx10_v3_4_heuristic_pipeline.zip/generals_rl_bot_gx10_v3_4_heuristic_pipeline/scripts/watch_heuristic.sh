#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
OPPONENT="${OPPONENT:-third_party/generals-bots/competition/agents/hunter_cpp/run.sh}"
python third_party/generals-bots/competition/matchup.py \
  heuristic_submission/run.sh "$OPPONENT" --mode competition --seed "${SEED:-7}" --gui
