#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
GAMES="${GAMES:-256}"
exec python -m src.evaluate_heuristic --games "$GAMES" "$@"
