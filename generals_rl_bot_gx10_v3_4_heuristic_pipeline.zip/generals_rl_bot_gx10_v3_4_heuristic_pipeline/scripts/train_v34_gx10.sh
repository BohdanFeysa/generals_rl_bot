#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate

export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.85}"
export XLA_PYTHON_CLIENT_PREALLOCATE="${XLA_PYTHON_CLIENT_PREALLOCATE:-true}"
export JAX_COMPILATION_CACHE_DIR="${JAX_COMPILATION_CACHE_DIR:-$ROOT/.jax_cache_v34}"
export JAX_OPTIMIZATION_LEVEL="${JAX_OPTIMIZATION_LEVEL:-O1}"
export XLA_FLAGS="${XLA_FLAGS:---xla_gpu_enable_command_buffer=FUSION,CUSTOM_CALL}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-16}"

# Recovery defaults: initialize from the strongest pre-collapse v3.2 checkpoint,
# start directly on a 75% competition / 25% max_bfs=28 pool, and train against a
# diverse opponent mixture while distilling the heuristic online.
exec python -m src.train_v34 \
  --num-envs "${NUM_ENVS:-512}" \
  --pool-size "${POOL_SIZE:-4096}" \
  --rollout-length "${ROLLOUT_LENGTH:-512}" \
  --bptt-length "${BPTT_LENGTH:-32}" \
  --minibatch-sequences "${MINIBATCH_SEQUENCES:-128}" \
  --ppo-epochs "${PPO_EPOCHS:-1}" \
  --top-advantage-fraction "${TOP_ADVANTAGE_FRACTION:-1.0}" \
  --gae-lambda "${GAE_LAMBDA:-0.995}" \
  --shaping-scale "${SHAPING_SCALE:-1.0}" \
  --bc-coef "${BC_COEF:-0.20}" \
  --bc-final-coef "${BC_FINAL_COEF:-0.02}" \
  --bc-decay-updates "${BC_DECAY_UPDATES:-800}" \
  --selfplay-fraction "${SELFPLAY_FRACTION:-0.25}" \
  --heuristic-fraction "${HEURISTIC_FRACTION:-0.35}" \
  --expander-fraction "${EXPANDER_FRACTION:-0.20}" \
  --hunter-fraction "${HUNTER_FRACTION:-0.20}" \
  --ema-decay "${EMA_DECAY:-0.999}" \
  --spawn-curriculum-updates "${SPAWN_CURRICULUM_UPDATES:-0}" \
  --updates "${UPDATES:-1200}" \
  --checkpoint-dir "${CHECKPOINT_DIR:-checkpoints_v34}" \
  "$@"
