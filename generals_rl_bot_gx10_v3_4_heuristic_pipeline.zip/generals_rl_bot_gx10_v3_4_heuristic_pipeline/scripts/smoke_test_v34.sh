#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate

python -m pytest -q tests/test_action_codec.py tests/test_heuristic.py
rm -rf /tmp/generals_v34_smoke

NUM_ENVS=16 \
POOL_SIZE=256 \
ROLLOUT_LENGTH=32 \
BPTT_LENGTH=16 \
MINIBATCH_SEQUENCES=16 \
UPDATES=1 \
CHECKPOINT_DIR=/tmp/generals_v34_smoke \
SPAWN_CURRICULUM_UPDATES=0 \
BC_DECAY_UPDATES=10 \
bash scripts/train_v34_gx10.sh --float32

test -f /tmp/generals_v34_smoke/update_0000001.msgpack
GAMES=16 bash scripts/evaluate_heuristic.sh --opponent both
bash scripts/package_heuristic_submission.sh

echo "v3.4 smoke test completed"
