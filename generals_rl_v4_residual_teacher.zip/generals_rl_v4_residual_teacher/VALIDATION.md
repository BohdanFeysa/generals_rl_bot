# Validation report

## Completed in the artifact build environment

- Exact teacher ZIP SHA-256 verified.
- All Python modules passed `py_compile`.
- All shell scripts passed `bash -n`.
- Unit tests: action codec, teacher artifact hash, teacher candidate inclusion, zero-initialized teacher anchoring, and checkpoint round-trip.
- Full miniature lifecycle passed against a JAX mock with the same public API shape:
  1. teacher data collection;
  2. behavior cloning;
  3. PPO update;
  4. checkpoint save;
  5. PPO resume with optimizer state;
  6. teacher/model evaluation;
  7. submission export;
  8. two-turn stdin/stdout runtime smoke test.
- The exported zero-initialized model selected the exact teacher action on both protocol turns.

## Must be run on the GX10

The artifact build environment did not contain the installed official `generals` package or the GX10 CUDA stack. Therefore the first commands on the GX10 must be:

```bash
bash scripts/setup_gx10.sh
bash scripts/smoke_test.sh
bash scripts/evaluate_teacher.sh --opponent all --games 16 --seed 123
```

Then run a tiny integration job before a long experiment:

```bash
bash scripts/collect_teacher.sh --samples 256 --num-envs 4 --pool-size 256 --shard-size 128 --out /tmp/v4_smoke_data
bash scripts/train_bc.sh --data /tmp/v4_smoke_data --epochs 1 --batch-size 32 --out /tmp/v4_smoke_bc.npz
bash scripts/train_ppo.sh --init /tmp/v4_smoke_bc.npz --checkpoint-dir /tmp/v4_smoke_ppo --num-envs 4 --pool-size 256 --rollout-length 8 --updates 1 --epochs 1 --minibatch-size 16 --save-every 1
```

Only after that should the full 100k-sample / BC / PPO recipe begin.

## Intentional limitations

- v4.0 uses fixed-opponent residual PPO rather than a snapshot self-play league.
- Exact stateful candidate generation is CPU-side and lower-throughput than end-to-end JAX PPO.
- Environment state is not serialized. Resume preserves model, EMA, and Adam state but starts a fresh map pool and teacher-state fleet.
- The immutable teacher ZIP remains the deployment fallback and should never be deleted.
