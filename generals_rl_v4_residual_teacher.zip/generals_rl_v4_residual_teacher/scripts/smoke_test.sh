#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd); cd "$ROOT"
source .venv/bin/activate 2>/dev/null || true
python -m pytest -q
python -m generals_v4.model_smoke
