#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd); cd "$ROOT"
source .venv/bin/activate
python -m generals_v4.collect_teacher --samples "${SAMPLES:-100000}" --num-envs "${COLLECT_ENVS:-32}" --out datasets/teacher_v4
python -m generals_v4.train_bc --data datasets/teacher_v4 --epochs "${BC_EPOCHS:-8}" --out checkpoints_v4/bc_final.npz
python -m generals_v4.train_ppo --init checkpoints_v4/bc_final.npz --checkpoint-dir checkpoints_v4/ppo --num-envs "${PPO_ENVS:-64}" --rollout-length "${ROLLOUT:-128}" --updates "${UPDATES:-100}"
