#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install -U pip setuptools wheel
python -m pip install -e . -r requirements-train.txt
if python -c 'import generals' 2>/dev/null; then
  echo "official generals package already available"
elif [[ -d "${GENERALS_REPO:-../generals-bots}" ]]; then
  python -m pip install -e "${GENERALS_REPO:-../generals-bots}"
else
  git clone https://github.com/strakam/generals-bots.git ../generals-bots
  python -m pip install -e ../generals-bots
fi
python -c "import jax; print('JAX devices:', jax.devices()); from generals import GeneralsEnv; print('GeneralsEnv import: OK')"
