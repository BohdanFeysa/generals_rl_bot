#!/usr/bin/env bash
set -euo pipefail
source .venv/bin/activate
export XLA_PYTHON_CLIENT_MEM_FRACTION=${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.80}
python -m generals_v4.train_ppo "$@"
