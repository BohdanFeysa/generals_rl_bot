#!/usr/bin/env bash
set -euo pipefail
source .venv/bin/activate
python -m generals_v4.evaluate "$@"
