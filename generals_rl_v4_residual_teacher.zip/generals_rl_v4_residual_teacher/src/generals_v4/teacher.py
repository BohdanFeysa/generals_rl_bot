from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from .action_codec import BOARD, DIR_DR, DIR_DC, action_key, move_destination
from . import teacher_exact as exact

_CPU_DEVICE = jax.local_devices(backend="cpu")[0]
_choose_action_backend = jax.jit(
    lambda obs, key: exact._action_index_to_env(exact._heuristic_action_index(obs, key))
)


def to_teacher_observation(obs: Any) -> exact.Observation:
    """Convert the official padded Observation without changing semantics."""
    return exact.Observation(
        armies=jnp.asarray(obs.armies),
        generals=jnp.asarray(obs.generals),
        castles=jnp.asarray(obs.castles),
        mountains=jnp.asarray(obs.mountains),
        neutral_cells=jnp.asarray(obs.neutral_cells),
        owned_cells=jnp.asarray(obs.owned_cells),
        opponent_cells=jnp.asarray(obs.opponent_cells),
        fog_cells=jnp.asarray(obs.fog_cells),
        structures_in_fog=jnp.asarray(obs.structures_in_fog),
        owned_land_count=jnp.asarray(obs.owned_land_count),
        owned_army_count=jnp.asarray(obs.owned_army_count),
        opponent_land_count=jnp.asarray(obs.opponent_land_count),
        opponent_army_count=jnp.asarray(obs.opponent_army_count),
        timestep=jnp.asarray(obs.timestep),
    )


@dataclass
class TeacherProposal:
    action: np.ndarray
    next_state: exact.EconomyState


class ExactTeacher:
    """Stateful wrapper around the exact winning submission policy.

    propose() is transactional. The internal state changes only after commit(),
    allowing an RL override without pretending the teacher action was executed.
    """

    def __init__(self, seed: int = 0xF3A5A):
        self.key = jax.random.PRNGKey(seed)
        self.state = exact.EconomyState()

    def reset(self) -> None:
        self.state = exact.EconomyState()

    def propose(self, obs: Any) -> TeacherProposal:
        teacher_obs = to_teacher_observation(obs)
        self.key, action_key_jax = jax.random.split(self.key)
        cpu_obs = jax.tree.map(lambda x: jax.device_put(x, _CPU_DEVICE), teacher_obs)
        cpu_key = jax.device_put(action_key_jax, _CPU_DEVICE)
        base = np.asarray(_choose_action_backend(cpu_obs, cpu_key), dtype=np.int32)
        state_copy = replace(self.state)
        overlay = exact.choose_mobilized_economy(teacher_obs, base, state_copy)
        action = base if overlay is None else np.asarray(overlay, dtype=np.int32)
        return TeacherProposal(action=action, next_state=state_copy)

    def commit(self, obs: Any, proposal: TeacherProposal, executed_action: np.ndarray) -> None:
        executed = np.asarray(executed_action, dtype=np.int32)
        if action_key(executed) == action_key(proposal.action):
            self.state = proposal.next_state
            return
        self._commit_override(obs, executed)

    def _commit_override(self, obs: Any, action: np.ndarray) -> None:
        armies = np.asarray(obs.armies, dtype=np.int32)
        owned = np.asarray(obs.owned_cells, dtype=bool)
        castles = np.asarray(obs.castles, dtype=bool)
        opponent = np.asarray(obs.opponent_cells, dtype=bool)
        visible = np.argwhere(opponent)
        if len(visible):
            self.state.enemy_memory = (
                float(np.mean(visible[:, 0])),
                float(np.mean(visible[:, 1])),
            )
        if int(action[0]) != 0:
            return
        r, c = map(int, action[1:3])
        destination = move_destination(action)
        if destination is None:
            return
        follows_main = self.state.main_stack == (r, c)
        large_source = 0 <= r < BOARD and 0 <= c < BOARD and (
            int(armies[r, c]) >= 45 or (bool(castles[r, c] and owned[r, c]) and int(armies[r, c]) >= 35)
        )
        if follows_main or large_source:
            self.state.main_stack = destination
            self.state.lost_turns = 0


class TeacherFleet:
    def __init__(self, count: int, seed: int = 1234):
        self.agents = [ExactTeacher(seed + 104729 * i) for i in range(count)]

    def reset(self, index: int) -> None:
        self.agents[index].reset()
