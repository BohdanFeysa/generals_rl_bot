from __future__ import annotations

import json
from pathlib import Path
from typing import Any
import numpy as np
import jax
import jax.numpy as jnp

from .optim import AdamState


def _flatten(tree, prefix=""):
    out = {}
    if isinstance(tree, dict):
        for k, v in tree.items():
            out.update(_flatten(v, f"{prefix}/{k}" if prefix else str(k)))
    elif isinstance(tree, (list, tuple)):
        for i, v in enumerate(tree):
            out.update(_flatten(v, f"{prefix}/{i}"))
    else:
        out[prefix] = np.asarray(tree)
    return out


def _rebuild(template, arrays, prefix=""):
    if isinstance(template, dict):
        return {k: _rebuild(v, arrays, f"{prefix}/{k}" if prefix else str(k)) for k, v in template.items()}
    if isinstance(template, list):
        return [_rebuild(v, arrays, f"{prefix}/{i}") for i, v in enumerate(template)]
    if isinstance(template, tuple):
        return tuple(_rebuild(v, arrays, f"{prefix}/{i}") for i, v in enumerate(template))
    return jnp.asarray(arrays[prefix])


def save_checkpoint(path, params, ema_params=None, opt_state: AdamState | None = None, metadata: dict[str, Any] | None = None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    arrays = {f"params::{k}": v for k, v in _flatten(params).items()}
    if ema_params is not None:
        arrays.update({f"ema::{k}": v for k, v in _flatten(ema_params).items()})
    if opt_state is not None:
        arrays["opt::step"] = np.asarray(opt_state.step)
        arrays.update({f"opt_m::{k}": v for k, v in _flatten(opt_state.m).items()})
        arrays.update({f"opt_v::{k}": v for k, v in _flatten(opt_state.v).items()})
    meta = json.dumps(metadata or {}, sort_keys=True).encode()
    arrays["metadata_json"] = np.frombuffer(meta, dtype=np.uint8)
    np.savez_compressed(path, **arrays)


def load_checkpoint(path, template, with_optimizer=False):
    data = np.load(path, allow_pickle=False)
    params_arrays = {k.split("::", 1)[1]: data[k] for k in data.files if k.startswith("params::")}
    params = _rebuild(template, params_arrays)
    ema_keys = [k for k in data.files if k.startswith("ema::")]
    ema = None
    if ema_keys:
        ema_arrays = {k.split("::", 1)[1]: data[k] for k in ema_keys}
        ema = _rebuild(template, ema_arrays)
    opt = None
    if with_optimizer and "opt::step" in data:
        m_arrays = {k.split("::", 1)[1]: data[k] for k in data.files if k.startswith("opt_m::")}
        v_arrays = {k.split("::", 1)[1]: data[k] for k in data.files if k.startswith("opt_v::")}
        opt = AdamState(jnp.asarray(data["opt::step"]), _rebuild(template, m_arrays), _rebuild(template, v_arrays))
    metadata = json.loads(bytes(data["metadata_json"].tolist()).decode()) if "metadata_json" in data else {}
    return params, ema, opt, metadata
