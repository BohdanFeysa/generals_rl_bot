from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp

from .model import ModelConfig, init_params, forward
from .optim import init_adam, adam_update
from .checkpoint import save_checkpoint
from .dataset import load_shards


def main():
    p = argparse.ArgumentParser(description="Behavior-clone the exact teacher over shuffled candidates")
    p.add_argument("--data", default="datasets/teacher_v4")
    p.add_argument("--out", default="checkpoints_v4/bc_final.npz")
    p.add_argument("--epochs", type=int, default=8)
    p.add_argument("--batch-size", type=int, default=512)
    p.add_argument("--learning-rate", type=float, default=3e-4)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    cfg = ModelConfig()
    params = init_params(jax.random.PRNGKey(args.seed), cfg)
    opt = init_adam(params)

    @jax.jit
    def step(params, opt, batch):
        def loss_fn(p):
            logits, _ = forward(p, batch[0], batch[1], batch[2], batch[3], batch[4], batch[5])
            logp = jax.nn.log_softmax(logits, axis=-1)
            target = batch[6]
            loss = -jnp.mean(jnp.take_along_axis(logp, target[:, None], axis=-1)[:, 0])
            acc = jnp.mean(jnp.argmax(logits, axis=-1) == target)
            return loss, acc
        (loss, acc), grads = jax.value_and_grad(loss_fn, has_aux=True)(params)
        params, opt, norm = adam_update(params, grads, opt, args.learning_rate, weight_decay=1e-5, clip_norm=1.0)
        return params, opt, loss, acc, norm

    rng = np.random.default_rng(args.seed)
    shards = load_shards(args.data)
    step_no = 0
    for epoch in range(args.epochs):
        rng.shuffle(shards)
        losses = []; accs = []
        for shard in shards:
            d = np.load(shard, allow_pickle=False)
            n = len(d["teacher_index"])
            order = rng.permutation(n)
            for start in range(0, n - args.batch_size + 1, args.batch_size):
                ix = order[start:start + args.batch_size]
                batch = (
                    jnp.asarray(d["board"][ix]), jnp.asarray(d["global"][ix]),
                    jnp.asarray(d["candidate"][ix]), jnp.asarray(d["source"][ix], jnp.int32),
                    jnp.asarray(d["destination"][ix], jnp.int32), jnp.asarray(d["mask"][ix], bool),
                    jnp.asarray(d["teacher_index"][ix], jnp.int32),
                )
                params, opt, loss, acc, norm = step(params, opt, batch)
                losses.append(float(loss)); accs.append(float(acc)); step_no += 1
        print(f"epoch={epoch+1} loss={np.mean(losses):.4f} teacher_acc={np.mean(accs):.4f}")
    save_checkpoint(args.out, params, params, opt, {"phase": "bc", "steps": step_no, "teacher_sha256": "8c3ba3a6ec74f7943478f4c8affa1beda1af3f16229c11e2e06d188e6f60eae8"})
    print(f"saved {args.out}")


if __name__ == "__main__":
    main()
