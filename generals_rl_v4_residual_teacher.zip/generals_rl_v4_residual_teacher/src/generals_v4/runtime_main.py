from __future__ import annotations

import json, sys
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp

from . import teacher_exact as exact
from .teacher import ExactTeacher
from .candidates import generate_candidates
from .model import ModelConfig, init_params, forward, policy_logits
from .checkpoint import load_checkpoint


def main():
    base=Path(__file__).resolve().parent.parent; cfg=json.loads((base/"config.json").read_text());template=init_params(jax.random.PRNGKey(0),ModelConfig());params,ema,_,_=load_checkpoint(base/"weights.npz",template);params=ema if ema is not None else params
    first=sys.stdin.readline()
    if not first:return
    _pid,h,w=map(int,first.split());teacher=ExactTeacher();rng=np.random.default_rng(123)
    while True:
        scalar=sys.stdin.readline()
        if not scalar:break
        try:obs=exact._read_observation(sys.stdin,h,w,scalar)
        except EOFError:break
        cs=generate_candidates(obs,teacher,rng,shuffle=False)
        chosen=cs.teacher_index
        try:
            raw,_=forward(params,jnp.asarray(cs.board[None]),jnp.asarray(cs.global_features[None]),jnp.asarray(cs.candidate_features[None]),jnp.asarray(cs.source_indices[None]),jnp.asarray(cs.destination_indices[None]),jnp.asarray(cs.mask[None]));logits=np.asarray(policy_logits(raw,jnp.asarray([cs.teacher_index]),jnp.asarray(cs.mask[None]),cfg["teacher_bonus"],cfg["residual_scale"]))[0];best=int(np.argmax(logits));margin=float(logits[best]-logits[cs.teacher_index]);
            if best==cs.teacher_index or margin>=cfg["confidence_margin"]:chosen=best
        except Exception:
            chosen=cs.teacher_index
        action=cs.actions[chosen];teacher.commit(obs,cs.proposal,action);sys.stdout.write("%d %d %d %d %d\n"%tuple(map(int,action)));sys.stdout.flush()

if __name__=="__main__":main()
