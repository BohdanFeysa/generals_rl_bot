from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp

from .candidates import generate_candidates
from .dataset import ShardBuffer
from .env_utils import stack_player_observations, select_seat, host_observation
from .teacher import TeacherFleet


def main():
    p = argparse.ArgumentParser(description="Collect exact-teacher imitation shards")
    p.add_argument("--samples", type=int, default=100000)
    p.add_argument("--num-envs", type=int, default=32)
    p.add_argument("--pool-size", type=int, default=512)
    p.add_argument("--sample-every", type=int, default=2)
    p.add_argument("--shard-size", type=int, default=4096)
    p.add_argument("--out", default="datasets/teacher_v4")
    p.add_argument("--seed", type=int, default=123)
    args = p.parse_args()

    from generals import GeneralsEnv
    from generals.agents import ExpanderAgent, HunterAgent

    env = GeneralsEnv(mode="competition", pool_size=args.pool_size)
    key = jax.random.PRNGKey(args.seed)
    key, pool_key = jax.random.split(key)
    pool, _ = env.reset(pool_key)
    idx = jnp.arange(args.num_envs, dtype=jnp.int32) % args.pool_size
    states = jax.tree.map(lambda x: x[idx], pool)._replace(pool_idx=(idx + args.num_envs) % args.pool_size)
    get_obs = jax.jit(jax.vmap(stack_player_observations))
    step_batch = jax.jit(jax.vmap(lambda s, a: env.step(s, a, pool)))
    expander = ExpanderAgent(); hunter = HunterAgent()
    exp_act = jax.jit(jax.vmap(expander.act)); hunt_act = jax.jit(jax.vmap(hunter.act))
    seat = jnp.arange(args.num_envs, dtype=jnp.int32) % 2
    other = 1 - seat
    # 50% teacher mirror, 25% Hunter, 25% Expander.
    opponent_type = np.arange(args.num_envs) % 4
    learner_fleet = TeacherFleet(args.num_envs, args.seed + 1000)
    opponent_fleet = TeacherFleet(args.num_envs, args.seed + 2000)
    rngs = [np.random.default_rng(args.seed + 3000 + i) for i in range(args.num_envs)]
    writer = ShardBuffer(Path(args.out), args.shard_size)
    obs = get_obs(states)
    collected = 0
    env_turn = np.zeros(args.num_envs, dtype=np.int32)

    while collected < args.samples:
        learner_obs_b = select_seat(obs, seat)
        opp_obs_b = select_seat(obs, other)
        learner_actions = np.zeros((args.num_envs, 5), np.int32)
        opponent_actions = np.zeros((args.num_envs, 5), np.int32)
        proposals = []
        for i in range(args.num_envs):
            hobs = host_observation(learner_obs_b, i)
            cs = generate_candidates(hobs, learner_fleet.agents[i], rngs[i], shuffle=True)
            proposals.append(cs.proposal)
            learner_actions[i] = cs.proposal.action
            if env_turn[i] % args.sample_every == 0 and collected < args.samples:
                writer.add({
                    "board": cs.board.astype(np.float16),
                    "global": cs.global_features.astype(np.float16),
                    "candidate": cs.candidate_features.astype(np.float16),
                    "actions": cs.actions.astype(np.int16),
                    "source": cs.source_indices.astype(np.int16),
                    "destination": cs.destination_indices.astype(np.int16),
                    "mask": cs.mask.astype(np.uint8),
                    "teacher_index": np.asarray(cs.teacher_index, np.int16),
                })
                collected += 1

        key, k1, k2 = jax.random.split(key, 3)
        exp_actions = np.asarray(exp_act(opp_obs_b, jax.random.split(k1, args.num_envs)))
        hunter_actions = np.asarray(hunt_act(opp_obs_b, jax.random.split(k2, args.num_envs)))
        opp_props = [None] * args.num_envs
        for i in range(args.num_envs):
            if opponent_type[i] < 2:
                hobs = host_observation(opp_obs_b, i)
                prop = opponent_fleet.agents[i].propose(hobs)
                opponent_actions[i] = prop.action
                opp_props[i] = (hobs, prop)
            elif opponent_type[i] == 2:
                opponent_actions[i] = hunter_actions[i]
            else:
                opponent_actions[i] = exp_actions[i]
        actions = np.zeros((args.num_envs, 2, 5), np.int32)
        rows = np.arange(args.num_envs)
        actions[rows, np.asarray(seat)] = learner_actions
        actions[rows, np.asarray(other)] = opponent_actions
        timestep, states = step_batch(states, jnp.asarray(actions))
        done = np.asarray(timestep.terminated | timestep.truncated)
        for i in range(args.num_envs):
            hobs = host_observation(learner_obs_b, i)
            learner_fleet.agents[i].commit(hobs, proposals[i], learner_actions[i])
            if opp_props[i] is not None:
                oh, op = opp_props[i]
                opponent_fleet.agents[i].commit(oh, op, opponent_actions[i])
            env_turn[i] += 1
            if done[i]:
                learner_fleet.reset(i); opponent_fleet.reset(i); env_turn[i] = 0
        obs = timestep.observation
        if collected % 4096 < args.num_envs:
            print(f"collected={collected}/{args.samples}")
    writer.flush()


if __name__ == "__main__":
    main()
