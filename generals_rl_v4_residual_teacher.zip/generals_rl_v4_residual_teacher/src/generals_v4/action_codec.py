from __future__ import annotations

import numpy as np

BOARD = 21
DIR_DR = np.asarray([-1, 1, 0, 0], dtype=np.int32)
DIR_DC = np.asarray([0, 0, -1, 1], dtype=np.int32)
PASS = np.asarray([1, 0, 0, 0, 0], dtype=np.int32)


def action_key(action: np.ndarray) -> tuple[int, int, int, int, int]:
    return tuple(map(int, np.asarray(action).tolist()))


def move_destination(action: np.ndarray) -> tuple[int, int] | None:
    a = np.asarray(action, dtype=np.int32)
    if int(a[0]) != 0:
        return None
    r, c, d = map(int, a[1:4])
    if not 0 <= d < 4:
        return None
    nr, nc = r + int(DIR_DR[d]), c + int(DIR_DC[d])
    return (nr, nc) if 0 <= nr < BOARD and 0 <= nc < BOARD else None


def action_source_destination(action: np.ndarray) -> tuple[int, int]:
    a = np.asarray(action, dtype=np.int32)
    kind = int(a[0])
    if kind == 0:
        src = int(a[1]) * BOARD + int(a[2])
        dst_rc = move_destination(a)
        dst = src if dst_rc is None else dst_rc[0] * BOARD + dst_rc[1]
        return src, dst
    if kind == 2:
        cell = int(a[1]) * BOARD + int(a[2])
        return cell, cell
    return 0, 0
