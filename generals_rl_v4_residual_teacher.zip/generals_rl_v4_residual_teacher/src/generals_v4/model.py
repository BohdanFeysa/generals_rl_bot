from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import jax
import jax.numpy as jnp
import numpy as np

from .candidates import BOARD_CHANNELS, GLOBAL_FEATURES, CANDIDATE_FEATURES, MAX_CANDIDATES


@dataclass(frozen=True)
class ModelConfig:
    board_channels: int = BOARD_CHANNELS
    global_features: int = GLOBAL_FEATURES
    candidate_features: int = CANDIDATE_FEATURES
    max_candidates: int = MAX_CANDIDATES
    conv_channels: int = 32
    residual_blocks: int = 2
    candidate_hidden: int = 64
    trunk_hidden: int = 128


def _glorot(key, shape):
    fan_in = np.prod(shape[:-1])
    fan_out = shape[-1]
    limit = np.sqrt(6.0 / float(fan_in + fan_out))
    return jax.random.uniform(key, shape, minval=-limit, maxval=limit, dtype=jnp.float32)


def _dense(key, in_dim, out_dim, zero=False):
    return {
        "w": jnp.zeros((in_dim, out_dim), jnp.float32) if zero else _glorot(key, (in_dim, out_dim)),
        "b": jnp.zeros((out_dim,), jnp.float32),
    }


def _conv(key, in_ch, out_ch, zero=False):
    shape = (3, 3, in_ch, out_ch)
    return {
        "w": jnp.zeros(shape, jnp.float32) if zero else _glorot(key, shape),
        "b": jnp.zeros((out_ch,), jnp.float32),
    }


def init_params(key: jax.Array, cfg: ModelConfig = ModelConfig()) -> dict[str, Any]:
    keys = iter(jax.random.split(key, 32))
    p: dict[str, Any] = {"conv_in": _conv(next(keys), cfg.board_channels, cfg.conv_channels)}
    p["res"] = []
    for _ in range(cfg.residual_blocks):
        p["res"].append({
            "a": _conv(next(keys), cfg.conv_channels, cfg.conv_channels),
            "b": _conv(next(keys), cfg.conv_channels, cfg.conv_channels),
        })
    p["global"] = _dense(next(keys), cfg.global_features, cfg.candidate_hidden)
    p["candidate"] = _dense(next(keys), cfg.candidate_features, cfg.candidate_hidden)
    combined = cfg.conv_channels * 3 + cfg.candidate_hidden * 2
    p["trunk1"] = _dense(next(keys), combined, cfg.trunk_hidden)
    p["trunk2"] = _dense(next(keys), cfg.trunk_hidden, cfg.candidate_hidden)
    p["policy"] = _dense(next(keys), cfg.candidate_hidden, 1, zero=True)
    p["value1"] = _dense(next(keys), cfg.conv_channels + cfg.candidate_hidden, cfg.candidate_hidden)
    p["value2"] = _dense(next(keys), cfg.candidate_hidden, 1, zero=True)
    return p


def _conv_apply(p, x):
    y = jax.lax.conv_general_dilated(
        x, p["w"], window_strides=(1, 1), padding="SAME",
        dimension_numbers=("NHWC", "HWIO", "NHWC"),
    )
    return y + p["b"]


def _dense_apply(p, x):
    return x @ p["w"] + p["b"]


def forward(params, board, global_features, candidate_features, source_indices, destination_indices, mask):
    x = jax.nn.relu(_conv_apply(params["conv_in"], board.astype(jnp.float32)))
    for block in params["res"]:
        y = jax.nn.relu(_conv_apply(block["a"], x))
        y = _conv_apply(block["b"], y)
        x = jax.nn.relu(x + y)
    b = x.shape[0]
    spatial = x.reshape((b, 441, x.shape[-1]))
    batch = jnp.arange(b)[:, None]
    src = spatial[batch, source_indices]
    dst = spatial[batch, destination_indices]
    pooled = jnp.mean(x, axis=(1, 2))
    g = jax.nn.relu(_dense_apply(params["global"], global_features.astype(jnp.float32)))
    c = jax.nn.relu(_dense_apply(params["candidate"], candidate_features.astype(jnp.float32)))
    gk = jnp.broadcast_to(g[:, None, :], (b, candidate_features.shape[1], g.shape[-1]))
    pk = jnp.broadcast_to(pooled[:, None, :], (b, candidate_features.shape[1], pooled.shape[-1]))
    z = jnp.concatenate([src, dst, pk, gk, c], axis=-1)
    z = jax.nn.relu(_dense_apply(params["trunk1"], z))
    z = jax.nn.relu(_dense_apply(params["trunk2"], z))
    logits = _dense_apply(params["policy"], z)[..., 0]
    logits = jnp.where(mask, logits, -1.0e30)
    value = _dense_apply(params["value2"], jax.nn.relu(_dense_apply(params["value1"], jnp.concatenate([pooled, g], -1))))[..., 0]
    return logits, value


def policy_logits(raw_logits, teacher_index, mask, teacher_bonus: float, residual_scale: float):
    bonus = jax.nn.one_hot(teacher_index, raw_logits.shape[-1]) * teacher_bonus
    logits = residual_scale * jnp.tanh(raw_logits) + bonus
    return jnp.where(mask, logits, -1.0e30)
