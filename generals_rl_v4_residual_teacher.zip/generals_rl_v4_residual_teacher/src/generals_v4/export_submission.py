from __future__ import annotations

import argparse, json, shutil, zipfile
from pathlib import Path
import jax
from .model import ModelConfig, init_params
from .checkpoint import load_checkpoint, save_checkpoint


def main():
    p=argparse.ArgumentParser();p.add_argument("checkpoint");p.add_argument("--out",default="submission_build/v4_residual");p.add_argument("--teacher-bonus",type=float,default=1.5);p.add_argument("--residual-scale",type=float,default=2.0);p.add_argument("--confidence-margin",type=float,default=0.10);args=p.parse_args()
    root=Path(args.out); shutil.rmtree(root,ignore_errors=True);root.mkdir(parents=True)
    cfg=ModelConfig();template=init_params(jax.random.PRNGKey(0),cfg);params,ema,_,meta=load_checkpoint(args.checkpoint,template);chosen=ema if ema is not None else params
    save_checkpoint(root/"weights.npz",chosen,chosen,None,{"export":True,**meta})
    package_src=Path(__file__).resolve().parent
    package_dst=root/"generals_v4"; package_dst.mkdir()
    for name in ["runtime_main.py","teacher_exact.py","teacher.py","candidates.py","action_codec.py","model.py","checkpoint.py","optim.py","__init__.py"]:
        shutil.copy2(package_src/name,package_dst/name)
    (root/"config.json").write_text(json.dumps({"teacher_bonus":args.teacher_bonus,"residual_scale":args.residual_scale,"confidence_margin":args.confidence_margin}))
    (root/"main.py").write_text("from generals_v4.runtime_main import main\nif __name__ == '__main__': main()\n")
    (root/"run.sh").write_text("#!/usr/bin/env bash\nset -euo pipefail\nexport JAX_PLATFORMS=cpu\nexport GENERALS_V4_TEACHER_CPU_ONLY=1\nexport XLA_PYTHON_CLIENT_PREALLOCATE=false\nexec python3 \"$(dirname \"$0\")/main.py\"\n")
    (root/"run.sh").chmod(0o755)
    zip_path=root.with_suffix(".zip")
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as z:
        for f in root.rglob("*"):
            if f.is_file(): z.write(f,f.relative_to(root))
    print(zip_path)

if __name__=="__main__":main()
