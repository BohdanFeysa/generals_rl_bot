from __future__ import annotations

from typing import NamedTuple
import jax
import jax.numpy as jnp


class AdamState(NamedTuple):
    step: jax.Array
    m: object
    v: object


def init_adam(params):
    zeros = jax.tree.map(jnp.zeros_like, params)
    return AdamState(jnp.asarray(0, jnp.int32), zeros, zeros)


def global_norm(tree):
    return jnp.sqrt(sum(jnp.sum(jnp.square(x)) for x in jax.tree.leaves(tree)))


def adam_update(params, grads, state: AdamState, lr: float, weight_decay: float = 0.0, clip_norm: float = 1.0):
    norm = global_norm(grads)
    scale = jnp.minimum(1.0, clip_norm / (norm + 1e-8))
    grads = jax.tree.map(lambda g: g * scale, grads)
    step = state.step + 1
    b1, b2, eps = 0.9, 0.999, 1e-8
    m = jax.tree.map(lambda m0, g: b1 * m0 + (1 - b1) * g, state.m, grads)
    v = jax.tree.map(lambda v0, g: b2 * v0 + (1 - b2) * jnp.square(g), state.v, grads)
    b1c = 1.0 - b1 ** step.astype(jnp.float32)
    b2c = 1.0 - b2 ** step.astype(jnp.float32)
    updates = jax.tree.map(lambda mm, vv, p: mm / b1c / (jnp.sqrt(vv / b2c) + eps) + weight_decay * p, m, v, params)
    params = jax.tree.map(lambda p, u: p - lr * u, params, updates)
    return params, AdamState(step, m, v), norm
