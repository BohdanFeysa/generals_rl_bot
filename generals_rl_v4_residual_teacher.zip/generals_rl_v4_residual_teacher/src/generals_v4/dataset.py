from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import numpy as np


@dataclass
class ShardBuffer:
    out_dir: Path
    shard_size: int = 4096

    def __post_init__(self):
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.items: list[dict[str, np.ndarray]] = []
        self.index = len(list(self.out_dir.glob("shard_*.npz")))

    def add(self, sample: dict[str, np.ndarray]):
        self.items.append(sample)
        if len(self.items) >= self.shard_size:
            self.flush()

    def flush(self):
        if not self.items:
            return
        keys = self.items[0].keys()
        arrays = {k: np.stack([x[k] for x in self.items]) for k in keys}
        path = self.out_dir / f"shard_{self.index:05d}.npz"
        np.savez_compressed(path, **arrays)
        print(f"wrote {path} samples={len(self.items)}")
        self.index += 1
        self.items.clear()


def load_shards(path: str | Path):
    files = sorted(Path(path).glob("shard_*.npz"))
    if not files:
        raise FileNotFoundError(f"no shard_*.npz files under {path}")
    return files
