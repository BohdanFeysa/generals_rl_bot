"""Generals v4: exact-teacher candidate policy plus bounded residual RL."""

__version__ = "4.0.0"
