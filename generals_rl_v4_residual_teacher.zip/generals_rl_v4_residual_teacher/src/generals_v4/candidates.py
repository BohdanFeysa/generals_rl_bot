from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

import numpy as np

from .action_codec import BOARD, DIR_DR, DIR_DC, PASS, action_key, action_source_destination, move_destination
from .teacher import ExactTeacher, TeacherProposal
from . import teacher_exact as exact

MAX_CANDIDATES = 32
BOARD_CHANNELS = 12
GLOBAL_FEATURES = 20
CANDIDATE_FEATURES = 28


@dataclass
class CandidateSet:
    board: np.ndarray
    global_features: np.ndarray
    candidate_features: np.ndarray
    actions: np.ndarray
    source_indices: np.ndarray
    destination_indices: np.ndarray
    mask: np.ndarray
    teacher_index: int
    proposal: TeacherProposal


def _np(obs: Any, name: str, dtype=None):
    arr = np.asarray(getattr(obs, name))
    return arr.astype(dtype) if dtype is not None else arr


def _cardinal(mask: np.ndarray) -> np.ndarray:
    p = np.pad(mask.astype(np.int32), 1)
    return p[:-2, 1:-1] + p[2:, 1:-1] + p[1:-1, :-2] + p[1:-1, 2:]


def _neighbor8(mask: np.ndarray) -> np.ndarray:
    p = np.pad(mask.astype(np.int32), 1)
    out = np.zeros((BOARD, BOARD), dtype=np.int32)
    for dr in range(3):
        for dc in range(3):
            if dr != 1 or dc != 1:
                out += p[dr:dr + BOARD, dc:dc + BOARD]
    return out


def _castle_cost(structures: np.ndarray) -> np.ndarray:
    rr, cc = np.indices((BOARD, BOARD))
    result = np.full((BOARD, BOARD), 35, dtype=np.int32)
    for r, c in np.argwhere(structures):
        d = np.abs(rr - int(r)) + np.abs(cc - int(c))
        result += np.maximum(0, 14 - 2 * d)
    return result


def _own_general(obs: Any) -> np.ndarray:
    return _np(obs, "generals", bool) & _np(obs, "owned_cells", bool)


def board_features(obs: Any, teacher: ExactTeacher) -> tuple[np.ndarray, np.ndarray]:
    armies = _np(obs, "armies", np.float32)
    owned = _np(obs, "owned_cells", bool)
    opponent = _np(obs, "opponent_cells", bool)
    neutral = _np(obs, "neutral_cells", bool)
    fog = _np(obs, "fog_cells", bool)
    mountains = _np(obs, "mountains", bool)
    generals = _np(obs, "generals", bool)
    castles = _np(obs, "castles", bool)
    structures_fog = _np(obs, "structures_in_fog", bool)
    own_general = generals & owned
    main = np.zeros((BOARD, BOARD), dtype=np.float32)
    if teacher.state.main_stack is not None:
        r, c = teacher.state.main_stack
        if 0 <= r < BOARD and 0 <= c < BOARD:
            main[r, c] = 1.0
    memory = np.zeros((BOARD, BOARD), dtype=np.float32)
    if teacher.state.enemy_memory is not None:
        r = int(np.clip(round(teacher.state.enemy_memory[0]), 0, BOARD - 1))
        c = int(np.clip(round(teacher.state.enemy_memory[1]), 0, BOARD - 1))
        memory[r, c] = 1.0
    board = np.stack([
        owned, opponent, neutral, fog, mountains, generals, castles,
        structures_fog, np.log1p(armies) / 9.0, own_general, main, memory,
    ], axis=-1).astype(np.float32)

    turn = float(np.asarray(obs.timestep))
    my_land = float(np.asarray(obs.owned_land_count))
    my_army = float(np.asarray(obs.owned_army_count))
    opp_land = float(np.asarray(obs.opponent_land_count))
    opp_army = float(np.asarray(obs.opponent_army_count))
    own_castles = castles & owned
    gr, gc = (np.argwhere(own_general)[0] if own_general.any() else np.asarray([0, 0]))
    general_army = float(armies[int(gr), int(gc)]) if own_general.any() else 0.0
    main_valid = teacher.state.main_stack is not None
    mr, mc = teacher.state.main_stack if main_valid else (0, 0)
    main_army = float(armies[mr, mc]) if main_valid and owned[mr, mc] else 0.0
    mem_valid = teacher.state.enemy_memory is not None
    er, ec = teacher.state.enemy_memory if mem_valid else (0.0, 0.0)
    global_f = np.asarray([
        turn / 1200.0,
        my_land / 441.0,
        opp_land / 441.0,
        np.log1p(my_army) / 10.0,
        np.log1p(opp_army) / 10.0,
        np.tanh((np.log1p(my_army) - np.log1p(opp_army)) / 4.0),
        float(own_castles.sum()) / 12.0,
        float((castles & opponent).sum()) / 12.0,
        float(fog.mean()),
        np.log1p(general_army) / 9.0,
        float(gr) / 20.0,
        float(gc) / 20.0,
        float(main_valid),
        np.log1p(main_army) / 9.0,
        float(mr) / 20.0,
        float(mc) / 20.0,
        float(mem_valid),
        float(er) / 20.0,
        float(ec) / 20.0,
        min(float(teacher.state.lost_turns), 5.0) / 5.0,
    ], dtype=np.float32)
    return board, global_f


def _simple_objective(obs: Any, teacher: ExactTeacher) -> tuple[int, int]:
    t_obs = exact.Observation(*[getattr(obs, f) for f in exact.Observation._fields])
    state_copy = replace(teacher.state)
    source = teacher.state.main_stack
    if source is None:
        armies = _np(obs, "armies", np.int32)
        owned = _np(obs, "owned_cells", bool)
        mask = owned & (armies > 1)
        if mask.any():
            source = tuple(map(int, np.unravel_index(int(np.argmax(np.where(mask, armies, -1))), armies.shape)))
        else:
            source = (0, 0)
    target = exact._objective_cell_np(t_obs, source, state_copy)
    return source if target is None else target


def _candidate_feature(obs: Any, teacher: ExactTeacher, action: np.ndarray, simple_score: float) -> np.ndarray:
    armies = _np(obs, "armies", np.float32)
    owned = _np(obs, "owned_cells", bool)
    opponent = _np(obs, "opponent_cells", bool)
    neutral = _np(obs, "neutral_cells", bool)
    fog = _np(obs, "fog_cells", bool)
    generals = _np(obs, "generals", bool)
    castles = _np(obs, "castles", bool)
    own_general = generals & owned
    kind = int(action[0])
    src, dst = action_source_destination(action)
    sr, sc = divmod(src, BOARD)
    dr, dc = divmod(dst, BOARD)
    src_army = float(armies[sr, sc]) if kind != 1 else 0.0
    dst_army = float(armies[dr, dc]) if kind == 0 else 0.0
    margin = src_army - 1.0 - dst_army if kind == 0 else 0.0
    gr, gc = (np.argwhere(own_general)[0] if own_general.any() else np.asarray([0, 0]))
    main = teacher.state.main_stack
    mem = teacher.state.enemy_memory
    dist_src_g = abs(sr - int(gr)) + abs(sc - int(gc))
    dist_dst_g = abs(dr - int(gr)) + abs(dc - int(gc))
    dist_dst_main = 40 if main is None else abs(dr - main[0]) + abs(dc - main[1])
    dist_dst_mem = 40 if mem is None else abs(dr - mem[0]) + abs(dc - mem[1])
    owned_n = _cardinal(owned)
    exposed = _cardinal(opponent | fog)
    info = _neighbor8(fog)
    structures = own_general | (castles & owned)
    cost = _castle_cost(structures)
    my_army = max(float(np.asarray(obs.owned_army_count)), 1.0)
    opp_army = max(float(np.asarray(obs.opponent_army_count)), 1.0)
    deathtouch = float(np.asarray(obs.timestep)) >= 800.0
    is_move = kind == 0
    return np.asarray([
        float(kind == 0), float(kind == 1), float(kind == 2),
        float(action[4]) if is_move else 0.0,
        np.log1p(src_army) / 9.0,
        np.log1p(dst_army) / 9.0,
        np.tanh(margin / 50.0),
        float(own_general[sr, sc]) if kind != 1 else 0.0,
        float(castles[sr, sc] and owned[sr, sc]) if kind != 1 else 0.0,
        float(opponent[dr, dc]) if is_move else 0.0,
        float(neutral[dr, dc]) if is_move else 0.0,
        float(fog[dr, dc]) if is_move else 0.0,
        float(generals[dr, dc] and opponent[dr, dc]) if is_move else 0.0,
        float(castles[dr, dc]) if is_move else 0.0,
        float(owned[dr, dc]) if is_move else 0.0,
        float(is_move and deathtouch and generals[dr, dc] and opponent[dr, dc]),
        dist_src_g / 40.0, dist_dst_g / 40.0,
        dist_dst_main / 40.0, dist_dst_mem / 40.0,
        float(main == (sr, sc)),
        float(cost[sr, sc]) / 100.0 if kind == 2 else 0.0,
        float(owned_n[sr, sc]) / 4.0 if kind != 1 else 0.0,
        float(exposed[sr, sc]) / 4.0 if kind != 1 else 0.0,
        float(info[dr, dc]) / 8.0 if is_move else 0.0,
        np.tanh(simple_score / 10000.0),
        src_army / my_army,
        dst_army / opp_army,
    ], dtype=np.float32)


def generate_candidates(obs: Any, teacher: ExactTeacher, rng: np.random.Generator | None = None, shuffle: bool = True) -> CandidateSet:
    proposal = teacher.propose(obs)
    armies = _np(obs, "armies", np.int32)
    owned = _np(obs, "owned_cells", bool)
    opponent = _np(obs, "opponent_cells", bool)
    neutral = _np(obs, "neutral_cells", bool)
    fog = _np(obs, "fog_cells", bool)
    mountains = _np(obs, "mountains", bool)
    generals = _np(obs, "generals", bool)
    castles = _np(obs, "castles", bool)
    own_general = generals & owned
    target = _simple_objective(obs, teacher)
    tr, tc = target
    info = _neighbor8(fog)
    actions_with_score: list[tuple[np.ndarray, float]] = [(proposal.action.copy(), 1.0e12), (PASS.copy(), -500.0)]

    rows, cols = np.indices((BOARD, BOARD))
    move_candidates: list[tuple[float, np.ndarray]] = []
    turn = int(np.asarray(obs.timestep))
    top_sources = set()
    movable_mask = owned & (armies > 1)
    if movable_mask.any():
        flat = np.argsort(np.where(movable_mask, armies, -1).reshape(-1))[-6:]
        for x in flat:
            r, c = divmod(int(x), BOARD)
            if movable_mask[r, c]:
                top_sources.add((r, c))
    if teacher.state.main_stack is not None:
        top_sources.add(teacher.state.main_stack)
    if int(proposal.action[0]) == 0:
        top_sources.add((int(proposal.action[1]), int(proposal.action[2])))

    for r, c in np.argwhere(movable_mask):
        r, c = int(r), int(c)
        for d in range(4):
            nr, nc = r + int(DIR_DR[d]), c + int(DIR_DC[d])
            if not (0 <= nr < BOARD and 0 <= nc < BOARD) or mountains[nr, nc]:
                continue
            margin = int(armies[r, c]) - 1 - int(armies[nr, nc])
            score = 0.02 * int(armies[r, c])
            if generals[nr, nc] and opponent[nr, nc] and (margin > 0 or turn >= 800):
                score += 1.0e9
            elif opponent[nr, nc]:
                score += 15000.0 + 30.0 * margin
            elif fog[nr, nc]:
                score += 700.0 + 40.0 * info[nr, nc]
            elif neutral[nr, nc]:
                score += 500.0 + 20.0 * info[nr, nc]
            elif owned[nr, nc]:
                progress = (abs(r - tr) + abs(c - tc)) - (abs(nr - tr) + abs(nc - tc))
                score += 220.0 * progress - 80.0
            for split in (0, 1):
                a = np.asarray([0, r, c, d, split], dtype=np.int32)
                s = score - (35.0 if split else 0.0)
                if (r, c) in top_sources or score >= 400.0:
                    move_candidates.append((s, a))
    move_candidates.sort(key=lambda x: x[0], reverse=True)
    actions_with_score.extend((a, s) for s, a in move_candidates[:24])

    structures = own_general | (castles & owned)
    cost = _castle_cost(structures)
    owned_n = _cardinal(owned)
    exposed = _cardinal(opponent | fog)
    build_mask = owned & ~generals & ~castles & ~mountains & (armies >= cost + 5)
    build_score = 8.0 * (armies - cost) - 12.0 * cost + 60.0 * owned_n - 100.0 * exposed
    for flat in np.argsort(np.where(build_mask, build_score, -1e30).reshape(-1))[-6:][::-1]:
        r, c = divmod(int(flat), BOARD)
        if build_mask[r, c]:
            actions_with_score.append((np.asarray([2, r, c, 0, 0], dtype=np.int32), float(build_score[r, c])))

    dedup: list[tuple[np.ndarray, float]] = []
    seen = set()
    for action, score in actions_with_score:
        k = action_key(action)
        if k not in seen:
            seen.add(k)
            dedup.append((action, score))
        if len(dedup) >= MAX_CANDIDATES:
            break
    teacher_key = action_key(proposal.action)
    if not any(action_key(a) == teacher_key for a, _ in dedup):
        dedup[-1] = (proposal.action.copy(), 1.0e12)

    if shuffle and len(dedup) > 1:
        rng = np.random.default_rng() if rng is None else rng
        perm = rng.permutation(len(dedup))
        dedup = [dedup[int(i)] for i in perm]

    actions = np.zeros((MAX_CANDIDATES, 5), dtype=np.int32)
    feats = np.zeros((MAX_CANDIDATES, CANDIDATE_FEATURES), dtype=np.float32)
    src = np.zeros((MAX_CANDIDATES,), dtype=np.int32)
    dst = np.zeros((MAX_CANDIDATES,), dtype=np.int32)
    mask = np.zeros((MAX_CANDIDATES,), dtype=bool)
    teacher_index = -1
    for i, (a, score) in enumerate(dedup):
        actions[i] = a
        feats[i] = _candidate_feature(obs, teacher, a, score)
        src[i], dst[i] = action_source_destination(a)
        mask[i] = True
        if action_key(a) == teacher_key:
            teacher_index = i
    if teacher_index < 0:
        raise RuntimeError("teacher action missing from candidate set")
    board, global_f = board_features(obs, teacher)
    return CandidateSet(board, global_f, feats, actions, src, dst, mask, teacher_index, proposal)
