from __future__ import annotations

import argparse
import numpy as np
import jax
import jax.numpy as jnp

from .candidates import generate_candidates
from .teacher import TeacherFleet
from .env_utils import stack_player_observations, select_seat, host_observation
from .model import ModelConfig, init_params, forward, policy_logits
from .checkpoint import load_checkpoint


def main():
    p=argparse.ArgumentParser(); p.add_argument("checkpoint"); p.add_argument("--opponent",choices=["teacher","hunter","expander","all"],default="all"); p.add_argument("--games",type=int,default=128); p.add_argument("--seed",type=int,default=123); p.add_argument("--teacher-bonus",type=float,default=1.5); p.add_argument("--residual-scale",type=float,default=2.0); p.add_argument("--confidence-margin",type=float,default=0.0); args=p.parse_args()
    from generals import GeneralsEnv
    from generals.agents import ExpanderAgent,HunterAgent
    cfg=ModelConfig(); template=init_params(jax.random.PRNGKey(0),cfg); params,ema,_,meta=load_checkpoint(args.checkpoint,template); params=ema if ema is not None else params
    names=["teacher","hunter","expander"] if args.opponent=="all" else [args.opponent]
    for off,name in enumerate(names):
        env=GeneralsEnv(mode="competition",pool_size=max(args.games,256)); key=jax.random.PRNGKey(args.seed+off); key,pool_key=jax.random.split(key); pool,_=env.reset(pool_key); idx=jnp.arange(args.games)%env.pool_size; states=jax.tree.map(lambda x:x[idx],pool)._replace(pool_idx=(idx+args.games)%env.pool_size)
        get_obs=jax.jit(jax.vmap(stack_player_observations)); step=jax.jit(jax.vmap(lambda s,a:env.step(s,a,pool))); exp=ExpanderAgent();hunt=HunterAgent(); exp_act=jax.jit(jax.vmap(exp.act));hunt_act=jax.jit(jax.vmap(hunt.act))
        seat=jnp.arange(args.games)%2;other=1-seat; fleet=TeacherFleet(args.games,args.seed+1000);oppfleet=TeacherFleet(args.games,args.seed+2000);rngs=[np.random.default_rng(args.seed+3000+i) for i in range(args.games)];obs=get_obs(states);finished=np.zeros(args.games,bool);wins=np.zeros(args.games,bool);losses=np.zeros(args.games,bool);overrides=0;decisions=0
        for _ in range(1200):
            lob=select_seat(obs,seat);oob=select_seat(obs,other);sets=[generate_candidates(host_observation(lob,i),fleet.agents[i],rngs[i],shuffle=False) for i in range(args.games)]
            raw,val=forward(params,jnp.asarray(np.stack([x.board for x in sets])),jnp.asarray(np.stack([x.global_features for x in sets])),jnp.asarray(np.stack([x.candidate_features for x in sets])),jnp.asarray(np.stack([x.source_indices for x in sets])),jnp.asarray(np.stack([x.destination_indices for x in sets])),jnp.asarray(np.stack([x.mask for x in sets])))
            logits=np.asarray(policy_logits(raw,jnp.asarray([x.teacher_index for x in sets]),jnp.asarray(np.stack([x.mask for x in sets])),args.teacher_bonus,args.residual_scale)); chosen=np.argmax(logits,axis=-1);teacher_idx=np.asarray([x.teacher_index for x in sets]);
            if args.confidence_margin>0:
                rows=np.arange(args.games); margin=logits[rows,chosen]-logits[rows,teacher_idx]; chosen=np.where((chosen!=teacher_idx)&(margin<args.confidence_margin),teacher_idx,chosen)
            la=np.stack([sets[i].actions[chosen[i]] for i in range(args.games)]);overrides+=int(np.sum(chosen!=teacher_idx));decisions+=args.games
            key,k1=jax.random.split(key); oppprops=[None]*args.games
            if name=="teacher":
                oa=np.zeros((args.games,5),np.int32)
                for i in range(args.games):
                    oh=host_observation(oob,i);op=oppfleet.agents[i].propose(oh);oa[i]=op.action;oppprops[i]=(oh,op)
            elif name=="hunter": oa=np.asarray(hunt_act(oob,jax.random.split(k1,args.games)))
            else: oa=np.asarray(exp_act(oob,jax.random.split(k1,args.games)))
            actions=np.zeros((args.games,2,5),np.int32);rows=np.arange(args.games);actions[rows,np.asarray(seat)]=la;actions[rows,np.asarray(other)]=oa;ts,states=step(states,jnp.asarray(actions));done=np.asarray(ts.terminated|ts.truncated)
            for i in range(args.games):
                h=host_observation(lob,i);fleet.agents[i].commit(h,sets[i].proposal,la[i]);
                if oppprops[i] is not None: oh,op=oppprops[i];oppfleet.agents[i].commit(oh,op,oa[i])
                if done[i]: fleet.reset(i);oppfleet.reset(i)
            just=(~finished)&done;winner=np.asarray(ts.info.winner);wins|=just&(winner==np.asarray(seat));losses|=just&(winner==np.asarray(other));finished|=just;obs=ts.observation
            if finished.all(): break
        w=int(wins.sum());l=int(losses.sum());d=args.games-w-l;score=(w+.5*d)/args.games;print(f"v4 vs {name}: games={args.games} wins={w} losses={l} draws={d} score={score:.4f} override={overrides/max(decisions,1):.3f}")

if __name__=="__main__":main()
