from __future__ import annotations

import jax
import jax.numpy as jnp
import numpy as np


def stack_player_observations(state):
    from generals.core import game
    p0 = game.get_observation(state, 0)
    p1 = game.get_observation(state, 1)
    return jax.tree.map(lambda a, b: jnp.stack([a, b], axis=0), p0, p1)


def select_seat(tree, seat):
    n = seat.shape[0]
    return jax.tree.map(lambda x: x[jnp.arange(n), seat], tree)


def host_observation(batch, i: int):
    return jax.tree.map(lambda x: np.asarray(x[i]), batch)


def potential(obs):
    land = (obs.owned_land_count.astype(jnp.float32) - obs.opponent_land_count.astype(jnp.float32)) / 441.0
    army = jnp.tanh((jnp.log1p(obs.owned_army_count.astype(jnp.float32)) - jnp.log1p(obs.opponent_army_count.astype(jnp.float32))) / 4.0)
    own_castles = jnp.sum(obs.castles & obs.owned_cells, axis=(-2, -1)).astype(jnp.float32)
    opp_castles = jnp.sum(obs.castles & obs.opponent_cells, axis=(-2, -1)).astype(jnp.float32)
    return 0.18 * land + 0.07 * army + 0.03 * (own_castles - opp_castles) / 10.0
