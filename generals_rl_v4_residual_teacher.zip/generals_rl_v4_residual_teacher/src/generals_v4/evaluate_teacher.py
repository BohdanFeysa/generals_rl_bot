from __future__ import annotations

import argparse
import numpy as np
import jax
import jax.numpy as jnp

from .teacher import TeacherFleet
from .env_utils import stack_player_observations, select_seat, host_observation


def main():
    p = argparse.ArgumentParser(description="Benchmark the immutable exact teacher")
    p.add_argument("--opponent", choices=["teacher", "hunter", "expander", "all"], default="all")
    p.add_argument("--games", type=int, default=128)
    p.add_argument("--seed", type=int, default=123)
    args = p.parse_args()
    from generals import GeneralsEnv
    from generals.agents import ExpanderAgent, HunterAgent
    names = ["teacher", "hunter", "expander"] if args.opponent == "all" else [args.opponent]
    for off, name in enumerate(names):
        env = GeneralsEnv(mode="competition", pool_size=max(args.games, 256))
        key = jax.random.PRNGKey(args.seed + off)
        key, pool_key = jax.random.split(key)
        pool, _ = env.reset(pool_key)
        idx = jnp.arange(args.games, dtype=jnp.int32) % env.pool_size
        states = jax.tree.map(lambda x: x[idx], pool)._replace(pool_idx=(idx + args.games) % env.pool_size)
        get_obs = jax.jit(jax.vmap(stack_player_observations))
        step = jax.jit(jax.vmap(lambda s, a: env.step(s, a, pool)))
        expander = ExpanderAgent(); hunter = HunterAgent()
        exp_act = jax.jit(jax.vmap(expander.act)); hunter_act = jax.jit(jax.vmap(hunter.act))
        seat = jnp.arange(args.games, dtype=jnp.int32) % 2
        other = 1 - seat
        learner = TeacherFleet(args.games, args.seed + 10000 + off * 1000)
        opponent = TeacherFleet(args.games, args.seed + 20000 + off * 1000)
        obs = get_obs(states)
        finished = np.zeros(args.games, bool); wins = np.zeros(args.games, bool); losses = np.zeros(args.games, bool)
        for _turn in range(1200):
            lob = select_seat(obs, seat); oob = select_seat(obs, other)
            la = np.zeros((args.games, 5), np.int32); lprops = []
            for i in range(args.games):
                h = host_observation(lob, i); pr = learner.agents[i].propose(h); la[i] = pr.action; lprops.append((h, pr))
            key, k = jax.random.split(key)
            oprops = [None] * args.games
            if name == "teacher":
                oa = np.zeros((args.games, 5), np.int32)
                for i in range(args.games):
                    h = host_observation(oob, i); pr = opponent.agents[i].propose(h); oa[i] = pr.action; oprops[i] = (h, pr)
            elif name == "hunter":
                oa = np.asarray(hunter_act(oob, jax.random.split(k, args.games)))
            else:
                oa = np.asarray(exp_act(oob, jax.random.split(k, args.games)))
            actions = np.zeros((args.games, 2, 5), np.int32); rows = np.arange(args.games)
            actions[rows, np.asarray(seat)] = la; actions[rows, np.asarray(other)] = oa
            ts, states = step(states, jnp.asarray(actions)); done = np.asarray(ts.terminated | ts.truncated)
            for i in range(args.games):
                h, pr = lprops[i]; learner.agents[i].commit(h, pr, la[i])
                if oprops[i] is not None:
                    h, pr = oprops[i]; opponent.agents[i].commit(h, pr, oa[i])
                if done[i]: learner.reset(i); opponent.reset(i)
            just = (~finished) & done; winner = np.asarray(ts.info.winner)
            wins |= just & (winner == np.asarray(seat)); losses |= just & (winner == np.asarray(other)); finished |= just
            obs = ts.observation
            if finished.all(): break
        w = int(wins.sum()); l = int(losses.sum()); d = args.games - w - l; score = (w + 0.5 * d) / args.games
        print(f"teacher vs {name}: games={args.games} wins={w} losses={l} draws={d} score={score:.4f}")


if __name__ == "__main__":
    main()
