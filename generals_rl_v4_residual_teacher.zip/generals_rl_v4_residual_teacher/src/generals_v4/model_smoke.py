import jax, jax.numpy as jnp
from .model import ModelConfig, init_params, forward

def main():
    cfg=ModelConfig();p=init_params(jax.random.PRNGKey(0),cfg);b=2;k=cfg.max_candidates
    logits,value=forward(p,jnp.zeros((b,21,21,cfg.board_channels)),jnp.zeros((b,cfg.global_features)),jnp.zeros((b,k,cfg.candidate_features)),jnp.zeros((b,k),jnp.int32),jnp.zeros((b,k),jnp.int32),jnp.ones((b,k),bool))
    assert logits.shape==(b,k) and value.shape==(b,);print('model smoke: OK',logits.shape,value.shape)
if __name__=='__main__':main()
