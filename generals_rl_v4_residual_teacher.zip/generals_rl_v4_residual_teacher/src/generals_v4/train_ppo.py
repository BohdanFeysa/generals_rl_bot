from __future__ import annotations

import argparse
from pathlib import Path
import time
import numpy as np
import jax
import jax.numpy as jnp

from .candidates import generate_candidates
from .teacher import TeacherFleet
from .env_utils import stack_player_observations, select_seat, host_observation, potential
from .model import ModelConfig, init_params, forward, policy_logits
from .optim import init_adam, adam_update
from .checkpoint import load_checkpoint, save_checkpoint


def lerp(a, b, x): return a + (b - a) * min(max(x, 0.0), 1.0)


def main():
    p = argparse.ArgumentParser(description="v4 bounded residual PPO over exact-teacher candidates")
    p.add_argument("--init", help="BC checkpoint for a new run")
    p.add_argument("--resume", help="PPO checkpoint to continue (fresh environment pool)")
    p.add_argument("--checkpoint-dir", default="checkpoints_v4/ppo")
    p.add_argument("--num-envs", type=int, default=64)
    p.add_argument("--pool-size", type=int, default=1024)
    p.add_argument("--rollout-length", type=int, default=128)
    p.add_argument("--updates", type=int, default=1200)
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--minibatch-size", type=int, default=1024)
    p.add_argument("--learning-rate", type=float, default=3e-5)
    p.add_argument("--seed", type=int, default=123)
    p.add_argument("--save-every", type=int, default=20)
    args = p.parse_args()

    from generals import GeneralsEnv
    from generals.agents import ExpanderAgent, HunterAgent

    cfg = ModelConfig(); template = init_params(jax.random.PRNGKey(0), cfg)
    if bool(args.init) == bool(args.resume):
        raise SystemExit("provide exactly one of --init or --resume")
    start_update = 0
    if args.resume:
        params, ema, opt, resume_meta = load_checkpoint(args.resume, template, with_optimizer=True)
        if ema is None:
            ema = params
        if opt is None:
            opt = init_adam(params)
        start_update = int(resume_meta.get("update", 0))
        print(f"resumed {args.resume} at update {start_update}; environment pool starts fresh")
    else:
        params, ema, _, _ = load_checkpoint(args.init, template)
        if ema is not None:
            params = ema
        ema = params
        opt = init_adam(params)
    out = Path(args.checkpoint_dir); out.mkdir(parents=True, exist_ok=True)

    env = GeneralsEnv(mode="competition", pool_size=args.pool_size)
    key = jax.random.PRNGKey(args.seed); key, pool_key = jax.random.split(key)
    pool, _ = env.reset(pool_key)
    idx = jnp.arange(args.num_envs, dtype=jnp.int32) % args.pool_size
    states = jax.tree.map(lambda x: x[idx], pool)._replace(pool_idx=(idx + args.num_envs) % args.pool_size)
    get_obs = jax.jit(jax.vmap(stack_player_observations))
    step_batch = jax.jit(jax.vmap(lambda s, a: env.step(s, a, pool)))
    exp = ExpanderAgent(); hunt = HunterAgent()
    exp_act = jax.jit(jax.vmap(exp.act)); hunt_act = jax.jit(jax.vmap(hunt.act))
    seat = jnp.arange(args.num_envs, dtype=jnp.int32) % 2; other = 1 - seat
    # 50% teacher, 30% hunter, 20% expander.
    types = np.zeros(args.num_envs, np.int32)
    types[int(.5*args.num_envs):int(.8*args.num_envs)] = 1
    types[int(.8*args.num_envs):] = 2
    learner_fleet = TeacherFleet(args.num_envs, args.seed + 10000)
    opp_fleet = TeacherFleet(args.num_envs, args.seed + 20000)
    rngs = [np.random.default_rng(args.seed + 30000 + i) for i in range(args.num_envs)]
    obs = get_obs(states)

    @jax.jit
    def infer(params, board, glob, cand, src, dst, mask, teacher_idx, sample_key, bonus, scale):
        raw, value = forward(params, board, glob, cand, src, dst, mask)
        logits = policy_logits(raw, teacher_idx, mask, bonus, scale)
        action = jax.random.categorical(sample_key, logits, axis=-1).astype(jnp.int32)
        logp = jax.nn.log_softmax(logits, -1)
        chosen = jnp.take_along_axis(logp, action[:, None], -1)[:, 0]
        return action, chosen, value, raw

    def schedule(update):
        x = min(update / 800.0, 1.0)
        return lerp(6.0, 1.5, x), lerp(0.25, 2.0, x), lerp(0.30, 0.03, x)

    @jax.jit
    def ppo_minibatch(params, opt, batch, bonus, scale, bc_coef):
        def loss_fn(p):
            raw, value = forward(p, batch[0], batch[1], batch[2], batch[3], batch[4], batch[5])
            logits = policy_logits(raw, batch[6], batch[5], bonus, scale)
            logp_all = jax.nn.log_softmax(logits, -1)
            logp = jnp.take_along_axis(logp_all, batch[7][:, None], -1)[:, 0]
            ratio = jnp.exp(logp - batch[8])
            clipped = jnp.clip(ratio, 0.85, 1.15)
            policy_loss = -jnp.mean(jnp.minimum(ratio * batch[9], clipped * batch[9]))
            value_loss = 0.5 * jnp.mean(jnp.square(value - batch[10]))
            probs = jnp.exp(logp_all)
            entropy = -jnp.mean(jnp.sum(probs * logp_all, -1))
            teacher_logp = jax.nn.log_softmax(raw, -1)
            bc = -jnp.mean(jnp.take_along_axis(teacher_logp, batch[6][:, None], -1)[:, 0])
            loss = policy_loss + 0.5 * value_loss - 0.01 * entropy + bc_coef * bc
            approx_kl = jnp.mean((ratio - 1.0) - (logp - batch[8]))
            return loss, (policy_loss, value_loss, entropy, bc, approx_kl)
        (loss, aux), grads = jax.value_and_grad(loss_fn, has_aux=True)(params)
        params, opt, norm = adam_update(params, grads, opt, args.learning_rate, weight_decay=1e-6, clip_norm=0.5)
        return params, opt, loss, aux, norm

    total_steps = start_update * args.num_envs * args.rollout_length
    if args.updates <= start_update:
        raise SystemExit(f"--updates must exceed resumed update {start_update}")
    for update in range(start_update + 1, args.updates + 1):
        started = time.time(); bonus, scale, bc_coef = schedule(update)
        store = {k: [] for k in ["board","global","candidate","source","destination","mask","teacher","chosen","logp","value","reward","done"]}
        overrides = 0
        for t in range(args.rollout_length):
            learner_obs_b = select_seat(obs, seat); opp_obs_b = select_seat(obs, other)
            sets = [generate_candidates(host_observation(learner_obs_b, i), learner_fleet.agents[i], rngs[i], shuffle=True) for i in range(args.num_envs)]
            board = np.stack([x.board for x in sets]); glob = np.stack([x.global_features for x in sets]); cand = np.stack([x.candidate_features for x in sets])
            src = np.stack([x.source_indices for x in sets]); dst = np.stack([x.destination_indices for x in sets]); mask = np.stack([x.mask for x in sets]); teacher_idx = np.asarray([x.teacher_index for x in sets], np.int32)
            key, sample_key, k1, k2 = jax.random.split(key, 4)
            chosen, logp, value, _ = infer(params, jnp.asarray(board), jnp.asarray(glob), jnp.asarray(cand), jnp.asarray(src), jnp.asarray(dst), jnp.asarray(mask), jnp.asarray(teacher_idx), sample_key, bonus, scale)
            chosen_np = np.asarray(chosen); learner_actions = np.stack([sets[i].actions[chosen_np[i]] for i in range(args.num_envs)])
            overrides += int(np.sum(chosen_np != teacher_idx))

            exp_actions = np.asarray(exp_act(opp_obs_b, jax.random.split(k1, args.num_envs)))
            hunt_actions = np.asarray(hunt_act(opp_obs_b, jax.random.split(k2, args.num_envs)))
            opponent_actions = np.zeros((args.num_envs,5), np.int32); opp_props = [None]*args.num_envs
            for i in range(args.num_envs):
                if types[i] == 0:
                    oh = host_observation(opp_obs_b, i); op = opp_fleet.agents[i].propose(oh)
                    opponent_actions[i] = op.action; opp_props[i] = (oh, op)
                elif types[i] == 1: opponent_actions[i] = hunt_actions[i]
                else: opponent_actions[i] = exp_actions[i]
            actions = np.zeros((args.num_envs,2,5), np.int32); rows = np.arange(args.num_envs)
            actions[rows, np.asarray(seat)] = learner_actions; actions[rows, np.asarray(other)] = opponent_actions
            phi0 = np.asarray(potential(learner_obs_b))
            timestep, states = step_batch(states, jnp.asarray(actions))
            done = np.asarray(timestep.terminated | timestep.truncated)
            next_learner = select_seat(timestep.observation, seat)
            phi1 = np.asarray(potential(next_learner)); phi1 = np.where(done, 0.0, phi1)
            raw_reward = np.asarray(timestep.reward)[rows, np.asarray(seat)]
            reward = raw_reward + (phi1 - phi0)
            for i in range(args.num_envs):
                hobs = host_observation(learner_obs_b, i)
                learner_fleet.agents[i].commit(hobs, sets[i].proposal, learner_actions[i])
                if opp_props[i] is not None:
                    oh, op = opp_props[i]; opp_fleet.agents[i].commit(oh, op, opponent_actions[i])
                if done[i]: learner_fleet.reset(i); opp_fleet.reset(i)
            for k, v in [("board",board.astype(np.float16)),("global",glob.astype(np.float16)),("candidate",cand.astype(np.float16)),("source",src.astype(np.int16)),("destination",dst.astype(np.int16)),("mask",mask.astype(np.uint8)),("teacher",teacher_idx.astype(np.int16)),("chosen",chosen_np.astype(np.int16)),("logp",np.asarray(logp).astype(np.float32)),("value",np.asarray(value).astype(np.float32)),("reward",reward.astype(np.float32)),("done",done.astype(np.uint8))]: store[k].append(v)
            obs = timestep.observation; total_steps += args.num_envs

        # Bootstrap values from final candidate sets.
        final_obs_b = select_seat(obs, seat)
        final_sets = [generate_candidates(host_observation(final_obs_b, i), learner_fleet.agents[i], rngs[i], shuffle=True) for i in range(args.num_envs)]
        final_raw, bootstrap = forward(params, jnp.asarray(np.stack([x.board for x in final_sets])), jnp.asarray(np.stack([x.global_features for x in final_sets])), jnp.asarray(np.stack([x.candidate_features for x in final_sets])), jnp.asarray(np.stack([x.source_indices for x in final_sets])), jnp.asarray(np.stack([x.destination_indices for x in final_sets])), jnp.asarray(np.stack([x.mask for x in final_sets])))
        rewards = np.stack(store["reward"]); dones = np.stack(store["done"]).astype(bool); values = np.stack(store["value"])
        adv = np.zeros_like(rewards); gae = np.zeros(args.num_envs, np.float32); next_value = np.asarray(bootstrap)
        for t in range(args.rollout_length-1, -1, -1):
            nd = 1.0 - dones[t].astype(np.float32)
            delta = rewards[t] + nd * next_value - values[t]
            gae = delta + 0.98 * nd * gae; adv[t] = gae; next_value = values[t]
        returns = adv + values; adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        flat = {k: np.concatenate(store[k], axis=0) for k in ["board","global","candidate","source","destination","mask","teacher","chosen","logp"]}
        flat["adv"] = adv.reshape(-1); flat["returns"] = returns.reshape(-1)
        n = len(flat["adv"]); order = np.random.default_rng(args.seed + update).permutation(n)
        metrics = []
        for _ in range(args.epochs):
            for start in range(0, n - args.minibatch_size + 1, args.minibatch_size):
                ix = order[start:start+args.minibatch_size]
                batch = tuple(jnp.asarray(flat[k][ix]) for k in ["board","global","candidate","source","destination","mask","teacher","chosen","logp","adv","returns"])
                params, opt, loss, aux, norm = ppo_minibatch(params, opt, batch, bonus, scale, bc_coef); metrics.append((float(loss),)+tuple(map(float,aux)))
        ema = jax.tree.map(lambda e,p: 0.999*e+0.001*p, ema, params)
        elapsed = time.time()-started; m=np.mean(metrics,axis=0)
        print(f"u={update:05d} steps={total_steps:,} fps={args.num_envs*args.rollout_length/elapsed:,.0f} loss={m[0]:.4f} pi={m[1]:.4f} v={m[2]:.4f} ent={m[3]:.3f} bc={m[4]:.3f} kl={m[5]:.5f} override={overrides/(args.num_envs*args.rollout_length):.3f} bonus={bonus:.2f} scale={scale:.2f}")
        if update % args.save_every == 0 or update == args.updates:
            path = out/f"update_{update:07d}.npz"; save_checkpoint(path, params, ema, opt, {"phase":"ppo","update":update,"teacher_bonus":bonus,"residual_scale":scale,"teacher_sha256":"8c3ba3a6ec74f7943478f4c8affa1beda1af3f16229c11e2e06d188e6f60eae8"}); print(f"saved {path}")


if __name__ == "__main__":
    main()
