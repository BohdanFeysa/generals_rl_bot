#!/usr/bin/env python3
from __future__ import annotations

"""Mobilized-castle competition runtime based on the validated v3.4 custom heuristic.

This is a competition-protocol wrapper around the same scoring policy used by
``src/heuristic.py``. Rectangular boards are padded to 21x21 with mountains,
matching the training/evaluation representation.
"""

import os
import sys
from typing import NamedTuple, TextIO
from dataclasses import dataclass

# Force the competition runtime onto CPU and avoid large allocator reservations.
if os.environ.get("GENERALS_V4_TEACHER_CPU_ONLY", "0") == "1":
    os.environ.setdefault("JAX_PLATFORMS", "cpu")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import numpy as np


BOARD = 21
DIR_DR = jnp.asarray([-1, 1, 0, 0], dtype=jnp.int32)
DIR_DC = jnp.asarray([0, 0, -1, 1], dtype=jnp.int32)
ROWS, COLS = jnp.meshgrid(
    jnp.arange(BOARD, dtype=jnp.float32),
    jnp.arange(BOARD, dtype=jnp.float32),
    indexing="ij",
)


class Observation(NamedTuple):
    armies: jnp.ndarray
    generals: jnp.ndarray
    castles: jnp.ndarray
    mountains: jnp.ndarray
    neutral_cells: jnp.ndarray
    owned_cells: jnp.ndarray
    opponent_cells: jnp.ndarray
    fog_cells: jnp.ndarray
    structures_in_fog: jnp.ndarray
    owned_land_count: jnp.ndarray
    owned_army_count: jnp.ndarray
    opponent_land_count: jnp.ndarray
    opponent_army_count: jnp.ndarray
    timestep: jnp.ndarray


class HeuristicWeights(NamedTuple):
    opening_release: float = 11.0
    capture_general: float = 1_000_000.0
    attack_enemy: float = 20_000.0
    explore_fog: float = 620.0
    expand_neutral: float = 440.0
    information: float = 42.0
    gather_progress: float = 230.0
    source_army: float = 2.0
    danger_defense: float = 380.0
    general_move_penalty: float = 900.0
    reverse_direction_bias: float = 8.0
    build_base: float = 360.0


WEIGHTS = HeuristicWeights()


def _shift_to_source(grid: jnp.ndarray) -> jnp.ndarray:
    x = jnp.pad(grid, ((1, 1), (1, 1)))
    up = x[0:BOARD, 1 : BOARD + 1]
    down = x[2 : BOARD + 2, 1 : BOARD + 1]
    left = x[1 : BOARD + 1, 0:BOARD]
    right = x[1 : BOARD + 1, 2 : BOARD + 2]
    return jnp.stack([up, down, left, right], axis=-1)


def _neighbor_sum(mask: jnp.ndarray) -> jnp.ndarray:
    x = jnp.pad(mask.astype(jnp.float32), ((1, 1), (1, 1)))
    total = jnp.zeros((BOARD, BOARD), dtype=jnp.float32)
    for dr in range(3):
        for dc in range(3):
            if dr == 1 and dc == 1:
                continue
            total = total + x[dr : dr + BOARD, dc : dc + BOARD]
    return total


def _action_index_to_env(action_index: jnp.ndarray) -> jnp.ndarray:
    # The heuristic emits only movement indices or pass. Movement layout is
    # (((row * 21 + col) * 4 + direction) * 2 + split).
    move_actions = BOARD * BOARD * 4 * 2
    idx = action_index.astype(jnp.int32)
    is_move = idx < move_actions
    move_q = jnp.minimum(idx, move_actions - 1)
    split = move_q % 2
    move_q //= 2
    direction = move_q % 4
    cell = move_q // 4
    row = cell // BOARD
    col = cell % BOARD
    return jnp.stack(
        [
            jnp.where(is_move, 0, 1),
            jnp.where(is_move, row, 0),
            jnp.where(is_move, col, 0),
            jnp.where(is_move, direction, 0),
            jnp.where(is_move, split, 0),
        ],
        axis=-1,
    ).astype(jnp.int32)


def _heuristic_action_index(obs: Observation, key: jnp.ndarray) -> jnp.ndarray:
    armies = obs.armies.astype(jnp.float32)
    owned = obs.owned_cells.astype(jnp.bool_)
    opponent = obs.opponent_cells.astype(jnp.bool_)
    neutral = obs.neutral_cells.astype(jnp.bool_)
    fog = obs.fog_cells.astype(jnp.bool_)
    generals = obs.generals.astype(jnp.bool_)
    mountains = obs.mountains.astype(jnp.bool_)
    timestep = obs.timestep.astype(jnp.float32)

    dest_army = _shift_to_source(armies)
    dest_owned = _shift_to_source(owned)
    dest_opponent = _shift_to_source(opponent)
    dest_neutral = _shift_to_source(neutral)
    dest_fog = _shift_to_source(fog)
    dest_general = _shift_to_source(generals)
    dest_mountain = _shift_to_source(mountains)
    dest_r_int = jnp.arange(BOARD, dtype=jnp.int32)[:, None, None] + DIR_DR
    dest_c_int = jnp.arange(BOARD, dtype=jnp.int32)[None, :, None] + DIR_DC
    in_bounds = (
        (dest_r_int >= 0)
        & (dest_r_int < BOARD)
        & (dest_c_int >= 0)
        & (dest_c_int < BOARD)
    )
    move_legal = owned[..., None] & (armies[..., None] > 1.0) & in_bounds & ~dest_mountain

    info_grid = _neighbor_sum(fog)
    dest_information = _shift_to_source(info_grid)

    own_general = generals & owned
    has_general = jnp.any(own_general)
    general_flat = jnp.argmax(own_general.reshape(-1)).astype(jnp.int32)
    gr = (general_flat // BOARD).astype(jnp.float32)
    gc = (general_flat % BOARD).astype(jnp.float32)
    general_army = jnp.max(jnp.where(own_general, armies, 0.0))

    phase = (obs.timestep.astype(jnp.int32) // 50) % 4
    dest_r = ROWS[..., None] + DIR_DR.astype(jnp.float32)
    dest_c = COLS[..., None] + DIR_DC.astype(jnp.float32)
    sector_bias = jnp.select(
        [phase == 0, phase == 1, phase == 2],
        [-dest_r, dest_c, dest_r],
        default=-dest_c,
    )
    sector_bias = WEIGHTS.reverse_direction_bias * sector_bias / float(BOARD)

    source_army = armies[..., None]
    movable = jnp.maximum(source_army - 1.0, 0.0)
    full_capture = movable > dest_army
    deathtouch = timestep >= 800.0
    enemy_general = dest_general & dest_opponent
    can_take_general = enemy_general & (full_capture | deathtouch)

    dist_to_general = jnp.abs(ROWS - gr) + jnp.abs(COLS - gc)
    threat_grid = jnp.where(opponent, armies - 2.0 * dist_to_general, -1.0e6)
    threat_flat = jnp.argmax(threat_grid.reshape(-1)).astype(jnp.int32)
    tr = (threat_flat // BOARD).astype(jnp.float32)
    tc = (threat_flat % BOARD).astype(jnp.float32)
    threat_strength = jnp.max(threat_grid)
    threat_distance = jnp.abs(tr - gr) + jnp.abs(tc - gc)
    danger = has_general & jnp.any(opponent) & (
        (threat_distance <= 5.0) | (threat_strength >= 0.6 * general_army)
    )

    adjacent_owned = _neighbor_sum(owned) > 0.0
    possible_enemy_spawn = fog & has_general & (dist_to_general >= 17.0)
    cell_sector = jnp.select(
        [phase == 0, phase == 1, phase == 2],
        [-ROWS, COLS, ROWS],
        default=-COLS,
    )
    objective_score = (
        jnp.where(generals & opponent, 1.0e7, 0.0)
        + jnp.where(opponent, 1.0e6 + armies * 50.0, 0.0)
        + jnp.where(fog & adjacent_owned, 20_000.0 + info_grid * 500.0, 0.0)
        + jnp.where(neutral & adjacent_owned, 10_000.0 + info_grid * 250.0, 0.0)
        + jnp.where(possible_enemy_spawn, 750.0, 0.0)
        + 10.0 * cell_sector
        - jnp.where(mountains, 1.0e9, 0.0)
    )
    objective_flat = jnp.argmax(objective_score.reshape(-1)).astype(jnp.int32)
    goal_r = (objective_flat // BOARD).astype(jnp.float32)
    goal_c = (objective_flat % BOARD).astype(jnp.float32)
    dist_source_goal = jnp.abs(ROWS - goal_r) + jnp.abs(COLS - goal_c)
    dist_dest_goal = jnp.abs(dest_r - goal_r) + jnp.abs(dest_c - goal_c)
    gather_progress = dist_source_goal[..., None] - dist_dest_goal

    score = jnp.zeros((BOARD, BOARD, 4), dtype=jnp.float32)
    score = score + WEIGHTS.source_army * jnp.log1p(source_army)
    score = score + sector_bias
    score = score + jnp.where(
        dest_fog,
        WEIGHTS.explore_fog + WEIGHTS.information * dest_information,
        0.0,
    )
    score = score + jnp.where(
        dest_neutral,
        WEIGHTS.expand_neutral + 0.5 * WEIGHTS.information * dest_information,
        0.0,
    )
    score = score + jnp.where(
        dest_opponent,
        WEIGHTS.attack_enemy + 30.0 * (movable - dest_army),
        0.0,
    )
    score = score + jnp.where(
        dest_owned & (gather_progress > 0.0),
        WEIGHTS.gather_progress * gather_progress + 3.0 * source_army,
        -120.0 * dest_owned,
    )

    dist_source_threat = jnp.abs(ROWS - tr) + jnp.abs(COLS - tc)
    dist_dest_threat = jnp.abs(dest_r - tr) + jnp.abs(dest_c - tc)
    defense_progress = dist_source_threat[..., None] - dist_dest_threat
    score = score + jnp.where(
        danger & (defense_progress > 0.0),
        WEIGHTS.danger_defense * defense_progress + 2.0 * source_army,
        0.0,
    )

    opening = obs.owned_land_count.astype(jnp.int32) <= 2
    opening_not_ready = opening & (general_army < WEIGHTS.opening_release)
    source_is_general = own_general[..., None]
    score = score - jnp.where(source_is_general & opening_not_ready, 1.0e8, 0.0)

    late_general_penalty = source_is_general & (timestep >= 80.0) & ~can_take_general
    score = score - jnp.where(
        late_general_penalty, WEIGHTS.general_move_penalty, 0.0
    )

    score = score + jnp.where(can_take_general, WEIGHTS.capture_general, 0.0)
    score = jnp.where(move_legal, score, -1.0e30)
    score = score + jax.random.uniform(key, score.shape, minval=0.0, maxval=1.0e-3)

    best_move_flat = jnp.argmax(score.reshape(-1)).astype(jnp.int32)
    best_move_score = jnp.max(score)
    move_cell = best_move_flat // 4
    move_dir = best_move_flat % 4
    move_row = move_cell // BOARD
    move_col = move_cell % BOARD

    selected_source_army = armies[move_row, move_col]
    selected_source_general = own_general[move_row, move_col]
    selected_dest_fog = dest_fog[move_row, move_col, move_dir]
    selected_dest_neutral = dest_neutral[move_row, move_col, move_dir]
    selected_dest_opponent = dest_opponent[move_row, move_col, move_dir]
    selected_enemy_general = enemy_general[move_row, move_col, move_dir]
    frontier_degree = jnp.sum(
        (dest_fog | dest_neutral)[move_row, move_col].astype(jnp.int32)
    )
    use_split = (
        (selected_source_general & (timestep >= 50.0))
        | (
            (selected_source_army >= 18.0)
            & (frontier_degree >= 2)
            & (selected_dest_fog | selected_dest_neutral)
        )
    ) & ~selected_dest_opponent & ~selected_enemy_general
    move_index = (
        ((move_row * BOARD + move_col) * 4 + move_dir) * 2
        + use_split.astype(jnp.int32)
    )

    pass_index = BOARD * BOARD * 4 * 2 + BOARD * BOARD
    pass_score = jnp.where(opening_not_ready, 0.0, -500.0)
    return jnp.where(pass_score >= best_move_score, pass_index, move_index).astype(
        jnp.int32
    )


@jax.jit
def choose_action(obs: Observation, key: jnp.ndarray) -> jnp.ndarray:
    return _action_index_to_env(_heuristic_action_index(obs, key))


def _read_grid(stream: TextIO, height: int, width: int) -> np.ndarray:
    rows: list[list[int]] = []
    for _ in range(height):
        line = stream.readline()
        if not line:
            raise EOFError
        row = [int(x) for x in line.split()]
        if len(row) != width:
            raise ValueError(f"expected {width} entries, got {len(row)}")
        rows.append(row)
    return np.asarray(rows, dtype=np.int32)


def _read_observation(
    stream: TextIO,
    height: int,
    width: int,
    scalar_line: str,
) -> Observation:
    values = [int(x) for x in scalar_line.split()]
    if len(values) != 5:
        raise ValueError(f"expected 5 scalar values, got {len(values)}")
    turn, my_land, my_army, opp_land, opp_army = values
    cell_type = _read_grid(stream, height, width)
    owner = _read_grid(stream, height, width)
    army = _read_grid(stream, height, width)

    # Exact training convention: rectangles occupy the top-left and all outside
    # cells are padded as mountains.
    types = np.full((BOARD, BOARD), 2, dtype=np.int32)
    owners = np.zeros((BOARD, BOARD), dtype=np.int32)
    armies = np.zeros((BOARD, BOARD), dtype=np.int32)
    types[:height, :width] = cell_type
    owners[:height, :width] = owner
    armies[:height, :width] = army

    inside = np.zeros((BOARD, BOARD), dtype=bool)
    inside[:height, :width] = True
    return Observation(
        armies=jnp.asarray(armies, dtype=jnp.int32),
        generals=jnp.asarray(inside & (types == 4)),
        castles=jnp.asarray(inside & (types == 3)),
        mountains=jnp.asarray((~inside) | (types == 2)),
        neutral_cells=jnp.asarray(inside & (owners == 0) & (types == 1)),
        owned_cells=jnp.asarray(inside & (owners == 1)),
        opponent_cells=jnp.asarray(inside & (owners == 2)),
        fog_cells=jnp.asarray(inside & (types == 0)),
        structures_in_fog=jnp.asarray(inside & (types == 5)),
        owned_land_count=jnp.asarray(my_land, dtype=jnp.int32),
        owned_army_count=jnp.asarray(my_army, dtype=jnp.int32),
        opponent_land_count=jnp.asarray(opp_land, dtype=jnp.int32),
        opponent_army_count=jnp.asarray(opp_army, dtype=jnp.int32),
        timestep=jnp.asarray(turn, dtype=jnp.int32),
    )



def _cardinal_neighbor_count(mask: np.ndarray) -> np.ndarray:
    """Number of true up/down/left/right neighbours for every board cell."""
    padded = np.pad(mask.astype(np.int32), 1)
    return (
        padded[0:BOARD, 1 : BOARD + 1]
        + padded[2 : BOARD + 2, 1 : BOARD + 1]
        + padded[1 : BOARD + 1, 0:BOARD]
        + padded[1 : BOARD + 1, 2 : BOARD + 2]
    )


def _castle_cost_grid_np(structures: np.ndarray) -> np.ndarray:
    """Exact competition castle cost from visible own structures."""
    rows, cols = np.indices((BOARD, BOARD))
    cost = np.full((BOARD, BOARD), 35, dtype=np.int32)
    for sr, sc in np.argwhere(structures):
        distance = np.abs(rows - int(sr)) + np.abs(cols - int(sc))
        cost += np.maximum(0, 14 - 2 * distance)
    return cost


def _planned_move_destination(action: np.ndarray) -> tuple[int, int] | None:
    if int(action[0]) != 0:
        return None
    r, c, direction = map(int, action[1:4])
    nr = r + int(np.asarray(DIR_DR)[direction])
    nc = c + int(np.asarray(DIR_DC)[direction])
    if not (0 <= nr < BOARD and 0 <= nc < BOARD):
        return None
    return nr, nc



def _visible_emergency_np(obs: Observation) -> bool:
    armies = np.asarray(obs.armies, dtype=np.int32)
    owned = np.asarray(obs.owned_cells, dtype=bool)
    opponent = np.asarray(obs.opponent_cells, dtype=bool)
    generals = np.asarray(obs.generals, dtype=bool)
    own_general = generals & owned
    if not own_general.any() or not opponent.any():
        return False
    gr, gc = map(int, np.argwhere(own_general)[0])
    general_army = int(armies[gr, gc])
    for er, ec in np.argwhere(opponent):
        d = abs(int(er) - gr) + abs(int(ec) - gc)
        a = int(armies[er, ec])
        # A distant huge stack is a strategic target, not an immediate
        # emergency. Suppressing all mobilisation because a 600-stack is
        # visible twenty tiles away caused the replayed late-game paralysis.
        if d <= 3 or (d <= 6 and a - 2 * d >= max(8, int(0.55 * general_army))):
            return True
    return False


@dataclass
class EconomyState:
    # Exact cell where the persistent assault stack is expected this turn.
    main_stack: tuple[int, int] | None = None
    # Last visible enemy centroid gives fog-frontier routing a direction.
    enemy_memory: tuple[float, float] | None = None
    # Number of consecutive turns for which the stack could not be followed.
    lost_turns: int = 0


def _objective_cell_np(
    obs: Observation,
    source: tuple[int, int],
    state: EconomyState,
) -> tuple[int, int] | None:
    """Choose a useful *front-line* destination for the persistent stack.

    Priority is intentionally simple and robust:
      1. visible enemy general;
      2. nearest capturable visible enemy border cell (weak cells first);
      3. frontier closest to the last-seen enemy region;
      4. nearest information-rich frontier.

    The old version targeted the strongest enemy cell. That often sent the army
    toward a remote fortress and, after one move, abandoned it. Here distance
    and immediate penetrability dominate.
    """
    armies = np.asarray(obs.armies, dtype=np.int32)
    owned = np.asarray(obs.owned_cells, dtype=bool)
    opponent = np.asarray(obs.opponent_cells, dtype=bool)
    neutral = np.asarray(obs.neutral_cells, dtype=bool)
    fog = np.asarray(obs.fog_cells, dtype=bool)
    generals = np.asarray(obs.generals, dtype=bool)
    mountains = np.asarray(obs.mountains, dtype=bool)
    sr, sc = source
    rr, cc = np.indices((BOARD, BOARD))
    distance = np.abs(rr - sr) + np.abs(cc - sc)
    source_army = int(armies[sr, sc])

    visible_enemy = np.argwhere(opponent)
    if len(visible_enemy):
        state.enemy_memory = (
            float(np.mean(visible_enemy[:, 0])),
            float(np.mean(visible_enemy[:, 1])),
        )

    enemy_general = generals & opponent
    if enemy_general.any():
        candidates = np.argwhere(enemy_general)
        return tuple(
            map(
                int,
                min(
                    candidates,
                    key=lambda x: abs(int(x[0]) - sr) + abs(int(x[1]) - sc),
                ),
            )
        )

    if opponent.any():
        # Prefer a nearby weak entry point into enemy territory. A huge stack
        # should penetrate the border, not chase the opponent's largest pile.
        capturable = opponent & (armies < max(2, source_army - 1))
        candidate_mask = capturable if capturable.any() else opponent
        border_degree = _cardinal_neighbor_count(owned)
        score = (
            -10.0 * distance
            - 1.5 * armies
            + 45.0 * border_degree
            + np.where(capturable, 500.0, 0.0)
        )
        score = np.where(candidate_mask, score, -1.0e30)
        r, c = np.unravel_index(int(np.argmax(score)), score.shape)
        return int(r), int(c)

    adjacent_owned = _cardinal_neighbor_count(owned) > 0
    frontier = (fog | neutral) & adjacent_owned & ~mountains
    if frontier.any():
        information = _cardinal_neighbor_count(fog)
        if state.enemy_memory is not None:
            er, ec = state.enemy_memory
            enemy_distance = np.abs(rr - er) + np.abs(cc - ec)
            score = 12.0 * information - 3.0 * distance - 8.0 * enemy_distance
        else:
            score = 15.0 * information - 5.0 * distance
        score = np.where(frontier, score, -1.0e30)
        r, c = np.unravel_index(int(np.argmax(score)), score.shape)
        return int(r), int(c)
    return None

def _first_step_toward_np(
    source: tuple[int, int],
    target: tuple[int, int],
    mountains: np.ndarray,
) -> int | None:
    """BFS first direction on the static passable board."""
    from collections import deque

    sr, sc = source
    tr, tc = target
    if source == target:
        return None
    seen = np.zeros((BOARD, BOARD), dtype=bool)
    seen[sr, sc] = True
    q = deque()
    for direction, (dr, dc) in enumerate(zip(np.asarray(DIR_DR), np.asarray(DIR_DC))):
        nr, nc = sr + int(dr), sc + int(dc)
        if 0 <= nr < BOARD and 0 <= nc < BOARD and not mountains[nr, nc]:
            seen[nr, nc] = True
            q.append((nr, nc, direction))
    while q:
        r, c, first_direction = q.popleft()
        if (r, c) == (tr, tc):
            return int(first_direction)
        for dr, dc in zip(np.asarray(DIR_DR), np.asarray(DIR_DC)):
            nr, nc = r + int(dr), c + int(dc)
            if (
                0 <= nr < BOARD
                and 0 <= nc < BOARD
                and not seen[nr, nc]
                and not mountains[nr, nc]
            ):
                seen[nr, nc] = True
                q.append((nr, nc, first_direction))
    return None


def _valid_owned_stack(
    state: EconomyState,
    owned: np.ndarray,
    armies: np.ndarray,
    own_general: np.ndarray,
) -> tuple[int, int] | None:
    """Recover the persistent stack, tolerating one-cell merge ambiguity."""
    if state.main_stack is None:
        return None
    r, c = state.main_stack
    if 0 <= r < BOARD and 0 <= c < BOARD and owned[r, c] and not own_general[r, c] and armies[r, c] > 1:
        state.lost_turns = 0
        return r, c

    # A capture/merge can make the expected tile temporarily unsuitable.
    # Recover the largest owned stack within radius two before abandoning it.
    candidates: list[tuple[int, int]] = []
    for rr in range(max(0, r - 2), min(BOARD, r + 3)):
        for cc in range(max(0, c - 2), min(BOARD, c + 3)):
            if abs(rr - r) + abs(cc - c) <= 2 and owned[rr, cc] and not own_general[rr, cc] and armies[rr, cc] > 1:
                candidates.append((rr, cc))
    if candidates:
        best = max(candidates, key=lambda x: int(armies[x]))
        state.main_stack = best
        state.lost_turns = 0
        return best

    state.lost_turns += 1
    if state.lost_turns >= 2:
        state.main_stack = None
    return None


def choose_mobilized_economy(
    obs: Observation,
    planned_action: np.ndarray,
    state: EconomyState,
) -> np.ndarray | None:
    """Castle economy with a persistent front-line assault stack.

    The previous implementation re-selected a stack every turn and required it
    to hold 28% of the *entire* army. Castle income made that threshold grow,
    so 500--1600 troop stacks were moved once and forgotten. This version
    remembers the stack cell after each move and keeps advancing it until it is
    destroyed or truly lost.
    """
    if os.environ.get("ENABLE_CASTLES", "1") == "0":
        return None

    armies = np.asarray(obs.armies, dtype=np.int32)
    owned = np.asarray(obs.owned_cells, dtype=bool)
    opponent = np.asarray(obs.opponent_cells, dtype=bool)
    generals = np.asarray(obs.generals, dtype=bool)
    castles = np.asarray(obs.castles, dtype=bool)
    mountains = np.asarray(obs.mountains, dtype=bool)
    own_general = generals & owned
    own_castles = castles & owned
    turn = int(np.asarray(obs.timestep))
    my_land = int(np.asarray(obs.owned_land_count))
    my_army = int(np.asarray(obs.owned_army_count))
    opp_army = int(np.asarray(obs.opponent_army_count))

    # Update enemy memory every turn even when no assault action is emitted.
    visible_enemy = np.argwhere(opponent)
    if len(visible_enemy):
        state.enemy_memory = (
            float(np.mean(visible_enemy[:, 0])),
            float(np.mean(visible_enemy[:, 1])),
        )

    destination = _planned_move_destination(planned_action)
    if destination is not None:
        nr, nc = destination
        if generals[nr, nc] and opponent[nr, nc]:
            return None
    if _visible_emergency_np(obs):
        return None

    # 1) Continue the exact stack we moved last turn.
    mobilize_source = _valid_owned_stack(state, owned, armies, own_general)

    # 2) Start a new campaign from a productive castle or the largest field
    # stack. Threshold is absolute plus a modest 6% share, never 28%.
    if mobilize_source is None:
        candidates: list[tuple[int, int]] = []
        for r, c in np.argwhere(own_castles & (armies >= 35)):
            candidates.append((int(r), int(c)))
        movable_owned = owned & ~own_general & (armies > 1)
        if movable_owned.any():
            r, c = np.unravel_index(
                int(np.argmax(np.where(movable_owned, armies, -1))), armies.shape
            )
            largest = int(armies[r, c])
            # Castle economies can make total army enormous; cap the share-
            # based threshold so a 300--600 field stack is never ignored.
            start_threshold = max(45, min(180, int(0.04 * max(my_army, 1))))
            if largest >= start_threshold:
                candidates.append((int(r), int(c)))
        if candidates:
            mobilize_source = max(candidates, key=lambda x: int(armies[x]))
            state.main_stack = mobilize_source
            state.lost_turns = 0

    if mobilize_source is not None:
        sr, sc = mobilize_source

        # Immediate adjacent penetration beats long-range routing.
        adjacent_attacks: list[tuple[float, int]] = []
        for direction, (dr, dc) in enumerate(zip(np.asarray(DIR_DR), np.asarray(DIR_DC))):
            nr, nc = sr + int(dr), sc + int(dc)
            if not (0 <= nr < BOARD and 0 <= nc < BOARD) or mountains[nr, nc]:
                continue
            if opponent[nr, nc]:
                is_general = bool(generals[nr, nc])
                capturable = armies[sr, sc] - 1 > armies[nr, nc]
                if is_general and (capturable or turn >= 800):
                    adjacent_attacks.append((1.0e9, direction))
                elif capturable:
                    adjacent_attacks.append((1.0e6 - float(armies[nr, nc]), direction))
        if adjacent_attacks:
            _, direction = max(adjacent_attacks)
            nr = sr + int(np.asarray(DIR_DR)[direction])
            nc = sc + int(np.asarray(DIR_DC)[direction])
            state.main_stack = (nr, nc)
            return np.asarray([0, sr, sc, direction, 0], dtype=np.int32)

        target = _objective_cell_np(obs, mobilize_source, state)
        if target is not None:
            direction = _first_step_toward_np(mobilize_source, target, mountains)
            if direction is not None:
                nr = sr + int(np.asarray(DIR_DR)[direction])
                nc = sc + int(np.asarray(DIR_DC)[direction])
                if not (
                    opponent[nr, nc]
                    and turn < 800
                    and armies[sr, sc] - 1 <= armies[nr, nc]
                ):
                    state.main_stack = (nr, nc)
                    return np.asarray([0, sr, sc, direction, 0], dtype=np.int32)

    # Build only while no active campaign exists. Once a stack has been
    # launched, combat has priority over adding another economic node.
    if state.main_stack is not None:
        return None
    if len(np.argwhere(own_castles)) and int(armies[own_castles].max(initial=0)) >= 35:
        return None
    if turn < 70 or turn > 520 or my_land < 10:
        return None

    castle_count = int(own_castles.sum())
    desired = min(5, 1 + my_land // 24 + (1 if turn >= 300 else 0))
    if castle_count >= desired:
        return None
    if my_army < max(95, opp_army + 25 + 18 * castle_count):
        return None

    structures = own_general | own_castles
    cost = _castle_cost_grid_np(structures)
    owned_neighbours = _cardinal_neighbor_count(owned)
    exposed = _cardinal_neighbor_count(opponent | np.asarray(obs.fog_cells, dtype=bool))
    reserve = 7
    candidates = (
        owned
        & ~generals
        & ~castles
        & ~mountains
        & (armies >= cost + reserve)
        & (owned_neighbours >= 2)
        & (exposed <= 1)
    )
    if not candidates.any():
        return None

    largest_army = int(armies[owned].max(initial=0))
    candidates &= armies < largest_army
    if not candidates.any():
        return None
    score = (
        8.0 * (armies - cost)
        - 12.0 * cost
        + 60.0 * owned_neighbours
        - 100.0 * exposed
    )
    score = np.where(candidates, score, -1.0e30)
    r, c = np.unravel_index(int(np.argmax(score)), score.shape)
    if score[r, c] <= -1.0e20:
        return None
    return np.asarray([2, int(r), int(c), 0, 0], dtype=np.int32)

def main() -> None:
    first = sys.stdin.readline()
    if not first:
        return
    _player_id, height, width = map(int, first.split())
    if not (1 <= height <= BOARD and 1 <= width <= BOARD):
        raise ValueError(f"unsupported board size {height}x{width}")

    key = jax.random.PRNGKey(0xF3A5A)
    economy_state = EconomyState()
    while True:
        scalar_line = sys.stdin.readline()
        if not scalar_line:
            break
        try:
            obs = _read_observation(sys.stdin, height, width, scalar_line)
        except EOFError:
            break
        key, action_key = jax.random.split(key)
        action = np.asarray(choose_action(obs, action_key), dtype=np.int32)
        economy_action = choose_mobilized_economy(obs, action, economy_state)
        if economy_action is not None:
            action = economy_action
        sys.stdout.write("%d %d %d %d %d\n" % tuple(map(int, action)))
        sys.stdout.flush()


if __name__ == "__main__":
    main()
