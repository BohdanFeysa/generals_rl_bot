import jax
from generals_v4.model import ModelConfig, init_params
from generals_v4.checkpoint import save_checkpoint, load_checkpoint
from generals_v4.optim import init_adam

def test_checkpoint_roundtrip(tmp_path):
    p=init_params(jax.random.PRNGKey(7),ModelConfig());o=init_adam(p);f=tmp_path/'x.npz';save_checkpoint(f,p,p,o,{'x':1});q,e,oo,m=load_checkpoint(f,p,with_optimizer=True);assert m['x']==1;assert e is not None and oo is not None
