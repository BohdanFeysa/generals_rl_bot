import jax, jax.numpy as jnp
from generals_v4.model import ModelConfig, init_params, forward, policy_logits

def test_model_shapes_and_teacher_anchor():
    c=ModelConfig();p=init_params(jax.random.PRNGKey(0),c);b=3;k=c.max_candidates
    mask=jnp.ones((b,k),bool);raw,val=forward(p,jnp.zeros((b,21,21,c.board_channels)),jnp.zeros((b,c.global_features)),jnp.zeros((b,k,c.candidate_features)),jnp.zeros((b,k),jnp.int32),jnp.zeros((b,k),jnp.int32),mask)
    assert raw.shape==(b,k) and val.shape==(b,)
    teacher=jnp.asarray([2,4,6]);logits=policy_logits(raw,teacher,mask,6.0,.25)
    assert (jnp.argmax(logits,-1)==teacher).all()
