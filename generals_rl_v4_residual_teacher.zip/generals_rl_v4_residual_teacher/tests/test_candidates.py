from types import SimpleNamespace
import numpy as np
from generals_v4.teacher import ExactTeacher
from generals_v4.candidates import generate_candidates, MAX_CANDIDATES
from generals_v4.action_codec import action_key

def synthetic_obs():
    z=np.zeros((21,21),np.int32); owned=np.zeros((21,21),bool);owned[10,10]=True;owned[10,11]=True;arm=z.copy();arm[10,10]=50;arm[10,11]=5;gen=np.zeros_like(owned);gen[10,10]=True;neutral=np.ones_like(owned);neutral[owned]=False;mount=np.zeros_like(owned);fog=np.zeros_like(owned)
    return SimpleNamespace(armies=arm,generals=gen,castles=np.zeros_like(owned),mountains=mount,neutral_cells=neutral,owned_cells=owned,opponent_cells=np.zeros_like(owned),fog_cells=fog,structures_in_fog=np.zeros_like(owned),owned_land_count=np.asarray(2),owned_army_count=np.asarray(55),opponent_land_count=np.asarray(1),opponent_army_count=np.asarray(1),timestep=np.asarray(100))

def test_teacher_is_always_present():
    t=ExactTeacher(1);cs=generate_candidates(synthetic_obs(),t,np.random.default_rng(1),shuffle=True)
    assert cs.actions.shape==(MAX_CANDIDATES,5);assert cs.mask[cs.teacher_index];assert action_key(cs.actions[cs.teacher_index])==action_key(cs.proposal.action)
