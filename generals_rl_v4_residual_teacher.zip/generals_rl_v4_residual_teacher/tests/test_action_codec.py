import numpy as np
from generals_v4.action_codec import move_destination, action_source_destination

def test_action_codec():
    a=np.asarray([0,5,6,3,0]); assert move_destination(a)==(5,7); assert action_source_destination(a)==(111,112)
    assert action_source_destination(np.asarray([2,3,4,0,0]))==(67,67)
