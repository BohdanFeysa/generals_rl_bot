from pathlib import Path
import hashlib

def test_teacher_artifact_hash():
    p=Path('teacher_artifact/generals_custom_heuristic_frontline_persistent.zip')
    assert hashlib.sha256(p.read_bytes()).hexdigest() == '8c3ba3a6ec74f7943478f4c8affa1beda1af3f16229c11e2e06d188e6f60eae8'
