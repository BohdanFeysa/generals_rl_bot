# Generals RL v4 — exact-teacher residual PPO

This repository is intentionally separate from v3. It uses the submitted and server-tested **persistent-frontline castle bot** as an immutable teacher, candidate generator anchor, deployment fallback, and principal opponent.

Teacher artifact SHA-256:

```text
8c3ba3a6ec74f7943478f4c8affa1beda1af3f16229c11e2e06d188e6f60eae8
```

## Why v4 is different

The earlier agents learned over roughly four thousand raw actions and had to rediscover castle economy, castle harvesting, persistent stack control, frontier routing, defence, and Deathtouch. v4 does not do that.

At every turn the exact teacher proposes its action. The candidate generator adds only 31 meaningful alternatives. A compact CNN ranks those candidates. Policy logits are:

```text
bounded neural residual + explicit teacher bonus
```

An untrained model therefore executes the teacher exactly. The teacher action is always present, candidate order is shuffled during imitation, and deployment falls back to the teacher on errors or low confidence.

## Repository layout

- `teacher_artifact/`: exact winning ZIP and checksum.
- `src/generals_v4/teacher_exact.py`: policy logic extracted from that ZIP; only import-time CPU forcing was made conditional.
- `collect_teacher.py`: generates shuffled-candidate imitation data.
- `train_bc.py`: behavior cloning.
- `train_ppo.py`: bounded residual PPO against 50% teacher, 30% Hunter, 20% Expander.
- `evaluate.py`: exact competition evaluation with both seats.
- `export_submission.py`: creates a root-level `run.sh` submission ZIP with exact-teacher fallback.

## Setup on GX10

```bash
unzip generals_rl_v4_residual_teacher.zip
cd generals_rl_v4_residual_teacher
bash scripts/setup_gx10.sh
bash scripts/smoke_test.sh
```

The setup creates `.venv` with `--system-site-packages`, preserving the JAX/CUDA build already working on the GX10. Set `GENERALS_REPO=/path/to/generals-bots` when the official repository is not at `../generals-bots`.

## Verify the teacher before training

Run the exact baseline through the current official competition environment:

```bash
bash scripts/evaluate_teacher.sh --opponent all --games 128 --seed 123
```

This establishes the local teacher score that every learned checkpoint must preserve or improve.

## Phase 1: collect teacher data

Start with 100k samples:

```bash
bash scripts/collect_teacher.sh   --samples 100000   --num-envs 32   --out datasets/teacher_v4
```

The collector uses exact competition rules and mixes teacher mirror, Hunter, and Expander. Candidate order is randomized so behavior cloning cannot learn “always pick slot zero.”

## Phase 2: behavior cloning

```bash
bash scripts/train_bc.sh   --data datasets/teacher_v4   --epochs 8   --out checkpoints_v4/bc_final.npz
```

Do not begin PPO until `teacher_acc` is at least about 0.90; 0.95+ is preferable.

## Phase 3: residual PPO

```bash
bash scripts/train_ppo.sh   --init checkpoints_v4/bc_final.npz   --checkpoint-dir checkpoints_v4/ppo   --num-envs 64   --rollout-length 128   --updates 1200
```

The default schedule starts with a teacher bonus of 6.0 and residual scale 0.25, then gradually permits larger overrides. The teacher imitation term remains active throughout training.

Because exact stateful candidate generation runs on CPU, v4 will have lower raw FPS than v3. That is deliberate: each action is strategically constrained instead of selected from thousands of arbitrary actions.

## Continue a PPO run

Checkpoints include parameters, EMA parameters, and Adam state. Continuation starts a fresh environment pool but preserves optimizer progress:

```bash
bash scripts/train_ppo.sh \
  --resume checkpoints_v4/ppo/update_0000100.npz \
  --checkpoint-dir checkpoints_v4/ppo \
  --updates 200
```

`--updates` is the final absolute update number, not an additional count.

## Evaluate

Stop training before evaluation on the unified-memory GX10.

```bash
bash scripts/evaluate.sh checkpoints_v4/ppo/update_0000200.npz   --opponent all --games 128 --seed 123
```

A checkpoint is not an improvement merely because it beats Hunter or Expander. It must also hold at least 50% score against the exact teacher. Promote only checkpoints that:

1. score at least 50% against the teacher over 256+ games;
2. preserve strong Expander performance;
3. improve or preserve Hunter performance;
4. keep zero faults in subprocess testing;
5. do not exhibit excessive override rate or idle-stack regressions.

## Export

```bash
bash scripts/export_submission.sh   checkpoints_v4/ppo/update_0000200.npz   --out submission_build/v4_u200
```

Output:

```text
submission_build/v4_u200.zip
```

The exported runtime uses EMA weights, exact teacher candidates, a confidence gate, and exception fallback. With zero/invalid weights it behaves as the teacher.

## One-command first experiment

```bash
SAMPLES=100000 BC_EPOCHS=8 UPDATES=100 bash scripts/first_experiment.sh
```

## Safe starting experiment

Do not immediately run 1200 updates. First:

```text
100k teacher samples
8 BC epochs
100 PPO updates
128-game evaluation versus teacher/Hunter/Expander
```

Inspect override rate. Early checkpoints should override the teacher rarely. A high override rate before direct teacher strength improves means the safety schedule is too weak.

## Known limitations

- No snapshot self-play league is included in v4.0; the exact teacher is a much stronger and safer anchor for the first residual experiment.
- Candidate generation is Python/NumPy and intentionally prioritizes correctness over maximum throughput.
- The exact server qualifier is a tiny sample. Use large local tournaments and preserve the original teacher ZIP as the immutable fallback.
