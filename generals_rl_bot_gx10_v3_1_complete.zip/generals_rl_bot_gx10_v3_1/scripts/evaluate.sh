#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
CHECKPOINT="${1:-checkpoints_v3}"
GAMES="${GAMES:-512}"
python -m src.evaluate "$CHECKPOINT" --opponent both --games "$GAMES"
