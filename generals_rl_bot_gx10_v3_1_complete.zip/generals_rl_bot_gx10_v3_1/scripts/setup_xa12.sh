#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
echo "Note: this machine is GX10; forwarding to scripts/setup_gx10.sh" >&2
exec "$ROOT/scripts/setup_gx10.sh" "$@"
