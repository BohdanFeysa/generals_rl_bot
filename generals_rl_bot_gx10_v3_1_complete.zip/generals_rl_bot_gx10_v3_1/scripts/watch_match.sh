#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
submission/build.sh
OPPONENT="${OPPONENT:-third_party/generals-bots/competition/agents/expander_cpp/run.sh}"
SEED="${SEED:-7}"
FPS="${FPS:-8}"
python third_party/generals-bots/competition/matchup.py \
  submission/run.sh "$OPPONENT" \
  --mode competition --seed "$SEED" --gui --fps "$FPS"
