# GX10 deployment and training guide

This package is self-contained except for the official `strakam/generals-bots`
repository, which `scripts/setup_gx10.sh` clones into
`third_party/generals-bots` and installs into the local virtual environment.

## 0. System prerequisites

On an Ubuntu/DGX-OS-style GX10 installation, make sure these commands exist:

```bash
nvidia-smi
git --version
python3 --version
g++ --version
zip -v | head -n 1
```

If standard build tools are missing:

```bash
sudo apt update
sudo apt install -y git python3-venv python3-dev build-essential zip unzip
```

The NVIDIA driver/CUDA runtime must already be provided by the GX10 system.
Do not replace the machine's NVIDIA stack merely to run this project.

## 1. Copy and extract the archive

```bash
unzip generals_rl_bot_gx10_v3_1.zip
cd generals_rl_bot_gx10_v3_1
```

## 2. Install the Python stack and official environment

```bash
bash scripts/setup_gx10.sh
source .venv/bin/activate
```

The setup script:

1. creates `.venv`;
2. installs CUDA-enabled JAX, Flax, Optax, and NumPy;
3. clones the official repository to `third_party/generals-bots`;
4. installs the official environment in editable mode;
5. verifies that JAX sees a GPU.

Successful setup must print at least one JAX device whose platform is `gpu`.

## 3. Run the end-to-end smoke test

```bash
bash scripts/smoke_test.sh
```

This performs one tiny PPO update, writes a checkpoint, exports weights, builds
the C++ bot, and checks numerical parity between JAX and C++ inference.
Do not begin a long run until this succeeds.

## 4. Start a fresh v3 training run

Do not resume the failed v2 checkpoint because the optimizer schedule,
trajectory layout, curriculum, EMA state, and checkpoint schema changed.

```bash
CHECKPOINT_DIR=checkpoints_v3 \
UPDATES=3000 \
bash scripts/train_gx10.sh
```

Default configuration:

```text
512 parallel environments
4096 starting-board pool
512-step rollouts
32-step recurrent BPTT chunks
128 recurrent sequences per minibatch
1 PPO epoch
25% top-advantage filtering
EMA decay 0.999
3000 target updates
```

Metrics are written to:

```text
checkpoints_v3/training_v3.csv
```

Checkpoints and `latest.json` are written into the same directory.

## 5. Monitor the run

In another terminal:

```bash
cd generals_rl_bot_gx10_v3_1
source .venv/bin/activate
watch -n 5 nvidia-smi
```

To inspect recent metrics:

```bash
tail -n 20 checkpoints_v3/training_v3.csv
```

Important fields include:

```text
spawn_stage
terminated_rate
truncated_rate
decisive_games
p0_wins
p1_wins
entropy
approx_kl
clip_fraction
explained_variance
```

The early short-distance curriculum should produce decisive games more often
than the previous full-distance run.

## 6. Stop and resume safely

Stop with `Ctrl+C` after a checkpoint has been written. Resume toward the same
final target:

```bash
CHECKPOINT_DIR=checkpoints_v3 \
UPDATES=3000 \
bash scripts/train_gx10.sh --resume checkpoints_v3
```

`UPDATES` is the final target, not an additional count. To extend a run that has
reached update 3000:

```bash
CHECKPOINT_DIR=checkpoints_v3 \
UPDATES=5000 \
bash scripts/train_gx10.sh --resume checkpoints_v3
```

## 7. Evaluate against official agents

For a quick checkpoint check:

```bash
GAMES=128 bash scripts/evaluate.sh checkpoints_v3
```

For a more stable comparison:

```bash
GAMES=512 bash scripts/evaluate.sh checkpoints_v3
```

Evaluation uses EMA parameters by default and alternates player seats.

## 8. Export the trained policy to the C++ submission bot

```bash
bash scripts/export_submission.sh checkpoints_v3
```

This creates:

```text
submission/weights.bin
generals_rl_bot_submission.zip
```

It also rebuilds the C++ agent and performs JAX-to-C++ numerical parity testing.

## 9. Verify the real stdin/stdout competition protocol

```bash
bash scripts/verify_local.sh
```

Use another official opponent if desired:

```bash
OPPONENT=third_party/generals-bots/competition/agents/hunter_cpp/run.sh \
SEED=9 bash scripts/verify_local.sh
```

Check the exact agent directory name under
`third_party/generals-bots/competition/agents/` if the official repository
changes its layout.

## 10. Watch a game in the official GUI

```bash
SEED=7 FPS=8 bash scripts/watch_match.sh
```

The GUI is supplied by the cloned official repository. The project starts the
trained C++ bot through `submission/run.sh` and uses the official match runner.
A local graphical session, remote desktop, or working X11 forwarding is needed.

## 11. Recommended training progression

1. Smoke test.
2. Train to update 100-200.
3. Evaluate against Expander and Hunter.
4. Export and watch several GUI matches.
5. Continue only if decisive-game rate and external results improve.
6. Complete the 3000-update curriculum.
7. Compare EMA and raw parameters.
8. Extend to 5000 only after the 3000 checkpoint is clearly stronger.

## 12. Common problems

### JAX shows only CPU

Do not train. Confirm `nvidia-smi`, the NVIDIA driver, and the CUDA-enabled JAX
wheel. Re-run `bash scripts/setup_gx10.sh` only after the GPU stack is healthy.

### Out of memory

Reduce the workload:

```bash
NUM_ENVS=256 POOL_SIZE=2048 MINIBATCH_SEQUENCES=64 \
CHECKPOINT_DIR=checkpoints_v3_small \
bash scripts/train_gx10.sh
```

### GUI does not open over SSH

Use a desktop/remote-desktop session or X11 forwarding. Headless verification
still works with `bash scripts/verify_local.sh`.

### Training has zero mean reward

Do not use zero-sum mean reward as the learning indicator. Inspect termination,
truncation, decisive games, evaluation win rate, and GUI behaviour.
