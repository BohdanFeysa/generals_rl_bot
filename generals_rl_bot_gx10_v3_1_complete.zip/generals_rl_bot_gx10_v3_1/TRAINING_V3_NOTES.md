# Renewed v3 training

Do not resume the failed v2 optimizer/checkpoint. Start a fresh v3 run because the
rollout horizon, GAE, PPO batching, learning-rate schedule, curriculum, EMA state,
and checkpoint schema all changed.

## First run

```bash
bash scripts/setup_gx10.sh
source .venv/bin/activate
bash scripts/smoke_test.sh
CHECKPOINT_DIR=checkpoints_v3 UPDATES=3000 bash scripts/train_gx10.sh
```

## Resume a v3 run

```bash
CHECKPOINT_DIR=checkpoints_v3 UPDATES=3000 \
  bash scripts/train_gx10.sh --resume checkpoints_v3
```

`UPDATES` is the final update number, not an additional count.

## Evaluation

```bash
GAMES=512 bash scripts/evaluate.sh checkpoints_v3
```

Evaluation and export use EMA parameters by default. Add `--last-iterate` to
`python -m src.evaluate` or `python -m src.export` to inspect raw parameters.

## Important limits

This version renews the optimization and curriculum while preserving the compact
CNN+GRU and C++ weight format. It does not reproduce the paper's 15.35M-parameter
transformer, 38-channel spatial memory, 512-step scoreboard histories, or
HL-Gauss value head. Treat Expander/Hunter evaluation and GUI games as the source
of truth, not training loss or zero-sum mean reward.
