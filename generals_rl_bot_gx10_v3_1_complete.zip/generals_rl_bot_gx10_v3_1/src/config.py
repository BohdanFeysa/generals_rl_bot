from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class ModelConfig:
    board_size: int = 21
    input_channels: int = 14
    channels: int = 24
    residual_blocks: int = 3
    hidden_size: int = 96

    @property
    def move_actions(self) -> int:
        return self.board_size * self.board_size * 4 * 2

    @property
    def build_actions(self) -> int:
        return self.board_size * self.board_size

    @property
    def build_offset(self) -> int:
        return self.move_actions

    @property
    def pass_index(self) -> int:
        return self.move_actions + self.build_actions

    @property
    def num_actions(self) -> int:
        return self.pass_index + 1


@dataclass(frozen=True)
class TrainConfig:
    """GX10-oriented recurrent PPO configuration.

    The policy architecture is intentionally unchanged so existing C++ export and
    inference code remain compatible. The optimization recipe follows the 2026
    Generals.io self-play paper where it is compatible with this recurrent model.
    """

    seed: int = 42
    num_envs: int = 512
    pool_size: int = 4096
    rollout_length: int = 512
    total_updates: int = 3000

    # Recurrent PPO: every environment/player trajectory is split into contiguous
    # BPTT chunks. A minibatch contains minibatch_sequences such chunks.
    bptt_length: int = 32
    minibatch_sequences: int = 128
    ppo_epochs: int = 1

    clip_epsilon: float = 0.20
    value_clip_epsilon: float = 0.20
    value_coef: float = 0.50
    max_grad_norm: float = 0.267
    gamma: float = 1.0
    gae_lambda: float = 0.90
    top_advantage_fraction: float = 0.25

    # Published schedules, evaluated in PPO-iteration units rather than raw Adam
    # steps. This keeps resume/extension smooth when total_updates changes.
    learning_rate_scale: float = 0.50
    min_learning_rate: float = 5.0e-6
    max_learning_rate: float = 1.0e-4
    learning_rate_power: float = 1.10
    entropy_scale: float = 0.05
    entropy_power: float = 0.20
    ema_decay: float = 0.999

    # Start with nearby generals, then progressively widen the maximum BFS spawn
    # distance before switching to the exact competition distribution.
    spawn_curriculum_updates: int = 1800

    save_every: int = 20
    log_every: int = 1
    checkpoint_dir: str = "checkpoints_v3"
    compilation_cache_dir: str = ".jax_cache"
    compute_dtype: str = "bfloat16"

    @property
    def chunks_per_agent(self) -> int:
        return self.rollout_length // self.bptt_length

    @property
    def sequence_count(self) -> int:
        return self.num_envs * 2 * self.chunks_per_agent

    @property
    def minibatches_per_epoch(self) -> int:
        return self.sequence_count // self.minibatch_sequences

    @property
    def optimizer_steps_per_update(self) -> int:
        return self.ppo_epochs * self.minibatches_per_epoch

    @property
    def agent_steps_per_update(self) -> int:
        return self.num_envs * 2 * self.rollout_length

    @property
    def environment_steps_per_update(self) -> int:
        return self.num_envs * self.rollout_length

    def validate(self) -> None:
        if self.num_envs <= 0 or self.pool_size <= 0:
            raise ValueError("num_envs and pool_size must be positive")
        if self.pool_size < self.num_envs:
            raise ValueError("pool_size must be at least num_envs")
        if self.pool_size % 16 != 0:
            raise ValueError(
                "competition pools cover 16 board-size combinations; "
                "pool_size must be divisible by 16"
            )
        if self.rollout_length <= 0 or self.total_updates <= 0:
            raise ValueError("rollout_length and total_updates must be positive")
        if self.bptt_length <= 0 or self.rollout_length % self.bptt_length != 0:
            raise ValueError("rollout_length must be divisible by bptt_length")
        if self.minibatch_sequences <= 0:
            raise ValueError("minibatch_sequences must be positive")
        if self.sequence_count % self.minibatch_sequences != 0:
            raise ValueError(
                "num_envs*2*(rollout_length/bptt_length) must be divisible "
                "by minibatch_sequences"
            )
        if self.ppo_epochs <= 0:
            raise ValueError("ppo_epochs must be positive")
        if not 0.0 < self.top_advantage_fraction <= 1.0:
            raise ValueError("top_advantage_fraction must be in (0, 1]")
        if not 0.0 <= self.ema_decay < 1.0:
            raise ValueError("ema_decay must be in [0, 1)")
        if self.spawn_curriculum_updates < 0:
            raise ValueError("spawn_curriculum_updates must be non-negative")


def save_config(path: str | Path, model: ModelConfig, train: TrainConfig) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"model": asdict(model), "train": asdict(train)}, indent=2),
        encoding="utf-8",
    )
