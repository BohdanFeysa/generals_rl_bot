from __future__ import annotations

import argparse
from typing import Callable

import jax
import jax.numpy as jnp

from generals import GeneralsEnv
from generals.agents import ExpanderAgent, HunterAgent
from generals.core import game

from .actions import action_index_to_env, mask_logits, valid_action_mask
from .checkpoint import load_params_only
from .config import ModelConfig
from .model import ActorCritic, encode_observation


def stack_player_observations(state):
    p0 = game.get_observation(state, 0)
    p1 = game.get_observation(state, 1)
    return jax.tree.map(lambda a, b: jnp.stack([a, b], axis=0), p0, p1)


def select_seat(tree, seat):
    n = seat.shape[0]
    return jax.tree.map(lambda x: x[jnp.arange(n), seat], tree)


def evaluate(
    checkpoint: str,
    opponent_name: str,
    games: int,
    seed: int,
    prefer_ema: bool,
) -> None:
    cfg = ModelConfig()
    model = ActorCritic(cfg, compute_dtype=jnp.float32)
    dummy_x = jnp.zeros((1, cfg.board_size, cfg.board_size, cfg.input_channels), dtype=jnp.float32)
    dummy_h = jnp.zeros((1, cfg.hidden_size), dtype=jnp.float32)
    target = model.init(jax.random.PRNGKey(0), dummy_x, dummy_h)["params"]
    params = load_params_only(checkpoint, target, prefer_ema=prefer_ema)

    opponent = ExpanderAgent() if opponent_name == "expander" else HunterAgent()
    env = GeneralsEnv(mode="competition", pool_size=max(games, 256))
    key = jax.random.PRNGKey(seed)
    key, pool_key = jax.random.split(key)
    pool, _ = env.reset(pool_key)
    idx = jnp.arange(games, dtype=jnp.int32) % env.pool_size
    states = jax.tree.map(lambda x: x[idx], pool)._replace(pool_idx=idx)

    get_obs = jax.jit(jax.vmap(stack_player_observations))
    step_batch = jax.jit(jax.vmap(lambda s, a: env.step(s, a, pool)))
    opponent_act = jax.jit(jax.vmap(opponent.act))

    seat = jnp.arange(games, dtype=jnp.int32) % 2
    other = 1 - seat
    obs = get_obs(states)
    hidden = jnp.zeros((games, cfg.hidden_size), dtype=jnp.float32)
    finished = jnp.zeros((games,), dtype=jnp.bool_)
    wins = jnp.zeros((games,), dtype=jnp.bool_)
    losses = jnp.zeros((games,), dtype=jnp.bool_)

    @jax.jit
    def learner_act(obs_one, h):
        x = encode_observation(obs_one, dtype=jnp.float32)
        logits, _, h_out = model.apply({"params": params}, x, h)
        logits = mask_logits(logits, valid_action_mask(obs_one))
        idx_action = jnp.argmax(logits, axis=-1).astype(jnp.int32)
        return action_index_to_env(idx_action), h_out

    for _turn in range(1200):
        learner_obs = select_seat(obs, seat)
        opp_obs = select_seat(obs, other)
        learner_action, hidden_out = learner_act(learner_obs, hidden)
        key, action_key = jax.random.split(key)
        opp_keys = jax.random.split(action_key, games)
        opp_action = opponent_act(opp_obs, opp_keys)

        actions = jnp.zeros((games, 2, 5), dtype=jnp.int32)
        actions = actions.at[jnp.arange(games), seat].set(learner_action)
        actions = actions.at[jnp.arange(games), other].set(opp_action)
        timestep, states = step_batch(states, actions)
        just_finished = (~finished) & (timestep.terminated | timestep.truncated)
        wins = wins | (just_finished & (timestep.info.winner == seat))
        losses = losses | (just_finished & (timestep.info.winner == other))
        finished = finished | just_finished
        hidden = jnp.where((timestep.terminated | timestep.truncated)[:, None], 0.0, hidden_out)
        obs = timestep.observation
        if bool(jnp.all(finished)):
            break

    wins_n = int(jnp.sum(wins))
    losses_n = int(jnp.sum(losses))
    draws_n = games - wins_n - losses_n
    print(
        f"vs {opponent_name}: games={games} wins={wins_n} losses={losses_n} "
        f"draws={draws_n} win_rate={wins_n / games:.3f}"
    )


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("checkpoint")
    p.add_argument("--opponent", choices=["expander", "hunter", "both"], default="both")
    p.add_argument("--games", type=int, default=256)
    p.add_argument("--seed", type=int, default=123)
    p.add_argument(
        "--last-iterate",
        action="store_true",
        help="Evaluate raw training parameters instead of EMA parameters",
    )
    args = p.parse_args()
    opponents = ["expander", "hunter"] if args.opponent == "both" else [args.opponent]
    for i, name in enumerate(opponents):
        evaluate(
            args.checkpoint,
            name,
            args.games,
            args.seed + i,
            prefer_ema=not args.last_iterate,
        )


if __name__ == "__main__":
    main()
