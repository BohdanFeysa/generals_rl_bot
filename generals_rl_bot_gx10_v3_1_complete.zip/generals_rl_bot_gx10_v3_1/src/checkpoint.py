from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from flax import serialization


def save_checkpoint(
    directory: str | Path,
    state: Any,
    ema_params: Any,
    update: int,
    rng_key: Any,
) -> Path:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"update_{update:07d}.msgpack"
    temp = target.with_suffix(".tmp")
    payload = {
        "params": state.params,
        "ema_params": ema_params,
        "opt_state": state.opt_state,
        "step": state.step,
        "rng_key": rng_key,
    }
    temp.write_bytes(serialization.to_bytes(payload))
    os.replace(temp, target)
    (directory / "latest.json").write_text(
        json.dumps({"update": update, "file": target.name}, indent=2),
        encoding="utf-8",
    )
    return target


def resolve_checkpoint(path: str | Path) -> Path:
    path = Path(path)
    if path.is_file():
        return path
    latest = path / "latest.json"
    if not latest.exists():
        raise FileNotFoundError(f"No checkpoint found in {path}")
    meta = json.loads(latest.read_text(encoding="utf-8"))
    return path / meta["file"]


def _restore_like(target: Any, raw: Any) -> Any:
    return serialization.from_state_dict(target, raw)


def load_checkpoint(
    path: str | Path,
    state: Any,
    ema_target: Any,
    rng_target: Any,
) -> tuple[Any, Any, Any, int]:
    """Restore a v3 checkpoint.

    v1/v2 checkpoints do not contain compatible optimizer/EMA state and should not
    be resumed into the renewed recipe. They can still be loaded with
    load_params_only for evaluation or warm-start experiments.
    """
    ckpt = resolve_checkpoint(path)
    raw = serialization.msgpack_restore(ckpt.read_bytes())
    if "ema_params" not in raw or "rng_key" not in raw:
        raise ValueError(
            "This is a legacy v1/v2 checkpoint. Start a fresh v3 run; the old "
            "optimizer state is incompatible with the new PPO schedule."
        )
    try:
        restored_params = _restore_like(state.params, raw["params"])
        restored_ema = _restore_like(ema_target, raw["ema_params"])
        restored_opt = _restore_like(state.opt_state, raw["opt_state"])
        restored_step = _restore_like(state.step, raw["step"])
        restored_rng = _restore_like(rng_target, raw["rng_key"])
    except Exception as exc:
        raise ValueError(
            "Checkpoint structure is incompatible with this model/configuration."
        ) from exc

    update = int(ckpt.stem.split("_")[-1])
    state = state.replace(
        params=restored_params,
        opt_state=restored_opt,
        step=restored_step,
    )
    return state, restored_ema, restored_rng, update


def load_params_only(
    path: str | Path,
    params_target: Any,
    *,
    prefer_ema: bool = True,
) -> Any:
    """Load policy parameters from any project checkpoint.

    v3 checkpoints deploy EMA parameters by default. Legacy checkpoints have no
    EMA and automatically fall back to the last iterate.
    """
    ckpt = resolve_checkpoint(path)
    raw = serialization.msgpack_restore(ckpt.read_bytes())
    key = "ema_params" if prefer_ema and "ema_params" in raw else "params"
    return serialization.from_state_dict(params_target, raw[key])
