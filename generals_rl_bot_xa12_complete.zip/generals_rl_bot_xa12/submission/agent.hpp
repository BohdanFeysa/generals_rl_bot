#pragma once

#include "model.hpp"

#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <optional>
#include <vector>

namespace genrl {

struct Observation {
    int height = 0, width = 0;
    int turn = 0;
    int my_land = 0, my_army = 0, opp_land = 0, opp_army = 0;
    std::array<int, model_config::BOARD * model_config::BOARD> type{};
    std::array<int, model_config::BOARD * model_config::BOARD> owner{};
    std::array<int, model_config::BOARD * model_config::BOARD> army{};
};

struct Action {
    int kind = 1, row = 0, col = 0, dir = 0, split = 0;
};

class Agent {
public:
    explicit Agent(const std::string& weights) : model_(weights) { hidden_.fill(0.0f); }

    Action choose(const Observation& obs) {
        const auto encoded = encode(obs);
        ForwardResult result = model_.forward(encoded, hidden_);
        hidden_ = result.hidden;
        if (auto forced = immediate_general_capture(obs)) return *forced;
        const auto legal = legal_mask(obs);
        int best = model_config::PASS_INDEX;
        float best_logit = -std::numeric_limits<float>::infinity();
        for (int i = 0; i < model_config::NUM_ACTIONS; ++i) {
            if (legal[i] && result.logits[i] > best_logit) {
                best_logit = result.logits[i];
                best = i;
            }
        }
        return decode(best);
    }

private:
    Model model_;
    std::array<float, model_config::HIDDEN> hidden_{};

    static int at(int r, int c) { return r * model_config::BOARD + c; }
    static bool in_bounds(const Observation& o, int r, int c) {
        return r >= 0 && r < o.height && c >= 0 && c < o.width;
    }

    static std::array<float, model_config::BOARD * model_config::BOARD * model_config::INPUT_CHANNELS>
    encode(const Observation& o) {
        constexpr int B = model_config::BOARD;
        constexpr int C = model_config::INPUT_CHANNELS;
        std::array<float, B * B * C> x{};
        const float land_me = static_cast<float>(o.my_land) / 441.0f;
        const float army_me = std::log1p(static_cast<float>(o.my_army)) / 10.0f;
        const float land_opp = static_cast<float>(o.opp_land) / 441.0f;
        const float army_opp = std::log1p(static_cast<float>(o.opp_army)) / 10.0f;
        const float timestep = static_cast<float>(o.turn) / 1200.0f;
        for (int r = 0; r < B; ++r) {
            for (int c = 0; c < B; ++c) {
                const int cell = at(r, c);
                const int base = cell * C;
                const bool pad = !in_bounds(o, r, c);
                bool pad_visible = false;
                if (pad) {
                    // Official training pools mountain-pad only the bottom/right
                    // of the true rectangle. Fog still applies to those cells:
                    // a padding mountain is channel 3 when adjacent to our land,
                    // otherwise it is channel 8 (structure-in-fog).
                    for (int rr = std::max(0, r - 1); rr <= std::min(o.height - 1, r + 1); ++rr) {
                        for (int cc = std::max(0, c - 1); cc <= std::min(o.width - 1, c + 1); ++cc) {
                            pad_visible = pad_visible || (o.owner[at(rr, cc)] == 1);
                        }
                    }
                }
                const int type = pad ? (pad_visible ? 2 : 5) : o.type[cell];
                const int owner = pad ? 0 : o.owner[cell];
                const float a = pad ? 0.0f : static_cast<float>(o.army[cell]);
                x[base + 0] = std::clamp(std::log1p(a) / 8.0f, 0.0f, 2.0f);
                x[base + 1] = type == 4;
                x[base + 2] = type == 3;
                x[base + 3] = type == 2;
                x[base + 4] = (type == 1 && owner == 0);
                x[base + 5] = owner == 1;
                x[base + 6] = owner == 2;
                x[base + 7] = type == 0;
                x[base + 8] = type == 5;
                x[base + 9] = land_me;
                x[base + 10] = army_me;
                x[base + 11] = land_opp;
                x[base + 12] = army_opp;
                x[base + 13] = timestep;
            }
        }
        return x;
    }

    static int build_cost(const Observation& o, int r, int c) {
        int cost = 35;
        for (int sr = 0; sr < o.height; ++sr) {
            for (int sc = 0; sc < o.width; ++sc) {
                const int s = at(sr, sc);
                if (o.owner[s] != 1 || (o.type[s] != 3 && o.type[s] != 4)) continue;
                const int surcharge = 14 - 2 * (std::abs(r - sr) + std::abs(c - sc));
                if (surcharge > 0) cost += surcharge;
            }
        }
        return cost;
    }

    static std::array<std::uint8_t, model_config::NUM_ACTIONS> legal_mask(const Observation& o) {
        std::array<std::uint8_t, model_config::NUM_ACTIONS> mask{};
        static constexpr int dr[4] = {-1, 1, 0, 0};
        static constexpr int dc[4] = {0, 0, -1, 1};
        for (int r = 0; r < o.height; ++r) {
            for (int c = 0; c < o.width; ++c) {
                const int cell = at(r, c);
                if (o.owner[cell] == 1 && o.army[cell] > 1) {
                    for (int d = 0; d < 4; ++d) {
                        const int nr = r + dr[d], nc = c + dc[d];
                        if (!in_bounds(o, nr, nc)) continue;
                        if (o.type[at(nr, nc)] == 2) continue;
                        const int base = ((cell * 4 + d) * 2);
                        mask[base] = mask[base + 1] = 1;
                    }
                }
                if (o.owner[cell] == 1 && o.type[cell] != 3 && o.type[cell] != 4 &&
                    o.army[cell] >= build_cost(o, r, c)) {
                    mask[model_config::BUILD_OFFSET + cell] = 1;
                }
            }
        }
        mask[model_config::PASS_INDEX] = 1;
        return mask;
    }

    static Action decode(int idx) {
        if (idx < model_config::BUILD_OFFSET) {
            const int split = idx % 2; idx /= 2;
            const int dir = idx % 4; idx /= 4;
            return Action{0, idx / model_config::BOARD, idx % model_config::BOARD, dir, split};
        }
        if (idx < model_config::PASS_INDEX) {
            const int cell = idx - model_config::BUILD_OFFSET;
            return Action{2, cell / model_config::BOARD, cell % model_config::BOARD, 0, 0};
        }
        return Action{};
    }

    static std::optional<Action> immediate_general_capture(const Observation& o) {
        static constexpr int dr[4] = {-1, 1, 0, 0};
        static constexpr int dc[4] = {0, 0, -1, 1};
        int best_margin = 0;
        std::optional<Action> best;
        for (int r = 0; r < o.height; ++r) {
            for (int c = 0; c < o.width; ++c) {
                const int src = at(r, c);
                if (o.owner[src] != 1 || o.army[src] <= 1) continue;
                for (int d = 0; d < 4; ++d) {
                    const int nr = r + dr[d], nc = c + dc[d];
                    if (!in_bounds(o, nr, nc)) continue;
                    const int dst = at(nr, nc);
                    if (o.type[dst] == 4 && o.owner[dst] == 2) {
                        // At/after turn 800, a valid move onto the enemy general
                        // is deathtouch regardless of army counts. Before that,
                        // require a normal army-based capture.
                        const int margin = (o.army[src] - 1) - o.army[dst];
                        const bool wins = (o.turn >= 800) || (margin > 0);
                        const int priority = (o.turn >= 800 ? 1'000'000 : 0) + margin;
                        if (wins && priority > best_margin) {
                            best_margin = priority;
                            best = Action{0, r, c, d, 0};
                        }
                    }
                }
            }
        }
        return best;
    }
};

}  // namespace genrl
