#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CXX="${CXX:-g++}"
"$CXX" -std=c++20 -O3 -DNDEBUG -ffast-math -march=native -mtune=native \
  -Wall -Wextra -Wpedantic main.cpp -o bot
strip bot 2>/dev/null || true
