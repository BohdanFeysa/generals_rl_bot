#pragma once
namespace model_config {
constexpr int BOARD = 21;
constexpr int INPUT_CHANNELS = 14;
constexpr int CHANNELS = 24;
constexpr int RESIDUAL_BLOCKS = 3;
constexpr int HIDDEN = 96;
constexpr int MOVE_ACTIONS = 3528;
constexpr int BUILD_OFFSET = 3528;
constexpr int PASS_INDEX = 3969;
constexpr int NUM_ACTIONS = 3970;
}
