#pragma once

#include "model_config.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace genrl {

struct Tensor {
    std::vector<std::uint32_t> shape;
    std::vector<float> data;
};

class WeightFile {
public:
    explicit WeightFile(const std::string& path) { load(path); }

    const Tensor& at(const std::string& name) const {
        auto it = tensors_.find(name);
        if (it == tensors_.end()) throw std::runtime_error("missing tensor: " + name);
        return it->second;
    }

private:
    std::unordered_map<std::string, Tensor> tensors_;

    template <class T>
    static T read_scalar(std::ifstream& f) {
        T value{};
        f.read(reinterpret_cast<char*>(&value), sizeof(T));
        if (!f) throw std::runtime_error("truncated weight file");
        return value;
    }

    void load(const std::string& path) {
        std::ifstream f(path, std::ios::binary);
        if (!f) throw std::runtime_error("cannot open weights: " + path);
        char magic[8]{};
        f.read(magic, 8);
        if (!f || std::memcmp(magic, "GENRLV1\0", 8) != 0) {
            throw std::runtime_error("invalid weights magic");
        }
        const std::uint32_t count = read_scalar<std::uint32_t>(f);
        for (std::uint32_t i = 0; i < count; ++i) {
            const std::uint16_t name_len = read_scalar<std::uint16_t>(f);
            std::string name(name_len, '\0');
            f.read(name.data(), name_len);
            const std::uint8_t rank = read_scalar<std::uint8_t>(f);
            Tensor t;
            t.shape.resize(rank);
            std::uint64_t expected = 1;
            for (std::uint8_t d = 0; d < rank; ++d) {
                t.shape[d] = read_scalar<std::uint32_t>(f);
                expected *= t.shape[d];
            }
            const std::uint64_t size = read_scalar<std::uint64_t>(f);
            if (size != expected) throw std::runtime_error("bad tensor size: " + name);
            t.data.resize(static_cast<std::size_t>(size));
            f.read(reinterpret_cast<char*>(t.data.data()), static_cast<std::streamsize>(size * sizeof(float)));
            if (!f) throw std::runtime_error("truncated tensor: " + name);
            tensors_.emplace(std::move(name), std::move(t));
        }
    }
};

struct ForwardResult {
    std::array<float, model_config::NUM_ACTIONS> logits{};
    std::array<float, model_config::HIDDEN> hidden{};
    float value = 0.0f;
};

class Model {
public:
    explicit Model(const std::string& weights_path) : weights_(weights_path) {
        validate_shapes();
    }

    ForwardResult forward(
        const std::array<float, model_config::BOARD * model_config::BOARD * model_config::INPUT_CHANNELS>& input,
        const std::array<float, model_config::HIDDEN>& hidden_in) const {
        constexpr int B = model_config::BOARD;
        constexpr int C = model_config::CHANNELS;
        std::vector<float> x(B * B * C);
        conv_same(input.data(), model_config::INPUT_CHANNELS, weights_.at("stem/kernel"), weights_.at("stem/bias"), x.data());
        relu_inplace(x);

        for (int block = 0; block < model_config::RESIDUAL_BLOCKS; ++block) {
            const std::string prefix = "res_" + std::to_string(block) + "/";
            std::vector<float> y(B * B * C), z(B * B * C);
            conv_same(x.data(), C, weights_.at(prefix + "conv1/kernel"), weights_.at(prefix + "conv1/bias"), y.data());
            relu_inplace(y);
            conv_same(y.data(), C, weights_.at(prefix + "conv2/kernel"), weights_.at(prefix + "conv2/bias"), z.data());
            for (std::size_t i = 0; i < x.size(); ++i) x[i] = std::max(0.0f, x[i] + z[i]);
        }

        std::array<float, C> pooled{};
        for (int r = 0; r < B; ++r) {
            for (int c = 0; c < B; ++c) {
                const int base = (r * B + c) * C;
                for (int k = 0; k < C; ++k) pooled[k] += x[base + k];
            }
        }
        constexpr float inv_cells = 1.0f / static_cast<float>(B * B);
        for (float& v : pooled) v *= inv_cells;

        const auto z = gate(pooled.data(), C, hidden_in.data(), "gru_xz", "gru_hz", true);
        const auto r = gate(pooled.data(), C, hidden_in.data(), "gru_xr", "gru_hr", true);
        std::array<float, model_config::HIDDEN> reset_hidden{};
        for (int i = 0; i < model_config::HIDDEN; ++i) reset_hidden[i] = r[i] * hidden_in[i];
        const auto n = gate(pooled.data(), C, reset_hidden.data(), "gru_xn", "gru_hn", false);

        ForwardResult out;
        for (int i = 0; i < model_config::HIDDEN; ++i) {
            out.hidden[i] = (1.0f - z[i]) * n[i] + z[i] * hidden_in[i];
        }

        std::array<float, C> context{};
        dense(out.hidden.data(), model_config::HIDDEN, weights_.at("context/kernel"), weights_.at("context/bias"), context.data());

        std::vector<float> policy_features(B * B * C);
        for (int r0 = 0; r0 < B; ++r0) {
            for (int c0 = 0; c0 < B; ++c0) {
                const int base = (r0 * B + c0) * C;
                for (int k = 0; k < C; ++k) policy_features[base + k] = std::max(0.0f, x[base + k] + context[k]);
            }
        }

        std::array<float, model_config::MOVE_ACTIONS> move{};
        pointwise(policy_features.data(), weights_.at("move_head/kernel"), weights_.at("move_head/bias"), 8, move.data());
        std::copy(move.begin(), move.end(), out.logits.begin());

        std::array<float, model_config::BOARD * model_config::BOARD> build{};
        pointwise(policy_features.data(), weights_.at("build_head/kernel"), weights_.at("build_head/bias"), 1, build.data());
        std::copy(build.begin(), build.end(), out.logits.begin() + model_config::BUILD_OFFSET);

        std::array<float, C + model_config::HIDDEN> global{};
        std::copy(pooled.begin(), pooled.end(), global.begin());
        std::copy(out.hidden.begin(), out.hidden.end(), global.begin() + C);
        float pass = 0.0f;
        dense(global.data(), static_cast<int>(global.size()), weights_.at("pass_head/kernel"), weights_.at("pass_head/bias"), &pass);
        out.logits[model_config::PASS_INDEX] = pass;
        dense(global.data(), static_cast<int>(global.size()), weights_.at("value_head/kernel"), weights_.at("value_head/bias"), &out.value);
        return out;
    }

private:
    WeightFile weights_;

    static float sigmoid(float x) {
        if (x >= 0.0f) {
            const float e = std::exp(-x);
            return 1.0f / (1.0f + e);
        }
        const float e = std::exp(x);
        return e / (1.0f + e);
    }

    static void relu_inplace(std::vector<float>& x) {
        for (float& v : x) v = std::max(v, 0.0f);
    }

    static void dense(const float* input, int in_dim, const Tensor& kernel, const Tensor& bias, float* output) {
        if (kernel.shape.size() != 2 || static_cast<int>(kernel.shape[0]) != in_dim) {
            throw std::runtime_error("dense kernel shape mismatch");
        }
        const int out_dim = static_cast<int>(kernel.shape[1]);
        for (int j = 0; j < out_dim; ++j) {
            float sum = bias.data[j];
            for (int i = 0; i < in_dim; ++i) sum += input[i] * kernel.data[i * out_dim + j];
            output[j] = sum;
        }
    }

    std::array<float, model_config::HIDDEN> gate(
        const float* x, int xdim, const float* h,
        const std::string& xname, const std::string& hname, bool use_sigmoid) const {
        std::array<float, model_config::HIDDEN> a{}, b{}, out{};
        dense(x, xdim, weights_.at(xname + "/kernel"), weights_.at(xname + "/bias"), a.data());
        dense(h, model_config::HIDDEN, weights_.at(hname + "/kernel"), weights_.at(hname + "/bias"), b.data());
        for (int i = 0; i < model_config::HIDDEN; ++i) {
            const float v = a[i] + b[i];
            out[i] = use_sigmoid ? sigmoid(v) : std::tanh(v);
        }
        return out;
    }

    static void conv_same(const float* input, int in_channels, const Tensor& kernel, const Tensor& bias, float* output) {
        constexpr int B = model_config::BOARD;
        if (kernel.shape.size() != 4 || static_cast<int>(kernel.shape[2]) != in_channels) {
            throw std::runtime_error("conv kernel shape mismatch");
        }
        const int kh = static_cast<int>(kernel.shape[0]);
        const int kw = static_cast<int>(kernel.shape[1]);
        const int out_channels = static_cast<int>(kernel.shape[3]);
        const int pr = kh / 2, pc = kw / 2;
        for (int r = 0; r < B; ++r) {
            for (int c = 0; c < B; ++c) {
                for (int oc = 0; oc < out_channels; ++oc) {
                    float sum = bias.data[oc];
                    for (int kr = 0; kr < kh; ++kr) {
                        const int ir = r + kr - pr;
                        if (ir < 0 || ir >= B) continue;
                        for (int kc = 0; kc < kw; ++kc) {
                            const int ic = c + kc - pc;
                            if (ic < 0 || ic >= B) continue;
                            const int in_base = (ir * B + ic) * in_channels;
                            const int k_base = ((kr * kw + kc) * in_channels) * out_channels + oc;
                            for (int in = 0; in < in_channels; ++in) {
                                sum += input[in_base + in] * kernel.data[k_base + in * out_channels];
                            }
                        }
                    }
                    output[(r * B + c) * out_channels + oc] = sum;
                }
            }
        }
    }

    static void pointwise(const float* input, const Tensor& kernel, const Tensor& bias, int out_channels, float* output) {
        constexpr int B = model_config::BOARD;
        constexpr int C = model_config::CHANNELS;
        for (int cell = 0; cell < B * B; ++cell) {
            for (int oc = 0; oc < out_channels; ++oc) {
                float sum = bias.data[oc];
                for (int ic = 0; ic < C; ++ic) sum += input[cell * C + ic] * kernel.data[ic * out_channels + oc];
                output[cell * out_channels + oc] = sum;
            }
        }
    }

    void validate_shapes() const {
        auto expect = [this](const std::string& name, std::initializer_list<std::uint32_t> dims) {
            const auto& s = weights_.at(name).shape;
            if (s != std::vector<std::uint32_t>(dims)) throw std::runtime_error("shape mismatch: " + name);
        };
        expect("stem/kernel", {3, 3, model_config::INPUT_CHANNELS, model_config::CHANNELS});
        expect("stem/bias", {model_config::CHANNELS});
        for (int i = 0; i < model_config::RESIDUAL_BLOCKS; ++i) {
            const std::string p = "res_" + std::to_string(i) + "/";
            expect(p + "conv1/kernel", {3, 3, model_config::CHANNELS, model_config::CHANNELS});
            expect(p + "conv1/bias", {model_config::CHANNELS});
            expect(p + "conv2/kernel", {3, 3, model_config::CHANNELS, model_config::CHANNELS});
            expect(p + "conv2/bias", {model_config::CHANNELS});
        }
    }
};

}  // namespace genrl
