#include "agent.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

constexpr char TEST_MAGIC[8] = {'G','E','N','T','S','T','1','\0'};

template <class T>
T read_binary(std::ifstream& f) {
    T x{};
    f.read(reinterpret_cast<char*>(&x), sizeof(T));
    if (!f) throw std::runtime_error("truncated golden file");
    return x;
}

int self_test(const std::string& weights, const std::string& golden) {
    genrl::Model model(weights);
    std::ifstream f(golden, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open golden file");
    char magic[8]{};
    f.read(magic, 8);
    if (std::memcmp(magic, TEST_MAGIC, 8) != 0) throw std::runtime_error("invalid golden magic");
    const std::uint32_t x_n = read_binary<std::uint32_t>(f);
    const std::uint32_t h_n = read_binary<std::uint32_t>(f);
    const std::uint32_t logits_n = read_binary<std::uint32_t>(f);
    const std::uint32_t hout_n = read_binary<std::uint32_t>(f);
    if (x_n != model_config::BOARD * model_config::BOARD * model_config::INPUT_CHANNELS ||
        h_n != model_config::HIDDEN || logits_n != model_config::NUM_ACTIONS || hout_n != model_config::HIDDEN) {
        throw std::runtime_error("golden dimensions do not match model");
    }
    std::array<float, model_config::BOARD * model_config::BOARD * model_config::INPUT_CHANNELS> x{};
    std::array<float, model_config::HIDDEN> h{}, expected_h{};
    std::array<float, model_config::NUM_ACTIONS> expected_logits{};
    float expected_value = 0.0f;
    f.read(reinterpret_cast<char*>(x.data()), sizeof(x));
    f.read(reinterpret_cast<char*>(h.data()), sizeof(h));
    f.read(reinterpret_cast<char*>(expected_logits.data()), sizeof(expected_logits));
    f.read(reinterpret_cast<char*>(&expected_value), sizeof(float));
    f.read(reinterpret_cast<char*>(expected_h.data()), sizeof(expected_h));
    if (!f) throw std::runtime_error("truncated golden arrays");
    const auto got = model.forward(x, h);
    float max_logits = 0.0f, max_hidden = 0.0f;
    for (int i = 0; i < model_config::NUM_ACTIONS; ++i) max_logits = std::max(max_logits, std::abs(got.logits[i] - expected_logits[i]));
    for (int i = 0; i < model_config::HIDDEN; ++i) max_hidden = std::max(max_hidden, std::abs(got.hidden[i] - expected_h[i]));
    const float value_err = std::abs(got.value - expected_value);
    std::cerr << "parity max_abs: logits=" << max_logits << " hidden=" << max_hidden << " value=" << value_err << '\n';
    return (max_logits <= 3e-4f && max_hidden <= 3e-4f && value_err <= 3e-4f) ? 0 : 2;
}

bool read_observation(int h, int w, genrl::Observation& o) {
    if (!(std::cin >> o.turn >> o.my_land >> o.my_army >> o.opp_land >> o.opp_army)) return false;
    o.height = h; o.width = w;
    o.type.fill(2); o.owner.fill(0); o.army.fill(0);
    for (int r = 0; r < h; ++r) for (int c = 0; c < w; ++c) std::cin >> o.type[r * model_config::BOARD + c];
    for (int r = 0; r < h; ++r) for (int c = 0; c < w; ++c) std::cin >> o.owner[r * model_config::BOARD + c];
    for (int r = 0; r < h; ++r) for (int c = 0; c < w; ++c) std::cin >> o.army[r * model_config::BOARD + c];
    return static_cast<bool>(std::cin);
}

}  // namespace

int main(int argc, char** argv) {
    try {
        if (argc >= 2 && std::string(argv[1]) == "--self-test") {
            const std::string weights = argc >= 3 ? argv[2] : "weights.bin";
            const std::string golden = argc >= 4 ? argv[3] : "golden.bin";
            return self_test(weights, golden);
        }
        const std::string weights = argc >= 2 ? argv[1] : "weights.bin";
        int player_id = 0, h = 0, w = 0;
        if (!(std::cin >> player_id >> h >> w)) return 0;
        if (h < 1 || h > model_config::BOARD || w < 1 || w > model_config::BOARD) {
            throw std::runtime_error("unsupported board dimensions");
        }
        genrl::Agent agent(weights);
        genrl::Observation obs;
        while (read_observation(h, w, obs)) {
            const genrl::Action a = agent.choose(obs);
            std::cout << a.kind << ' ' << a.row << ' ' << a.col << ' ' << a.dir << ' ' << a.split << '\n' << std::flush;
        }
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "fatal: " << e.what() << '\n';
        return 1;
    }
}
