# Generals Competition RL bot — JAX training, C++ submission

This project replaces the original scaffold with an end-to-end pipeline that uses the official `GeneralsEnv(mode="competition")` ruleset for training and a dependency-free C++20 agent for submission.

## What is implemented

- Official 14-field observation encoding, padded to 21×21 exactly as training pools are padded.
- One masked categorical policy with 3,970 actions:
  - 3,528 normal/half moves: `21 × 21 × 4 × 2`
  - 441 castle-build actions
  - one pass action
- Exact castle-build pricing from owned generals and castles.
- Recurrent PPO self-play with GAE, clipped policy/value losses, legal-action masking, entropy regularisation, gradient clipping, auto-reset rollouts, BF16 activations, FP32 parameters, checkpoint/resume, CSV metrics and persistent JAX compilation cache.
- CPU-oriented C++ inference with the official stdin/stdout protocol, true rectangular dimensions from the handshake, recurrent-state persistence, an immediate visible general-capture guard, and a Python↔C++ numerical parity test.
- Evaluation against the official Expander and Hunter agents and local stdio match verification.

## Hardware note

The described 128 GB system matches NVIDIA GB10/DGX Spark-class specifications. The advertised 1 PFLOP figure is sparse FP4 peak compute, not memory bandwidth. The memory bandwidth is approximately 273 GB/s. PPO here normally uses BF16/FP32, so do not estimate training speed from the FP4 headline figure.

## 1. Install on the machine

```bash
git clone https://github.com/BohdanFeysa/generals_rl_bot.git
cd generals_rl_bot
# Replace the repository contents with this package, then:
bash scripts/setup_xa12.sh
source .venv/bin/activate
```

The setup script installs CUDA-enabled JAX 0.11.0, Flax 0.12.7 and Optax 0.2.8, clones the official engine into `third_party/generals-bots`, installs it editable, and verifies that JAX sees a GPU.

## 2. Verify everything before a long run

```bash
bash scripts/smoke_test.sh
```

This runs a tiny PPO update, writes a checkpoint, exports it, compiles C++, and compares C++ outputs against a JAX-generated golden vector.

## 3. Start training

```bash
bash scripts/train_xa12.sh
```

Default baseline:

```text
num_envs=2048
pool_size=8192
rollout_length=64
minibatch_envs=128
ppo_epochs=4
updates=2000
BF16 activations / FP32 parameters
```

Override without editing files:

```bash
NUM_ENVS=4096 POOL_SIZE=16384 MINIBATCH_ENVS=256 \
CHECKPOINT_DIR=checkpoints_large bash scripts/train_xa12.sh
```

Use 2,048 environments first. Only move to 4,096 after checking `nvidia-smi` and the logged FPS; unified memory is large, but launch overhead and the environment/model balance can make a larger batch slower.

Resume:

```bash
bash scripts/train_xa12.sh --resume checkpoints
```

Metrics are written to `checkpoints/training.csv`; checkpoints are atomic `msgpack` files and `latest.json` points to the newest one.

## 4. Evaluate policy quality

```bash
GAMES=512 bash scripts/evaluate.sh checkpoints
```

This alternates seats and reports win/loss/draw rates against both official heuristic agents. Treat this as a regression test, not a complete rating estimate. Also run many different local seeds against several baselines and previous snapshots.

## 5. Export and inject the trained bot

```bash
bash scripts/export_submission.sh checkpoints
```

The exporter:

1. loads the latest checkpoint;
2. writes `submission/weights.bin` in a small custom FP32 format;
3. regenerates `model_config.hpp`;
4. generates a deterministic JAX golden vector;
5. compiles the C++ agent;
6. runs numerical parity validation;
7. creates `generals_rl_bot_submission.zip`.

The competition launches `run.sh`; it starts `./bot ./weights.bin`. Each turn `main.cpp` parses the official frame, `Agent::choose` encodes it, runs the network, applies the same action mask as training, decodes the selected index, and prints exactly one flushed action line.

## 6. Test the actual submission protocol locally

```bash
bash scripts/verify_local.sh
```

For a visual game:

```bash
source .venv/bin/activate
python third_party/generals-bots/competition/matchup.py \
  submission/run.sh \
  third_party/generals-bots/competition/agents/expander_cpp/run.sh \
  --mode competition --seed 7 --gui
```

## Training method and recommended progression

The included run is a strong engineering baseline, not a claim of a solved agent. Use this progression:

1. **Pipeline validation:** smoke test, parity test, local stdio match.
2. **Initial self-play:** 100–300 updates; confirm entropy falls gradually, KL stays controlled, non-pass actions appear, and evaluation improves over random initialisation.
3. **Long self-play:** continue to 2,000 updates with periodic checkpoints.
4. **League training:** retain several strong historical checkpoints and sample opponents from them. Pure latest-vs-latest self-play can forget older strategies or settle into draw-heavy behaviour; league sampling is the next major algorithmic upgrade.
5. **Opponent diversity:** measure against Expander, Hunter, previous snapshots and any legal handcrafted bots. Never select a checkpoint using training reward alone.
6. **Ablations:** compare reward shaping on/off, GRU on/off, castle head on/off, and 2,048 vs 4,096 environments.

## Differences from the original Gemini scaffold

The original files only demonstrated data flow: the C++ engine did not implement the competition game, the training loop did not calculate PPO gradients or update parameters, the network fixed the board to 400 cells, action outputs omitted build/pass semantics, and the submission program did not parse the official protocol. This version removes the redundant custom engine and uses the official JAX simulator as the sole training source of truth.

## Files

```text
src/actions.py       shared action codec and masks
src/model.py         Flax residual CNN + explicit GRU actor-critic
src/train.py         recurrent PPO self-play
src/evaluate.py      batched evaluation against official agents
src/export.py        checkpoint → C++ tensors + parity vector
submission/          dependency-free C++ inference bot
scripts/             setup, smoke test, train, evaluate, export, match
```
