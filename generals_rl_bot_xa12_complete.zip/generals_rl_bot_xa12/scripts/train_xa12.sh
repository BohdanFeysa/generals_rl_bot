#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate

# 128 GB is unified CPU/GPU memory, so leave headroom for the OS, Python and the
# environment pool instead of trying to reserve all of it for XLA.
export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.85}"
export XLA_PYTHON_CLIENT_PREALLOCATE="${XLA_PYTHON_CLIENT_PREALLOCATE:-true}"
export JAX_COMPILATION_CACHE_DIR="${JAX_COMPILATION_CACHE_DIR:-$ROOT/.jax_cache}"
export JAX_OPTIMIZATION_LEVEL="${JAX_OPTIMIZATION_LEVEL:-O1}"
export XLA_FLAGS="${XLA_FLAGS:---xla_gpu_enable_command_buffer=FUSION,CUSTOM_CALL}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-16}"

# Stable starting point for GB10-class 128 GB hardware. Increase num-envs to
# 4096 only after the first run is stable and GPU utilisation remains low.
exec python -m src.train \
  --num-envs "${NUM_ENVS:-2048}" \
  --pool-size "${POOL_SIZE:-8192}" \
  --rollout-length "${ROLLOUT_LENGTH:-64}" \
  --minibatch-envs "${MINIBATCH_ENVS:-128}" \
  --ppo-epochs "${PPO_EPOCHS:-4}" \
  --updates "${UPDATES:-2000}" \
  --learning-rate "${LEARNING_RATE:-0.00025}" \
  --checkpoint-dir "${CHECKPOINT_DIR:-checkpoints}" \
  "$@"
