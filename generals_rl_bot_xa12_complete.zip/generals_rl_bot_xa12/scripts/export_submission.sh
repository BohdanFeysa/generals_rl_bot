#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
CHECKPOINT="${1:-checkpoints}"
python -m src.export "$CHECKPOINT" --submission-dir submission
submission/build.sh
submission/bot --self-test submission/weights.bin submission/golden.bin
rm -f submission/golden.bin
rm -f generals_rl_bot_submission.zip
(
  cd submission
  zip -9 ../generals_rl_bot_submission.zip \
    run.sh build.sh main.cpp agent.hpp model.hpp model_config.hpp weights.bin
)
ls -lh generals_rl_bot_submission.zip
