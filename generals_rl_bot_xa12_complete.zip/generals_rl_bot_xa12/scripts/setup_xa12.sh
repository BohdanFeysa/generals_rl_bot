#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PYTHON="${PYTHON:-python3}"
"$PYTHON" - <<'PY'
import platform, sys
print("Python:", sys.version)
print("Machine:", platform.machine())
if platform.machine() not in {"aarch64", "arm64"}:
    print("WARNING: expected an ARM64 GB10-class machine; continuing anyway.")
PY

if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "ERROR: nvidia-smi is missing. Install/update NVIDIA DGX OS before the JAX stack." >&2
  exit 1
fi
nvidia-smi

"$PYTHON" -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements-train.txt

mkdir -p third_party
if [[ ! -d third_party/generals-bots/.git ]]; then
  git clone https://github.com/strakam/generals-bots.git third_party/generals-bots
else
  git -C third_party/generals-bots pull --ff-only
fi
python -m pip install -e third_party/generals-bots

python - <<'PY'
import jax
import flax
import optax
print("JAX:", jax.__version__)
print("Flax:", flax.__version__)
print("Optax:", optax.__version__)
print("Devices:", jax.devices())
if not any(d.platform == "gpu" for d in jax.devices()):
    raise SystemExit("CUDA JAX installed, but no GPU device is visible")
PY

echo "Setup complete. Activate with: source .venv/bin/activate"
