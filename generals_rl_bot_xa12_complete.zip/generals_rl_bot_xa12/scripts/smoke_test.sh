#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
source .venv/bin/activate
export XLA_PYTHON_CLIENT_MEM_FRACTION="${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.50}"
export JAX_COMPILATION_CACHE_DIR="${JAX_COMPILATION_CACHE_DIR:-$ROOT/.jax_cache}"
python -m src.train \
  --num-envs 32 --pool-size 64 --rollout-length 8 --minibatch-envs 8 \
  --ppo-epochs 1 --updates 1 --checkpoint-dir checkpoints_smoke --float32
python -m src.export checkpoints_smoke --submission-dir submission
submission/build.sh
submission/bot --self-test submission/weights.bin submission/golden.bin
