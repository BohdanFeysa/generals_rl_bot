# Audit of the original repository

## Blocking issues found

1. `env/engine.cpp` is not a Generals Competition engine. It only stores arrays and increments a turn counter, so rollouts generated through it cannot represent the official rules.
2. `src/train.py` collects placeholder transitions but has no PPO objective, GAE, optimiser update, checkpointing, evaluation, opponent management or export validation.
3. `src/network.py` flattens a hard-coded 20×20 board (`400` cells), while competition training uses 21×21 padding and evaluation uses exact 18–21 rectangles.
4. The original policy heads do not cover the official complete action space: normal move, split move, castle build and pass.
5. `submission/contest_bot.cpp` does not parse the official handshake/observation frames, hard-codes dimensions, does not load/use the exported model consistently and does not emit a valid action-selection result.
6. `src/export.py` and the C++ loader do not define a tested, shared tensor layout. Silent transposition or parameter-order errors would therefore be likely.
7. There is no train→export→C++ numerical parity test and no local match test under `--mode competition`.

## Replacement decisions

- Use the official JAX simulator as the only game implementation.
- Use a fixed 21×21 neural input with exact bottom/right mountain-padding semantics at C++ inference time.
- Use one shared 3,970-index action codec in training and deployment.
- Train with recurrent masked PPO and potential-based reward shaping.
- Export named FP32 tensors and generate a deterministic golden vector.
- Keep the submission dependency-free C++ for predictable CPU latency and memory use.

## Next algorithmic upgrades after the baseline is stable

1. Historical-opponent league sampling rather than only latest-vs-latest self-play.
2. Supervised warm-start from legal heuristic or replay trajectories.
3. Separate checkpoint selection on a fixed seed suite and historical league Elo.
4. Opponent-policy fingerprints or a larger recurrent state if partial-observability errors dominate.
5. Distillation or int8 weight quantisation only if actual sandbox timing requires it; the current network is already small.
