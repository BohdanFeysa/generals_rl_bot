import jax.numpy as jnp

from src.actions import action_index_to_env, env_action_to_index
from src.config import ModelConfig


def test_round_trip_every_action():
    cfg = ModelConfig()
    indices = jnp.arange(cfg.num_actions, dtype=jnp.int32)
    decoded = action_index_to_env(indices)
    encoded = env_action_to_index(decoded)
    assert bool(jnp.all(indices == encoded))


def test_known_layout():
    # Cell (2,3), right, half.
    idx = (((2 * 21 + 3) * 4 + 3) * 2 + 1)
    assert action_index_to_env(jnp.array(idx)).tolist() == [0, 2, 3, 3, 1]
