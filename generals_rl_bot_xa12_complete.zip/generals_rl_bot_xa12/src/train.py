from __future__ import annotations

import argparse
import csv
import os
import time
from pathlib import Path
from typing import NamedTuple

# Must be set before JAX initializes the GPU allocator.
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.85")
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "true")

import jax
import jax.numpy as jnp
import numpy as np
import optax
from flax.training.train_state import TrainState

from generals import GeneralsEnv
from generals.core import game

from .actions import action_index_to_env, mask_logits, valid_action_mask
from .checkpoint import load_checkpoint, save_checkpoint
from .config import ModelConfig, TrainConfig, save_config
from .model import ActorCritic, encode_observation


class Transition(NamedTuple):
    obs: object
    action: jnp.ndarray
    old_logprob: jnp.ndarray
    old_value: jnp.ndarray
    reward: jnp.ndarray
    done: jnp.ndarray


class RolloutCarry(NamedTuple):
    states: object
    obs: object
    hidden: jnp.ndarray
    key: jnp.ndarray


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Recurrent masked PPO self-play for Generals Competition")
    p.add_argument("--num-envs", type=int, default=2048)
    p.add_argument("--pool-size", type=int, default=8192)
    p.add_argument("--rollout-length", type=int, default=64)
    p.add_argument("--updates", type=int, default=2000)
    p.add_argument("--ppo-epochs", type=int, default=4)
    p.add_argument("--minibatch-envs", type=int, default=128)
    p.add_argument("--learning-rate", type=float, default=2.5e-4)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--checkpoint-dir", default="checkpoints")
    p.add_argument("--resume", default=None, help="Checkpoint file or directory containing latest.json")
    p.add_argument("--float32", action="store_true", help="Disable bfloat16 activations")
    return p.parse_args()


def stack_player_observations(state):
    p0 = game.get_observation(state, 0)
    p1 = game.get_observation(state, 1)
    return jax.tree.map(lambda a, b: jnp.stack([a, b], axis=0), p0, p1)


def flatten_players(tree):
    return jax.tree.map(lambda x: x.reshape((x.shape[0] * x.shape[1],) + x.shape[2:]), tree)


def potential(obs) -> jnp.ndarray:
    land = (
        obs.owned_land_count.astype(jnp.float32)
        - obs.opponent_land_count.astype(jnp.float32)
    ) / 441.0
    log_ratio = jnp.log1p(obs.owned_army_count.astype(jnp.float32)) - jnp.log1p(
        obs.opponent_army_count.astype(jnp.float32)
    )
    return 0.55 * land + 0.45 * jnp.tanh(log_ratio / 2.0)


def make_optimizer(cfg: TrainConfig) -> optax.GradientTransformation:
    minibatches_per_epoch = cfg.num_envs // cfg.minibatch_envs
    total_opt_steps = cfg.total_updates * cfg.ppo_epochs * minibatches_per_epoch
    schedule = optax.cosine_decay_schedule(
        init_value=cfg.learning_rate - cfg.end_learning_rate,
        decay_steps=max(total_opt_steps, 1),
        alpha=0.0,
    )

    def lr(step):
        return cfg.end_learning_rate + schedule(step)

    return optax.chain(
        optax.clip_by_global_norm(cfg.max_grad_norm),
        optax.adam(learning_rate=lr, eps=1e-5),
    )


def main() -> None:
    args = parse_args()
    train_cfg = TrainConfig(
        seed=args.seed,
        num_envs=args.num_envs,
        pool_size=args.pool_size,
        rollout_length=args.rollout_length,
        total_updates=args.updates,
        ppo_epochs=args.ppo_epochs,
        minibatch_envs=args.minibatch_envs,
        learning_rate=args.learning_rate,
        checkpoint_dir=args.checkpoint_dir,
        compute_dtype="float32" if args.float32 else "bfloat16",
    )
    train_cfg.validate()
    model_cfg = ModelConfig()

    cache_dir = Path(train_cfg.compilation_cache_dir).resolve()
    cache_dir.mkdir(parents=True, exist_ok=True)
    jax.config.update("jax_compilation_cache_dir", str(cache_dir))
    jax.config.update("jax_persistent_cache_min_entry_size_bytes", -1)

    print("JAX devices:", jax.devices())
    if not any(d.platform == "gpu" for d in jax.devices()):
        raise RuntimeError("No JAX GPU found. Install the CUDA-enabled JAX wheel before training.")

    compute_dtype = jnp.float32 if train_cfg.compute_dtype == "float32" else jnp.bfloat16
    model = ActorCritic(model_cfg, compute_dtype=compute_dtype)
    key = jax.random.PRNGKey(train_cfg.seed)
    key, init_key, pool_key = jax.random.split(key, 3)

    dummy_x = jnp.zeros(
        (1, model_cfg.board_size, model_cfg.board_size, model_cfg.input_channels),
        dtype=compute_dtype,
    )
    dummy_h = jnp.zeros((1, model_cfg.hidden_size), dtype=jnp.float32)
    params = model.init(init_key, dummy_x, dummy_h)["params"]
    train_state = TrainState.create(apply_fn=model.apply, params=params, tx=make_optimizer(train_cfg))

    start_update = 0
    if args.resume:
        train_state, start_update = load_checkpoint(args.resume, train_state)
        print(f"Resumed from update {start_update}")

    out_dir = Path(train_cfg.checkpoint_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    save_config(out_dir / "config.json", model_cfg, train_cfg)

    env = GeneralsEnv(mode="competition", pool_size=train_cfg.pool_size)
    print("Generating the official competition training pool...")
    pool, _ = env.reset(pool_key)
    indices = jnp.arange(train_cfg.num_envs, dtype=jnp.int32)
    states = jax.tree.map(lambda x: x[indices % env.pool_size], pool)
    states = states._replace(pool_idx=indices % env.pool_size)

    get_obs_batch = jax.jit(jax.vmap(stack_player_observations))
    step_batch = jax.jit(jax.vmap(lambda s, a: env.step(s, a, pool)))
    obs = get_obs_batch(states)
    hidden = jnp.zeros((train_cfg.num_envs, 2, model_cfg.hidden_size), dtype=jnp.float32)

    def collect_rollout(params, carry: RolloutCarry):
        initial_hidden = carry.hidden

        def one_step(c: RolloutCarry, _):
            flat_obs = flatten_players(c.obs)
            x = encode_observation(flat_obs, dtype=compute_dtype)
            flat_hidden = c.hidden.reshape((-1, model_cfg.hidden_size))
            logits, values, hidden_out = model.apply({"params": params}, x, flat_hidden)
            mask = valid_action_mask(flat_obs)
            logits = mask_logits(logits, mask)

            key_next, sample_key = jax.random.split(c.key)
            action = jax.random.categorical(sample_key, logits, axis=-1).astype(jnp.int32)
            log_probs = jax.nn.log_softmax(logits, axis=-1)
            chosen_logprob = jnp.take_along_axis(log_probs, action[:, None], axis=-1)[:, 0]

            action_2p = action.reshape((train_cfg.num_envs, 2))
            env_actions = action_index_to_env(action_2p)
            timestep, new_states = step_batch(c.states, env_actions)
            done = timestep.terminated | timestep.truncated

            last_obs = get_obs_batch(timestep.last_state)
            # Potential-based shaping: F(s,s') = gamma*Phi(s') - Phi(s).
            # Terminal and truncated states transition to an absorbing state with
            # zero potential, preserving the original game's optimal policies.
            next_phi = jnp.where(done[:, None], 0.0, potential(last_obs))
            dense_reward = train_cfg.shaping_scale * (
                train_cfg.gamma * next_phi - potential(c.obs)
            )
            rewards = timestep.reward + dense_reward

            new_hidden = hidden_out.reshape((train_cfg.num_envs, 2, model_cfg.hidden_size))
            new_hidden = jnp.where(done[:, None, None], 0.0, new_hidden)

            transition = Transition(
                obs=c.obs,
                action=action_2p,
                old_logprob=chosen_logprob.reshape((train_cfg.num_envs, 2)),
                old_value=values.reshape((train_cfg.num_envs, 2)),
                reward=rewards,
                done=done,
            )
            return RolloutCarry(new_states, timestep.observation, new_hidden, key_next), transition

        final_carry, trajectory = jax.lax.scan(
            one_step, carry, xs=None, length=train_cfg.rollout_length
        )

        flat_final_obs = flatten_players(final_carry.obs)
        x_final = encode_observation(flat_final_obs, dtype=compute_dtype)
        _, bootstrap, _ = model.apply(
            {"params": params},
            x_final,
            final_carry.hidden.reshape((-1, model_cfg.hidden_size)),
        )
        bootstrap = bootstrap.reshape((train_cfg.num_envs, 2))

        def gae_step(carry_gae, inputs):
            gae, next_value = carry_gae
            reward_t, done_t, value_t = inputs
            not_done = 1.0 - done_t[:, None].astype(jnp.float32)
            delta = reward_t + train_cfg.gamma * not_done * next_value - value_t
            gae = delta + train_cfg.gamma * train_cfg.gae_lambda * not_done * gae
            return (gae, value_t), gae

        (_, _), advantages = jax.lax.scan(
            gae_step,
            (jnp.zeros_like(bootstrap), bootstrap),
            (trajectory.reward, trajectory.done, trajectory.old_value),
            reverse=True,
        )
        returns = advantages + trajectory.old_value
        return final_carry, trajectory, initial_hidden, advantages, returns

    collect_rollout_jit = jax.jit(collect_rollout)

    @jax.jit
    def update_minibatch(state, obs_mb, hidden0_mb, action_mb, old_logprob_mb, old_value_mb, adv_mb, ret_mb, done_mb):
        m = hidden0_mb.shape[0]
        hidden0_flat = hidden0_mb.reshape((m * 2, model_cfg.hidden_size))

        def loss_fn(params):
            def replay_step(h, inputs):
                obs_t, done_t = inputs
                flat_obs_t = flatten_players(obs_t)
                x_t = encode_observation(flat_obs_t, dtype=compute_dtype)
                logits_t, value_t, h_out = model.apply({"params": params}, x_t, h)
                logits_t = mask_logits(logits_t, valid_action_mask(flat_obs_t))
                h_out = jnp.where(jnp.repeat(done_t, 2)[:, None], 0.0, h_out)
                return h_out, (logits_t, value_t)

            _, (logits, values) = jax.lax.scan(replay_step, hidden0_flat, (obs_mb, done_mb))
            logits = logits.reshape((train_cfg.rollout_length, m, 2, model_cfg.num_actions))
            values = values.reshape((train_cfg.rollout_length, m, 2))

            logp_all = jax.nn.log_softmax(logits, axis=-1)
            new_logprob = jnp.take_along_axis(logp_all, action_mb[..., None], axis=-1)[..., 0]
            probs = jnp.exp(logp_all)
            entropy = -jnp.sum(probs * logp_all, axis=-1)

            ratio = jnp.exp(new_logprob - old_logprob_mb)
            unclipped = ratio * adv_mb
            clipped = jnp.clip(
                ratio,
                1.0 - train_cfg.clip_epsilon,
                1.0 + train_cfg.clip_epsilon,
            ) * adv_mb
            policy_loss = -jnp.mean(jnp.minimum(unclipped, clipped))

            value_clipped = old_value_mb + jnp.clip(
                values - old_value_mb,
                -train_cfg.value_clip_epsilon,
                train_cfg.value_clip_epsilon,
            )
            value_loss_unclipped = jnp.square(values - ret_mb)
            value_loss_clipped = jnp.square(value_clipped - ret_mb)
            value_loss = 0.5 * jnp.mean(jnp.maximum(value_loss_unclipped, value_loss_clipped))

            entropy_mean = jnp.mean(entropy)
            total_loss = policy_loss + train_cfg.value_coef * value_loss - train_cfg.entropy_coef * entropy_mean
            approx_kl = jnp.mean((ratio - 1.0) - (new_logprob - old_logprob_mb))
            clip_fraction = jnp.mean(jnp.abs(ratio - 1.0) > train_cfg.clip_epsilon)
            metrics = {
                "loss": total_loss,
                "policy_loss": policy_loss,
                "value_loss": value_loss,
                "entropy": entropy_mean,
                "approx_kl": approx_kl,
                "clip_fraction": clip_fraction,
            }
            return total_loss, metrics

        (_, metrics), grads = jax.value_and_grad(loss_fn, has_aux=True)(state.params)
        state = state.apply_gradients(grads=grads)
        metrics["grad_norm"] = optax.global_norm(grads)
        return state, metrics

    carry = RolloutCarry(states, obs, hidden, key)
    csv_path = out_dir / "training.csv"
    write_header = not csv_path.exists()
    csv_file = csv_path.open("a", newline="", encoding="utf-8")
    writer = csv.DictWriter(
        csv_file,
        fieldnames=[
            "update", "environment_steps", "fps", "mean_reward", "done_rate",
            "loss", "policy_loss", "value_loss", "entropy", "approx_kl",
            "clip_fraction", "grad_norm",
        ],
    )
    if write_header:
        writer.writeheader()

    print("Compiling rollout and PPO kernels on their first use...")
    total_env_steps = start_update * train_cfg.num_envs * train_cfg.rollout_length
    try:
        for update in range(start_update + 1, train_cfg.total_updates + 1):
            t0 = time.perf_counter()
            carry, traj, initial_hidden, advantages, returns = collect_rollout_jit(train_state.params, carry)
            advantages = (advantages - jnp.mean(advantages)) / (jnp.std(advantages) + 1e-8)

            key, perm_key = jax.random.split(carry.key)
            carry = carry._replace(key=key)
            metric_accum = []
            for _epoch in range(train_cfg.ppo_epochs):
                perm_key, epoch_key = jax.random.split(perm_key)
                order = np.asarray(jax.device_get(jax.random.permutation(epoch_key, train_cfg.num_envs)))
                for start in range(0, train_cfg.num_envs, train_cfg.minibatch_envs):
                    idx = jnp.asarray(order[start:start + train_cfg.minibatch_envs])
                    obs_mb = jax.tree.map(lambda x: x[:, idx], traj.obs)
                    train_state, metrics = update_minibatch(
                        train_state,
                        obs_mb,
                        initial_hidden[idx],
                        traj.action[:, idx],
                        traj.old_logprob[:, idx],
                        traj.old_value[:, idx],
                        advantages[:, idx],
                        returns[:, idx],
                        traj.done[:, idx],
                    )
                    metric_accum.append(metrics)

            # Synchronize once for accurate timing and logging.
            mean_reward = float(jax.device_get(jnp.mean(traj.reward)))
            done_rate = float(jax.device_get(jnp.mean(traj.done.astype(jnp.float32))))
            metrics_mean = jax.tree.map(lambda *xs: jnp.mean(jnp.stack(xs)), *metric_accum)
            metrics_host = {k: float(jax.device_get(v)) for k, v in metrics_mean.items()}
            elapsed = time.perf_counter() - t0
            new_steps = train_cfg.num_envs * train_cfg.rollout_length
            total_env_steps += new_steps
            fps = new_steps / max(elapsed, 1e-6)

            row = {
                "update": update,
                "environment_steps": total_env_steps,
                "fps": fps,
                "mean_reward": mean_reward,
                "done_rate": done_rate,
                **metrics_host,
            }
            writer.writerow(row)
            csv_file.flush()

            if update % train_cfg.log_every == 0:
                print(
                    f"u={update:05d} steps={total_env_steps:,} fps={fps:,.0f} "
                    f"reward={mean_reward:+.4f} done={done_rate:.4f} "
                    f"loss={metrics_host['loss']:.4f} ent={metrics_host['entropy']:.3f} "
                    f"kl={metrics_host['approx_kl']:.5f}"
                )

            if update % train_cfg.save_every == 0 or update == train_cfg.total_updates:
                path = save_checkpoint(out_dir, train_state, update)
                print(f"Saved {path}")
    finally:
        csv_file.close()


if __name__ == "__main__":
    main()
