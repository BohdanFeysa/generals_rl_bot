from __future__ import annotations

from functools import partial

import jax
import jax.numpy as jnp

from .config import ModelConfig


MODEL = ModelConfig()
BOARD = MODEL.board_size
MOVE_ACTIONS = MODEL.move_actions
BUILD_OFFSET = MODEL.build_offset
PASS_INDEX = MODEL.pass_index
NUM_ACTIONS = MODEL.num_actions


def _flatten_leading(x: jnp.ndarray) -> tuple[jnp.ndarray, tuple[int, ...]]:
    lead = x.shape[:-2]
    return x.reshape((-1, x.shape[-2], x.shape[-1])), lead


def _build_kernel(dtype=jnp.float32) -> jnp.ndarray:
    radius = 6
    vals = []
    for dr in range(-radius, radius + 1):
        row = []
        for dc in range(-radius, radius + 1):
            row.append(max(0, 14 - 2 * (abs(dr) + abs(dc))))
        vals.append(row)
    return jnp.asarray(vals, dtype=dtype)[:, :, None, None]


_BUILD_KERNEL = _build_kernel()


@jax.jit
def build_cost_grid(obs) -> jnp.ndarray:
    """Exact competition castle cost from information visible to the player."""
    structures = ((obs.castles | obs.generals) & obs.owned_cells).astype(jnp.float32)
    flat, lead = _flatten_leading(structures)
    x = flat[..., None]  # NHWC
    surcharge = jax.lax.conv_general_dilated(
        x,
        _BUILD_KERNEL,
        window_strides=(1, 1),
        padding="SAME",
        dimension_numbers=("NHWC", "HWIO", "NHWC"),
    )[..., 0]
    return (35.0 + surcharge).reshape(lead + structures.shape[-2:])


@jax.jit
def valid_action_mask(obs) -> jnp.ndarray:
    """Return [..., 3970] legal-action mask using only the agent observation."""
    armies = obs.armies
    owned = obs.owned_cells
    mountains = obs.mountains
    can_move = owned & (armies > 1)

    # Destination masks for directions up, down, left, right.
    up_passable = jnp.pad(~mountains[..., :-1, :], ((0, 0),) * (mountains.ndim - 2) + ((1, 0), (0, 0)))
    down_passable = jnp.pad(~mountains[..., 1:, :], ((0, 0),) * (mountains.ndim - 2) + ((0, 1), (0, 0)))
    left_passable = jnp.pad(~mountains[..., :, :-1], ((0, 0),) * (mountains.ndim - 2) + ((0, 0), (1, 0)))
    right_passable = jnp.pad(~mountains[..., :, 1:], ((0, 0),) * (mountains.ndim - 2) + ((0, 0), (0, 1)))

    move_dirs = jnp.stack(
        [can_move & up_passable, can_move & down_passable, can_move & left_passable, can_move & right_passable],
        axis=-1,
    )
    # Both split choices are legal whenever the source/direction is legal.
    move_mask = jnp.repeat(move_dirs[..., None], 2, axis=-1).reshape(armies.shape[:-2] + (MOVE_ACTIONS,))

    costs = build_cost_grid(obs)
    build_mask = (
        owned
        & ~obs.generals
        & ~obs.castles
        & (armies.astype(jnp.float32) >= costs)
    ).reshape(armies.shape[:-2] + (BOARD * BOARD,))

    pass_mask = jnp.ones(armies.shape[:-2] + (1,), dtype=jnp.bool_)
    return jnp.concatenate([move_mask, build_mask, pass_mask], axis=-1)


@jax.jit
def mask_logits(logits: jnp.ndarray, mask: jnp.ndarray) -> jnp.ndarray:
    return jnp.where(mask, logits, jnp.asarray(-1.0e9, logits.dtype))


@jax.jit
def action_index_to_env(action_index: jnp.ndarray) -> jnp.ndarray:
    """Decode flattened policy index to official [kind,row,col,dir,split]."""
    idx = action_index.astype(jnp.int32)
    is_move = idx < BUILD_OFFSET
    is_build = (idx >= BUILD_OFFSET) & (idx < PASS_INDEX)

    move_q = jnp.minimum(idx, BUILD_OFFSET - 1)
    split = move_q % 2
    move_q //= 2
    direction = move_q % 4
    cell = move_q // 4
    row = cell // BOARD
    col = cell % BOARD

    build_cell = jnp.clip(idx - BUILD_OFFSET, 0, BOARD * BOARD - 1)
    row = jnp.where(is_build, build_cell // BOARD, row)
    col = jnp.where(is_build, build_cell % BOARD, col)

    kind = jnp.where(is_move, 0, jnp.where(is_build, 2, 1)).astype(jnp.int32)
    direction = jnp.where(is_move, direction, 0).astype(jnp.int32)
    split = jnp.where(is_move, split, 0).astype(jnp.int32)
    row = jnp.where(is_move | is_build, row, 0).astype(jnp.int32)
    col = jnp.where(is_move | is_build, col, 0).astype(jnp.int32)
    return jnp.stack([kind, row, col, direction, split], axis=-1)


@jax.jit
def env_action_to_index(action: jnp.ndarray) -> jnp.ndarray:
    kind, row, col, direction, split = [action[..., i].astype(jnp.int32) for i in range(5)]
    move_idx = (((row * BOARD + col) * 4 + direction) * 2 + split)
    build_idx = BUILD_OFFSET + row * BOARD + col
    return jnp.where(kind == 0, move_idx, jnp.where(kind == 2, build_idx, PASS_INDEX)).astype(jnp.int32)
