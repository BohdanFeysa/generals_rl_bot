from __future__ import annotations

import argparse
import struct
from pathlib import Path

import flax
import jax
import jax.numpy as jnp
import numpy as np

from .checkpoint import load_params_only
from .config import ModelConfig
from .model import ActorCritic


WEIGHT_MAGIC = b"GENRLV1\0"
TEST_MAGIC = b"GENTST1\0"


def write_tensor(f, name: str, array: np.ndarray) -> None:
    arr = np.asarray(array, dtype=np.float32, order="C")
    name_b = name.encode("utf-8")
    f.write(struct.pack("<H", len(name_b)))
    f.write(name_b)
    f.write(struct.pack("<B", arr.ndim))
    for dim in arr.shape:
        f.write(struct.pack("<I", dim))
    f.write(struct.pack("<Q", arr.size))
    f.write(arr.tobytes(order="C"))


def export_weights(params, output: Path) -> None:
    flat = flax.traverse_util.flatten_dict(params, sep="/")
    items = sorted(flat.items())
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as f:
        f.write(WEIGHT_MAGIC)
        f.write(struct.pack("<I", len(items)))
        for name, tensor in items:
            write_tensor(f, name, np.asarray(jax.device_get(tensor), dtype=np.float32))
    print(f"Wrote {len(items)} tensors to {output} ({output.stat().st_size / 1024:.1f} KiB)")


def write_model_config(cfg: ModelConfig, output: Path) -> None:
    output.write_text(
        "#pragma once\n"
        "namespace model_config {\n"
        f"constexpr int BOARD = {cfg.board_size};\n"
        f"constexpr int INPUT_CHANNELS = {cfg.input_channels};\n"
        f"constexpr int CHANNELS = {cfg.channels};\n"
        f"constexpr int RESIDUAL_BLOCKS = {cfg.residual_blocks};\n"
        f"constexpr int HIDDEN = {cfg.hidden_size};\n"
        f"constexpr int MOVE_ACTIONS = {cfg.move_actions};\n"
        f"constexpr int BUILD_OFFSET = {cfg.build_offset};\n"
        f"constexpr int PASS_INDEX = {cfg.pass_index};\n"
        f"constexpr int NUM_ACTIONS = {cfg.num_actions};\n"
        "}\n",
        encoding="utf-8",
    )


def write_golden(model: ActorCritic, params, cfg: ModelConfig, output: Path) -> None:
    rng = np.random.default_rng(20260729)
    x = rng.normal(0.0, 0.25, size=(1, cfg.board_size, cfg.board_size, cfg.input_channels)).astype(np.float32)
    h = rng.normal(0.0, 0.10, size=(1, cfg.hidden_size)).astype(np.float32)
    logits, value, h_out = model.apply({"params": params}, jnp.asarray(x), jnp.asarray(h))
    logits = np.asarray(jax.device_get(logits[0]), dtype=np.float32)
    value = np.asarray(jax.device_get(value[0]), dtype=np.float32)
    h_out = np.asarray(jax.device_get(h_out[0]), dtype=np.float32)
    with output.open("wb") as f:
        f.write(TEST_MAGIC)
        f.write(struct.pack("<IIII", x.size, h.size, logits.size, h_out.size))
        f.write(x.reshape(-1).tobytes())
        f.write(h.reshape(-1).tobytes())
        f.write(logits.tobytes())
        f.write(value.tobytes())
        f.write(h_out.tobytes())
    print(f"Wrote C++ parity vector to {output}")


def main() -> None:
    p = argparse.ArgumentParser(description="Export a training checkpoint for the standalone C++ bot")
    p.add_argument("checkpoint", help="Checkpoint file or directory")
    p.add_argument("--submission-dir", default="submission")
    args = p.parse_args()

    cfg = ModelConfig()
    model = ActorCritic(cfg, compute_dtype=jnp.float32)
    dummy_x = jnp.zeros((1, cfg.board_size, cfg.board_size, cfg.input_channels), dtype=jnp.float32)
    dummy_h = jnp.zeros((1, cfg.hidden_size), dtype=jnp.float32)
    target = model.init(jax.random.PRNGKey(0), dummy_x, dummy_h)["params"]
    params = load_params_only(args.checkpoint, target)

    submission = Path(args.submission_dir)
    submission.mkdir(parents=True, exist_ok=True)
    export_weights(params, submission / "weights.bin")
    write_model_config(cfg, submission / "model_config.hpp")
    write_golden(model, params, cfg, submission / "golden.bin")


if __name__ == "__main__":
    main()
