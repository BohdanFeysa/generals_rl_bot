from __future__ import annotations

from dataclasses import dataclass, asdict
import json
from pathlib import Path


@dataclass(frozen=True)
class ModelConfig:
    board_size: int = 21
    input_channels: int = 14
    channels: int = 24
    residual_blocks: int = 3
    hidden_size: int = 96

    @property
    def move_actions(self) -> int:
        return self.board_size * self.board_size * 4 * 2

    @property
    def build_actions(self) -> int:
        return self.board_size * self.board_size

    @property
    def build_offset(self) -> int:
        return self.move_actions

    @property
    def pass_index(self) -> int:
        return self.move_actions + self.build_actions

    @property
    def num_actions(self) -> int:
        return self.pass_index + 1


@dataclass(frozen=True)
class TrainConfig:
    seed: int = 42
    num_envs: int = 2048
    pool_size: int = 8192
    rollout_length: int = 64
    total_updates: int = 2000
    ppo_epochs: int = 4
    minibatch_envs: int = 128
    learning_rate: float = 2.5e-4
    end_learning_rate: float = 2.5e-5
    gamma: float = 0.997
    gae_lambda: float = 0.95
    clip_epsilon: float = 0.20
    value_clip_epsilon: float = 0.20
    value_coef: float = 0.50
    entropy_coef: float = 0.012
    max_grad_norm: float = 0.50
    shaping_scale: float = 0.025
    save_every: int = 20
    log_every: int = 1
    checkpoint_dir: str = "checkpoints"
    compilation_cache_dir: str = ".jax_cache"
    compute_dtype: str = "bfloat16"

    def validate(self) -> None:
        if self.num_envs % self.minibatch_envs != 0:
            raise ValueError("num_envs must be divisible by minibatch_envs")
        if self.pool_size < self.num_envs:
            raise ValueError("pool_size must be at least num_envs")
        if self.rollout_length <= 0 or self.total_updates <= 0:
            raise ValueError("rollout_length and total_updates must be positive")


def save_config(path: str | Path, model: ModelConfig, train: TrainConfig) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"model": asdict(model), "train": asdict(train)}, indent=2),
        encoding="utf-8",
    )
