from __future__ import annotations

from typing import Any

import jax.numpy as jnp
from flax import linen as nn

from .config import ModelConfig


LOG_ARMY_SCALE = 8.0
LOG_TOTAL_ARMY_SCALE = 10.0


def encode_observation(obs, dtype=jnp.float32) -> jnp.ndarray:
    """Convert an official Observation PyTree to normalized NHWC channels."""
    armies = jnp.clip(jnp.log1p(obs.armies.astype(jnp.float32)) / LOG_ARMY_SCALE, 0.0, 2.0)
    shape = obs.armies.shape

    def plane(value: jnp.ndarray) -> jnp.ndarray:
        return jnp.broadcast_to(value[..., None, None], shape)

    channels = [
        armies,
        obs.generals,
        obs.castles,
        obs.mountains,
        obs.neutral_cells,
        obs.owned_cells,
        obs.opponent_cells,
        obs.fog_cells,
        obs.structures_in_fog,
        plane(obs.owned_land_count.astype(jnp.float32) / 441.0),
        plane(jnp.log1p(obs.owned_army_count.astype(jnp.float32)) / LOG_TOTAL_ARMY_SCALE),
        plane(obs.opponent_land_count.astype(jnp.float32) / 441.0),
        plane(jnp.log1p(obs.opponent_army_count.astype(jnp.float32)) / LOG_TOTAL_ARMY_SCALE),
        plane(obs.timestep.astype(jnp.float32) / 1200.0),
    ]
    return jnp.stack([jnp.asarray(x, dtype=dtype) for x in channels], axis=-1)


class ResidualBlock(nn.Module):
    channels: int
    compute_dtype: Any = jnp.float32

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        init = nn.initializers.orthogonal(jnp.sqrt(2.0))
        y = nn.Conv(
            self.channels,
            (3, 3),
            padding="SAME",
            kernel_init=init,
            dtype=self.compute_dtype,
            param_dtype=jnp.float32,
            name="conv1",
        )(x)
        y = nn.relu(y)
        y = nn.Conv(
            self.channels,
            (3, 3),
            padding="SAME",
            kernel_init=init,
            dtype=self.compute_dtype,
            param_dtype=jnp.float32,
            name="conv2",
        )(y)
        return nn.relu(x + y)


class ActorCritic(nn.Module):
    cfg: ModelConfig = ModelConfig()
    compute_dtype: Any = jnp.float32

    @nn.compact
    def __call__(self, x: jnp.ndarray, hidden: jnp.ndarray):
        conv_init = nn.initializers.orthogonal(jnp.sqrt(2.0))
        dense_init = nn.initializers.orthogonal(1.0)

        x = nn.Conv(
            self.cfg.channels,
            (3, 3),
            padding="SAME",
            kernel_init=conv_init,
            dtype=self.compute_dtype,
            param_dtype=jnp.float32,
            name="stem",
        )(x)
        x = nn.relu(x)
        for i in range(self.cfg.residual_blocks):
            x = ResidualBlock(self.cfg.channels, self.compute_dtype, name=f"res_{i}")(x)

        pooled = jnp.mean(x.astype(jnp.float32), axis=(-3, -2))

        def dense(name: str, features: int, inp: jnp.ndarray, init=dense_init) -> jnp.ndarray:
            return nn.Dense(
                features,
                kernel_init=init,
                dtype=self.compute_dtype,
                param_dtype=jnp.float32,
                name=name,
            )(inp)

        # Explicit GRU equations make the export and C++ implementation unambiguous.
        z = nn.sigmoid(dense("gru_xz", self.cfg.hidden_size, pooled) + dense("gru_hz", self.cfg.hidden_size, hidden))
        r = nn.sigmoid(dense("gru_xr", self.cfg.hidden_size, pooled) + dense("gru_hr", self.cfg.hidden_size, hidden))
        n = jnp.tanh(dense("gru_xn", self.cfg.hidden_size, pooled) + dense("gru_hn", self.cfg.hidden_size, r * hidden))
        hidden_out = (1.0 - z) * n + z * hidden
        hidden_out = hidden_out.astype(jnp.float32)

        context = dense("context", self.cfg.channels, hidden_out)
        policy_features = nn.relu(x.astype(jnp.float32) + context[:, None, None, :].astype(jnp.float32))

        move_logits = nn.Conv(
            8,
            (1, 1),
            padding="VALID",
            kernel_init=nn.initializers.orthogonal(0.01),
            dtype=jnp.float32,
            param_dtype=jnp.float32,
            name="move_head",
        )(policy_features).reshape((x.shape[0], self.cfg.move_actions))
        build_logits = nn.Conv(
            1,
            (1, 1),
            padding="VALID",
            kernel_init=nn.initializers.orthogonal(0.01),
            dtype=jnp.float32,
            param_dtype=jnp.float32,
            name="build_head",
        )(policy_features).reshape((x.shape[0], self.cfg.build_actions))

        global_features = jnp.concatenate([pooled, hidden_out], axis=-1)
        pass_logit = nn.Dense(
            1,
            kernel_init=nn.initializers.orthogonal(0.01),
            dtype=jnp.float32,
            param_dtype=jnp.float32,
            name="pass_head",
        )(global_features)
        value = nn.Dense(
            1,
            kernel_init=nn.initializers.orthogonal(1.0),
            dtype=jnp.float32,
            param_dtype=jnp.float32,
            name="value_head",
        )(global_features)[..., 0]

        logits = jnp.concatenate([move_logits, build_logits, pass_logit], axis=-1)
        return logits, value, hidden_out
