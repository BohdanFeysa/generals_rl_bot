from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from flax import serialization


def save_checkpoint(directory: str | Path, state: Any, update: int) -> Path:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"update_{update:07d}.msgpack"
    temp = target.with_suffix(".tmp")
    payload = {"params": state.params, "opt_state": state.opt_state, "step": state.step}
    temp.write_bytes(serialization.to_bytes(payload))
    os.replace(temp, target)
    (directory / "latest.json").write_text(
        json.dumps({"update": update, "file": target.name}, indent=2), encoding="utf-8"
    )
    return target


def resolve_checkpoint(path: str | Path) -> Path:
    path = Path(path)
    if path.is_file():
        return path
    latest = path / "latest.json"
    if not latest.exists():
        raise FileNotFoundError(f"No checkpoint found in {path}")
    meta = json.loads(latest.read_text(encoding="utf-8"))
    return path / meta["file"]


def load_checkpoint(path: str | Path, state: Any) -> tuple[Any, int]:
    ckpt = resolve_checkpoint(path)
    target = {"params": state.params, "opt_state": state.opt_state, "step": state.step}
    restored = serialization.from_bytes(target, ckpt.read_bytes())
    update = int(ckpt.stem.split("_")[-1])
    return state.replace(
        params=restored["params"],
        opt_state=restored["opt_state"],
        step=restored["step"],
    ), update


def load_params_only(path: str | Path, params_target: Any) -> Any:
    ckpt = resolve_checkpoint(path)
    # Deserialize into a minimal target with the expected parameter tree.
    target = {"params": params_target, "opt_state": None, "step": 0}
    try:
        restored = serialization.from_bytes(target, ckpt.read_bytes())
        return restored["params"]
    except Exception:
        # Normal training checkpoints contain a non-None optimizer tree. Build a
        # lightweight object by reading msgpack and extracting the params field.
        raw = serialization.msgpack_restore(ckpt.read_bytes())
        return serialization.from_state_dict(params_target, raw["params"])
